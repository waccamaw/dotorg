---
layout: post
title: "Waccamaw Pauwau 2019"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/waccamaw-pauwau.html
post_id: 5650048
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/waccamaw-pauwau.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Oct 16, 2019
- 3 min read

The 27th [#Waccamaw](https://www.waccamaw.org/updates/hashtags/Waccamaw) Pauwau will happen on the 2nd and 3rd of November, come rain or shine. We still have a few vendor slots open but we have ran out of full service RV camping sites.

We have dry tent camping available and if you have a generator we can hook you up with a RV slot but you will need to fill your water tanks.

Our Host Motel is the Quality Inn and Suits in North Myrtle Beach call 843-272-6153 to reserve. The price is only $49 (plus tax) per night, if you mention the Pauwau. This is a very nice motel.

Our Drum is Red Oak (Multi Tribal), Emcee is John Abrams (Waccamaw), Arena Director is David Creel (Edisto). Lead male is Larry Swearingen (Choctaw) (if he can find his way around the circle) and the lead female is Aki Hedgepeth (Saponi). We hope Aki's beauty will over shadow Larry's ugly! She'll help Larry find his way, I think.

We will be paying out $2,500 in luck of the draw dance money. There will be no drawing under $100 and there will be 17 of them over the two days.

The last draw on Saturday will pay out $300 and the last Draw on Sunday will pay out $500. If you dance the grand entry on Saturday, you will be eligible to participate in the big draw on Saturday, even if you win a smaller draw. We will give you an extra ticket for the big draws for every scheduled dance you do in the arena. Sundays final draw will be for $500. You will need to be in both Grand Entries (Sat and Sun) to qualify for the $500.

I don't know for sure but I hear David Perry and Mike Cranford may be here. With Larry Swearingen here, I think we need all the help we can get. David Creel is already shaking.

These two guys (Perry and Cranston) make me look bad. Actually, they make me look sick because they tend to upset my stomach. :) We usually have a bunch of beautiful ladies surround them because their combined ugly could be fatal.

Grand Entry on Saturday is at 1 PM and on Sunday, the Grand Entry is at 2PM. Dancer's gate fees will be refunded when they register to dance, therefore, the dancers are in free. We offer a free meal, for every registered dancer, each day. We also feed our volunteers and VIPs.There is no parking charge.

We have chairs available but they are limited so bring a lawn chair and lets enjoy some culture. Every one is invited. We have security onsite 24/7 and we will not allow alcohol, cusssing, or recreational drugs. Violators may be detained.

Service animals are welcome but we cannot allow animals near the vendors or the sacred circles. We love animals too but there will be a great many very valuable items on site and dancers and visitors don't want to get anything but grass on them. Animals are pure of spirit and many believe that will take the magic out of a blessed circle, because the good spirits will follow them as they leave. If you bring your pet, you will not be allowed to take them to the inside vendor's area or near the arena or fire circle.

Call 843-358-6877 or 843-229-6792 for more information.

I hope to see you here!

Chief Harold (Buster) Hatcher

Waccamaw Chief

[#PW2019](https://www.waccamaw.org/updates/hashtags/PW2019)

[#event](https://www.waccamaw.org/updates/hashtags/event) [#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau)
