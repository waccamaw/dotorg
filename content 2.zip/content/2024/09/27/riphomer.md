---
layout: post
title: "#RIPHomer"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/riphomer.html
post_id: 5650025
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/riphomer.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 2, 2017
- 1 min read

I hate to provide sad news but our longest seated member of Tribal Council, Homer Johnson has passed away.

Homer was a steady and dedicated member of the Tribe and of Tribal Council. He had heart tempered with the guts to stand up for what he believed in. One never doubted where they stood with Homey, he was open, direct and straight to the point!

He was a retired E-7 from the Air Force and had the bearing one would associate with a Military man. I could always depend on him to set me straight whenever I started to wander from what he thought I should do and he was not always kind when he did it. He chewed my tail more than anyone but I think he was right every time.

Im sure gonna miss him and it breaks my heart to lose him.

His funeral will be in Dillon at the Cooper Funeral Home (209 Black Branch Road, Dillion SC 29536), Saturday the 5th of August but the time is not yet determined.

The family has asked for a drum and the Black Feather Singers, as well as Military Honors. Homer Served on Tribal Council for over fifteen years and passed having earned the permeant title of "Waccamaw Tribal Council Member"!

Until then, walk easy and be safe.

Buster (Chief Hatcher)

Update From Lori: (Homer's Funeral Arrangements)Friday Aug 4th we are having the visitation from 6pm to 8pm at Cooper Funeral Home in Dillon, SC. Then the funeral service will be at 11am on Sat. Aug. 5th at Cooper Funeral Home

[#RIP](https://www.waccamaw.org/updates/hashtags/RIP) [#Funeral](https://www.waccamaw.org/updates/hashtags/Funeral)
