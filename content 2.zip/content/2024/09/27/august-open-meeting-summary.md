---
layout: post
title: "August 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/august-open-meeting-summary.html
post_id: 5649870
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 21, 2018
- 3 min read

Tribal Open Meeting Summary 8/3/2018  held at the Tribal Office in Aynor, SC

1.

CM’s,  Jeania, John, Dalton, Susan, and CoC Rick present. Elders Dan, and Becky present. 2C’s Cheryl and Phil present.

2.

Online Votes

3.

7/24 Approve Hunka membership application

4.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

5.

7/24 Authorize Hunka membership

6.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

7.

7/27 Approve July minutes

8.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

9.

7/27 Appoint Susan to Color Guard & allot $100 for uniform

10.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

11.

Old Business

12.

Cemetery Update

13.

Chief Hatcher: should be finished, just waiting on deed

14.

Resolution: DH-04-06-2018-001 Subject: Exemption of membership fees for age, length of service, or large donations: Third Reading

15.

Susan: can [#4](https://www.waccamaw.org/updates/hashtags/4)-5 be in-knd also?

16.

Example: photographs are a service; the photos are given to the tribe

17.

Dalton: that would fall under volunteer; they would need to give us receipts

18.

John: does it specify that [#2](https://www.waccamaw.org/updates/hashtags/2)-6 are in perpetuity?

19.

Remove/ change “monthly” in the header

20.

Dalton: motion to accept with the change; John seconded

21.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

22.

John: should we auto-renew people whose fees are up-to-date?

23.

People should be responsible for their own ID card

24.

John: we could send out a form asking people to update their information

25.

Glenn C: sending out forms will increase costs; stamps are at $0.50 now

26.

Chief Hatcher: you won’t solve this tonight

27.

Rick: Starla, look at the database & see what it would take to send out a form

28.

John: should the ones who fall under [#2](https://www.waccamaw.org/updates/hashtags/2)-6 have no expiration date on the card?

29.

Rick: I agree with that

30.

John:motion to have no expiration date on lifetime card

31.

Dalton: I think because it affects most of the tribe, you have to do it as a resolution or the Chief has to override it

32.

Chief Hatcher: lots of problems with no expiration dates

33.

People don’t tell you where they are; you can’t update the file

34.

Table the motion

35.

John: I rescind the motion

36.

New Business

37.

Membership Fees Exemption: Dorothy Hayes

38.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

39.

Committee Reports

40.

Buildings & Grounds: Glenn C

41.

Gable finished, need to do the flats on the end

42.

Lay out the circle tomorrow & get wiring

43.

Work Day tomorrow, will be here around 8:30 am

44.

2C Phil to ask Master Electrician about regulations

45.

Rick: got 100 gallon fuel tank’ needs a pump; tractor supply has one for $165

46.

Rick motioned to purchase; Dalton seconded

47.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

48.

Glenn C to pick up

49.

Pauwau: Michelle/ Glenn C

50.

Looking for Volunteers

51.

Trifolds are here to give out

52.

Meeting 8/9 at 6pm

53.

Receipts

54.

Glenn Cook reimbursement: $200  (stamps) Check 701

55.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

56.

Fuel: $80.04 Check 700

57.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

58.

Glenn Cook reimbursement: $65 (Aynor Hoe Down) Check 702

59.

Jeania-yes, John-yes, Dalton-yes, Susan-yes, Rick-yes

60.

2C Cheryl: doing a presentation at CCU

61.

Chief Hatcher

62.

Newsletters need to go out quarterly

63.

Email has to be made a valid form of communication by Tribal Council

64.

Rick: who is the email list controlled by?

65.

Dalton: I would put a disclaimer at the bottom saying that we will not sell their email address

66.

Set up a Youtube channel/ Pinterest to increase volunteers

67.

2C Cheryl: have to include an unsubscribe option

68.

Rick: table till next month

69.

Need to get an email receipt showing that they received the email

70.

Petition: 10 copies ready: $177

71.

Volunteers: CCU students

72.

A lot of people want to invest

73.

For recognition:

74.

BIA route: you’re locked into the BIA

75.

Congress route: they can attach things to your petition

76.

Mike G: Honoring Tribal Veterans

77.

2C Phil: bring your presentation to Council

John motioned to close the meeting; Dalton seconded.

Meeting adjourned 8:27 pm.

Respectfully submitted by Michelle Hatcher on 8/21/18 at 8:02 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
