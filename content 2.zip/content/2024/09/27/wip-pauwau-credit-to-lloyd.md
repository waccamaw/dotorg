---
layout: post
title: "WIP Pauwau 2019: Credit to Lloyd Gill"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/wip-pauwau-credit-to-lloyd.html
post_id: 5649869
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T19:04:13-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
- https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
- https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/29a4c30fba.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/944b538faa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/3817365919.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b25c672948.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cd4f7872cd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bf23877209.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/491910ef34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2ae51260a4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be17fba8b7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9f4529f967.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ccd8619b21.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1c9cab5cc8.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/80248ee3ee.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/91161069df.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e3d3d4bda4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9604e2e8d1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/331d56780d.jpg
url: /2024/09/27/wip-pauwau-credit-to-lloyd.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Nov 7, 2019
- 1 min read

![image](https://waccamaw.micro.blog/uploads/2025/29a4c30fba.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/29a4c30fba.jpg)

75398342_556410618444437_448276101298598

![image](https://waccamaw.micro.blog/uploads/2025/944b538faa.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/944b538faa.jpg)

73324063_396454231238147_857792071377459

![image](https://waccamaw.micro.blog/uploads/2025/3817365919.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/3817365919.jpg)

74272418_448998722425350_487007333830885

![image](https://waccamaw.micro.blog/uploads/2025/b25c672948.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b25c672948.jpg)

74666259_2250788175025104_17371214186104

![image](https://waccamaw.micro.blog/uploads/2025/cd4f7872cd.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/cd4f7872cd.jpg)

74594354_401818257429002_571195374942604

![image](https://waccamaw.micro.blog/uploads/2025/bf23877209.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/bf23877209.jpg)

75220780_425218331475149_631302550185417

![image](https://waccamaw.micro.blog/uploads/2025/491910ef34.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/491910ef34.jpg)

72212792_2692894440766899_28552017404902

![image](https://waccamaw.micro.blog/uploads/2025/2ae51260a4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2ae51260a4.jpg)

73237092_417316088949493_678193705613524

![image](https://waccamaw.micro.blog/uploads/2025/be17fba8b7.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/be17fba8b7.jpg)

75354952_535989756959886_507910913890713

![image](https://waccamaw.micro.blog/uploads/2025/9f4529f967.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9f4529f967.jpg)

74275648_2709869309094411_15847014517063

![image](https://waccamaw.micro.blog/uploads/2025/ccd8619b21.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ccd8619b21.jpg)

74661831_2652941598133272_15719304136962

![image](https://waccamaw.micro.blog/uploads/2025/1c9cab5cc8.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1c9cab5cc8.jpg)

74350321_432910264076915_362447959064418

![image](https://waccamaw.micro.blog/uploads/2025/80248ee3ee.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/80248ee3ee.jpg)

74479734_2544109985810970_73717745914562

![image](https://waccamaw.micro.blog/uploads/2025/91161069df.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/91161069df.jpg)

77244715_795361974247276_640678809537452

![image](https://waccamaw.micro.blog/uploads/2025/e3d3d4bda4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/e3d3d4bda4.jpg)

73524693_554800351754342_658118693464571

![image](https://waccamaw.micro.blog/uploads/2025/9604e2e8d1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9604e2e8d1.jpg)

74374379_456062015016052_712005142443563

![image](https://waccamaw.micro.blog/uploads/2025/331d56780d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/331d56780d.jpg)

74475956_1000512650305321_51011543513390

[#PW2019](https://www.waccamaw.org/updates/hashtags/PW2019) [#event](https://www.waccamaw.org/updates/hashtags/event)
