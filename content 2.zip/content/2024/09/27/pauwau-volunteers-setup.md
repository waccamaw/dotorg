---
layout: post
title: "Pauwau 2016 Volunteers & Setup"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/pauwau-volunteers-setup.html
post_id: 5650006
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/pauwau-volunteers-setup.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 10, 2016
- 1 min read

We are always looking for volunteers for before, during and after Pauwau.  If you''re interested, contact Michelle at [[email protected]](/cdn-cgi/l/email-protection)

Also, on November 2nd starting at 9:00 AM, we will begin setting up for the Pauwau.  We''ve got to put out the tables, chairs, hay bales, sound system, and other things to get ready for the Pauwau.  Hope to see you at the tribal grounds on Nov. 2nd!!!

[#helping](https://www.waccamaw.org/updates/hashtags/helping) [#volunteer](https://www.waccamaw.org/updates/hashtags/volunteer) [#community](https://www.waccamaw.org/updates/hashtags/community) [#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau)
