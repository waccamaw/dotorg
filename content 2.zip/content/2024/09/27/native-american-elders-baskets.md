---
layout: post
title: "Native American Elders Baskets"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/native-american-elders-baskets.html
post_id: 5649997
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T19:25:08-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/4cc283f3e6.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/4cc283f3e6.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/4cc283f3e6.jpg
url: /2024/09/27/native-american-elders-baskets.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Oct 27, 2018
- 1 min read

![image](https://waccamaw.micro.blog/uploads/2025/4cc283f3e6.jpg)

[#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau) [#festival](https://www.waccamaw.org/updates/hashtags/festival) [#Community](https://www.waccamaw.org/updates/hashtags/Community)
