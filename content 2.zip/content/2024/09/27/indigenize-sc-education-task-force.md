---
layout: post
title: "Indigenize SC Education Task Force"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/indigenize-sc-education-task-force.html
post_id: 5649983
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/indigenize-sc-education-task-force.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- May 2, 2022
- 1 min read

Updated: May 3, 2022

The Indigenize SC Education Task Force website and surveys are now available. There are 3 categories for the survey; one for SC Educators, one for Non-Indigenous students, and one for Native students.

Here is the link to the website and the surveys: [https://www.coastal.edu/scoess/spadonicentersandinitiatives/indigenizesc/](https://www.coastal.edu/scoess/spadonicentersandinitiatives/indigenizesc/)

-

Also, be sure to click on the link to the NASC Spring 2022 Newsletter to see Ashley Lowrimore's update on the task force's recent achievements! Thank you, Ashley!

-

funding opportunities for some of our initiatives

-

other announcements, updates, discussion points, etc.

The task force thanks everyone who works to indigenize education in South Carolina! If you'd like to join the task force, email Sara Rich at [[email protected]](/cdn-cgi/l/email-protection#0576776c666d3745666a64767164692b606170).

We'll hopefully have more updates for the next WIP newsletter!

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [native](https://www.waccamaw.org/updates/tags/native-1)
- [education](https://www.waccamaw.org/updates/tags/education)
