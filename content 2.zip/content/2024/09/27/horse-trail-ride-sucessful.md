---
layout: post
title: "Horse Trail Ride 4/28 Sucessful"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/horse-trail-ride-sucessful.html
post_id: 5649982
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T19:07:42-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/753709d7da.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/753709d7da.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/753709d7da.jpg
url: /2024/09/27/horse-trail-ride-sucessful.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Apr 30, 2018
- 1 min read

![Contact Larry for more information.](https://waccamaw.micro.blog/uploads/2025/753709d7da.jpg)

Thanks to great weather, the Waccamaw Trail Ride turned out well Saturday. I would like to thank Clay for his efforts before, during, and after the ride. I want to thank Mr. Doug, Mrs. Jewell, and, of course, Cheyenne, for security. Our friend, Ronnie Boardwine was also a gerat asset. Thanks to anyone else who helped to make the ride a success. I will have full details at the Friday night meeting.

Larry Jernigan

[#event](https://www.waccamaw.org/updates/hashtags/event) [#fundraiser](https://www.waccamaw.org/updates/hashtags/fundraiser)
