---
layout: post
title: "April 2014 Open Meeting Summary 04042014"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/april-open-meeting-summary.html
post_id: 5649873
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/april-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jul 17, 2016
- 3 min read

Tribal Open Meeting Summary 4/4/2014 held at the Tribal Office in Aynor, SC

1.

CoC Scott, CM’s Dalton, Homer, Susan, Robert, and John present.

2.

March Minutes read.

3.

Dalton motioned to accept; Robert seconded

4.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

5.

Financial Report: Michelle (from Alan’s email)

6.

General Fund

7.

Deposits: $236.00 Debits: $392.25  Balance: $14269.13

8.

Building Fund

9.

Deposits: $25.00 Debits: $0.00 Balance: $480.00

10.

Online Votes

11.

Sell boat motor to Mark A for $200

12.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

13.

Motor sold As-is

14.

Receipt emailed to Mark

15.

Old Business

16.

Inactive Membership List

17.

Dalton motioned to remove from ID [#336](https://www.waccamaw.org/updates/hashtags/336) & 307 on Monthly Report Query dated 3/7/14

18.

Homer seconded

19.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

20.

1-year Associate Members to update

21.

Ray Ammons

22.

Sean Strickland

23.

Michele L. Ammons

24.

Dalton motioned to update these to full memberships since they have worked at the Pauwau & attended meetings

25.

Homer seconded

26.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

27.

2nd Chief Cheryl suggested doing these prior to the open meeting

28.

Old Business List

29.

B&G

30.

Rake, pitchfork, RoundUp purchased

31.

Dalton motioned; Homer seconded to reimburse full amount

32.

$116.87 Check 1566

33.

A&C

34.

Scott read Carol Ann’s email & Program Committee Resolution to meeting (stating 4 votes carry the issue)

35.

Homer said it was first time he had seen the letter, possibly due to his own email issues

36.

John worried about discouraging A&C

37.

People willing to reform committee as voting members: Becky, Robert, Susan, 2nd Chief Phil

38.

Susan motioned; Robert seconded

39.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

40.

Moving Bank Accounts

41.

Given choices in area, HCSB is best bet

42.

Dalton motioned to switch to HCSB; Homer seconded

43.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

44.

New Business

45.

Committee Reports

46.

Grants: Michelle

47.

Waiting on SCAC notification

48.

B&G: John

49.

Cemetery maintained

50.

Thanks to Wayne, Donnie, Jameson (?)

51.

Water under office- need French drains; approx. cost: $700

52.

Cool seal: $500

53.

To level: roughly 1.5” from center

54.

Be ready to do other repairs at same time

55.

Budget: $1700 for 4 projects

56.

John motioned; Dalton seconded

57.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

58.

Tractor needs new tires or 1 decent used tire

59.

Spring trimmer & brush blades

60.

John motioned to purchase spring trimmer for $375 or less

61.

Dalton seconded

62.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

63.

Cemetery: need narrow riding mower or look into yard service

64.

John motioned to appoint Neal to B&G Committee

65.

Dalton seconded

66.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

67.

PW: 2nd Chief Cheryl

68.

Had meeting 3/12

69.

2014 camping form reflects gate charges

70.

Budget: removed some items

71.

Timeline: contracts are ready to go out

72.

Billboard quote from last month was a nonprofit price

73.

Ad sales: we need volunteers to help

74.

Show past books to businesses

75.

Fundraiser 4/26: Socastee Heritage Festival Event

76.

Request donations for past program & coloring books

77.

Ronnie Floyd w/ tipi, Trevor will dance

78.

Vend items for fundraising (not food)

79.

Chief Hatcher: would like Rick H to go work with Ronnie

80.

Rick H agreed to go

81.

In-kind donations: Water, paper products, etc… accepted

82.

Chief Hatcher: do we give them anything for donations?

83.

Mark A: can we get a banner made in time for PW?

84.

Chief Hatcher: can check Pepsi

85.

Next meeting: 4/9 @ Ryan’s

86.

Fuel Receipt: $46.65 Check 1567

87.

Homer motioned; John seconded

88.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

89.

Res J-HH-03-07-1014-001: Appointment of Council of Elders as Tribe’s Election Officials: 2nd Reading

90.

Will replace SB-10-01-2010-001

91.

Chief Hatcher

92.

GSW&S recommends septic tank & would write letter to do it

93.

$3700 w/ $190 down, finance rest over 17 years

94.

Dalton motioned; Homer seconded to start project with pump

95.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

96.

Need policy on letters of intent (formal date to get them in)

97.

Mud pile on road: they may get us gravel; may be up to us

98.

John A: Prison program: if interested in talking about cultural things, let him know

99.

Honorary members- need to find out if they have right to sue outside tribal court

100.

Letter from 2nd Chief Cheryl to member read in meeting

101.

Honorary member application

102.

Sponsored by Susan

103.

Bettina Glatz-Kremsner

104.

Homer: concerned about who we’re letting into tribe

105.

Dalton seconded

106.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

107.

Justin Ammons & Glen T’s son- waive fee & expedite it

108.

Susan: provided they get application in by next meeting

109.

Dalton motioned; Susan seconded

110.

Homer-yes, Susan-yes, John-yes, Dalton-yes, Scott-yes

111.

Investment Business

112.

Bingo

113.

2 types

114.

1 license per  501 (c)(3)

115.

Would create jobs with tribal preference

116.

Need to reimburse Susan for choker we gave visitors

117.

Scott approved $50.00 Check 1568

118.

Letters of Intent: send to Susan to put in newsletter

119.

HB4360 sitting in committee; S611 passed senate

120.

Would stop formation of new tribal groups

121.

CMA meeting: tried to reverse S611 stance

122.

Only had 1 tribal leader there at the time

123.

Say they will try to pull it, but they weren’t the ones who introduced it

124.

Drum finished now

Dalton motioned to close the meeting; Susan seconded.

Meeting adjourned 9:00 pm.

Respectfully submitted by Michelle Hatcher on 4/28/14 at 3:15 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
