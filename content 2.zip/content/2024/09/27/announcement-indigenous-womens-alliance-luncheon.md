---
layout: post
title: "Announcement: Indigenous Women's Alliance Luncheon"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/announcement-indigenous-womens-alliance-luncheon.html
post_id: 5649929
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T19:06:36-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/a9ce07a0dc.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/a9ce07a0dc.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/a9ce07a0dc.jpg
url: /2024/09/27/announcement-indigenous-womens-alliance-luncheon.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 3, 2019
- 1 min read

The IWA luncheon has been rescheduled for Saturday, September 14th, 11:30AM-3PM, due to Hurricane Dorian’s expected impact on our area this week.

All Waccamaw women are invited, as we are hosting the luncheon and getting to know the women from other tribes across the state.

Please RSVP or go to the IWA Facebook page to reply.

Thank you.

Vice Chief Cheryl Cail

![image](https://waccamaw.micro.blog/uploads/2025/a9ce07a0dc.jpg)
