---
layout: post
title: "Waccamaw Indian People stand with Standing Rock #NoDAPL #MniWicon"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/waccamaw-indian-people-stand-with.html
post_id: 5650047
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T20:02:01-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/0325db1232.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/0325db1232.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/0325db1232.jpg
url: /2024/09/27/waccamaw-indian-people-stand-with.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 23, 2016
- 1 min read

![image](https://waccamaw.micro.blog/uploads/2025/0325db1232.jpg)

[#NoDAPL](https://www.waccamaw.org/updates/hashtags/NoDAPL) [#StandingRock](https://www.waccamaw.org/updates/hashtags/StandingRock) [#MniWicon](https://www.waccamaw.org/updates/hashtags/MniWicon) [#WaterIsLife](https://www.waccamaw.org/updates/hashtags/WaterIsLife) [#Resolutions](https://www.waccamaw.org/updates/hashtags/Resolutions)
