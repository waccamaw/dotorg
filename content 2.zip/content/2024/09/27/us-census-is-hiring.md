---
layout: post
title: "US Census is Hiring!"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/us-census-is-hiring.html
post_id: 5650043
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/us-census-is-hiring.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 9, 2019
- 1 min read

To all but especially Native Americans:

The US Census is hiring! Contact them at 1-855-JOB-2020 or online at [https://2020census.gov/en/jobs](http://2020census.gov/en/jobs). Flexible hours, weekly paychecks, paid training, mileage reimbursement. Positions available: recruiting assistants, clerk, office operations supervisor, census field supervisor, enumerator/lister.

I understand that the hourly rate will be from $12 to $17 in SouthCarolina. In North Carolina, it's $12 to $20 and hour.

I don't know the requirements or anything so please call them

directly.1-855-562-2020.

If you are interested, I understand that these jobs will fill quickly.

They will be hiring throughout the census process.

Good Luck!

Buster

[#Census](https://www.waccamaw.org/updates/hashtags/Census) [#jobs](https://www.waccamaw.org/updates/hashtags/jobs)
