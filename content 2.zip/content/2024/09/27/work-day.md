---
layout: post
title: "Work Day 10/6/2018"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/work-day.html
post_id: 5650059
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/work-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Oct 4, 2018
- 1 min read

From B&G Chair Glenn:

Hope all is well & safe from the Hurricane and flood.

There is a work day this coming Sat the 6th. We need to work on the damage on the Drum Arbor, Mow and weedeat all around. Build a new place for the electrical panel at the Drum Arbor, so we can get it off the ground.

We are always open to some food and drinks.

Our Pauwau is next month!!

Thank you all for your time and help, have any concerns, please feel free to contact me at:

(phone or text) 843-602-4194 (if no answer please leave a voicemail)

email) [[email protected]](/cdn-cgi/l/email-protection)

Glenn Cook

[#helping](https://www.waccamaw.org/updates/hashtags/helping) [#volunteer](https://www.waccamaw.org/updates/hashtags/volunteer) [#community](https://www.waccamaw.org/updates/hashtags/community)
