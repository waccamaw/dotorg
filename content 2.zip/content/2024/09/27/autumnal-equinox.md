---
layout: post
title: "Autumnal Equinox 2023"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/autumnal-equinox.html
post_id: 5649937
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T19:06:51-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/74cb691c53.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/74cb691c53.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/74cb691c53.jpg
url: /2024/09/27/autumnal-equinox.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Sep 16, 2023
- 1 min read

The autumnal equinox is 9/23/2023. Come join us!

The autumnal equinox fire ceremony will be held on 9/23/2023 on the tribal grounds at 591 Bluewater Rd, Aynor, SC, 29511, beginning at 7:04 am, as well as noon and a closing ceremony later in the evening. On 9/24/2023, a fire ceremony will be held at sunrise (7:05 a.m.) and noon.

![ree](https://waccamaw.micro.blog/uploads/2025/74cb691c53.jpg)

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [equinox](https://www.waccamaw.org/updates/tags/equinox)
- [waccamaw](https://www.waccamaw.org/updates/tags/waccamaw)
