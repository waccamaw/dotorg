---
layout: post
title: "March 2012 Open Meeting Summary 03022012"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/march-open-meeting-summary.html
post_id: 5649882
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/march-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 24, 2016
- 3 min read

Tribal Open Meeting Summary 03/02/2012 held at the Senior Center in Aynor, SC

1.

CoC Scott, and CM's Susan and Neal present. Pursuant to  the Tribal Constitution page 8 (Article V paragraph B line 8), Chief Hatcher decided that all favorable votes taken will stand as voted and the vote will count.

2.

February minutes read.

3.

Susan motioned to accept; Neal seconded

4.

Susan-yes, Neal-yes, Scott-yes

5.

Financial Report

6.

General Account: $9972.88

7.

Building Fund: $657.65

8.

Online Votes

9.

None taken

10.

Committee Reports

11.

Grants: Michelle

12.

SCAC 3/15: two grants: PW & School Day

13.

Pauwau: Michelle

14.

We have 6 voting members & need Council to appoint one more

15.

Next meeting TBA at Shoney's at 6:30. Once the date is finalized, I'll email everyone

16.

Anyone who has program book ideas, send them to Michelle or Susan

17.

We need everyone to sell ads, not just the committee and not just a couple of people. I will attach a copy of the ad form for people to copy.

18.

Arts & Crafts: Susan

19.

Carol Ann is supposed to be setting up a meeting

20.

Building & Grounds: Neal

21.

Jeff is supposed to have house set down next week

22.

On a Sunday- tar the roof, around $40 per bucket, will get quote

23.

Jeff is supplying rollers

24.

Next projects: floors, carpet, take out wall, etc...

25.

Hope to be in the new building by June

26.

Donnie's Receipts

27.

City Auto Parts: $61.69 check 1419

28.

Susan motioned to accept; Neal seconded

29.

Susan-yes, Neal-yes, Scott-yes

30.

Sunhouse 1: $118.35 check 1420

31.

Susan motioned to accept; Neal seconded

32.

Susan-yes, Neal-yes, Scott-yes

33.

Chief Hatcher

34.

Apologies to new members because we don't have the roll book tonight

35.

Request to pay attorney $1000 if we can afford it

36.

Susan motioned to accept; Neal seconded but plan for future

37.

Susan-yes, Neal-yes, Scott-yes

38.

Newsletter is all electronic

39.

Need to communicate with all members- not just those with email

40.

Perhaps a compromise can be reached

41.

Met with Chaplain of Prisons & John Abrams

42.

No Native American religion in SC prisons allowed

43.

Authorize to use John Abrams to assist with this program

44.

Susan motioned to accept; Neal seconded but plan for future

45.

Susan-yes, Neal-yes, Scott-yes

46.

Neal will volunteer too

47.

Prison Program- hope to make it a statewide program

48.

Met with 2nd Chief of Pee Dee

49.

7 state-recognized tribes & 7 recognized groups

50.

tribes have Native history; groups may not

51.

Both get to vote on Native issues

52.

Going to propose at next Advisory meeting: no more groups

53.

Arts & Crafts said they would do feathers & we need them to do it

54.

Also need one for tribal constables

55.

Seal- $60, letterhead to change fax numbers & envelopes ($200)

56.

Neal motioned; Susan seconded

57.

Susan-yes, Neal-yes, Scott-yes

58.

2 Projects

59.

Donnie's floor

60.

Building fund

61.

Money shifted around; will get fixed

62.

Problem with 2 contractors working together

63.

2 guys passed inspection, were paid, but vents were upside down

64.

Jeff says access doors will be crushed if building is set down on it the way the other guys did it

65.

Says $150-200 to fix

66.

Susan motioned; Neal seconded

67.

Susan-yes, Neal-yes, Scott-yes

68.

Value of building needs to be reported to Iris

69.

Neal motions $20/sq. foot; Susan seconded

70.

Susan-yes, Neal-yes, Scott-yes

71.

Scott to email Iris

72.

Federal Recognition

73.

Still no contract

74.

Interest in amphitheater

75.

Chief of Constables looking for good people

76.

Chief of Constables David: developing screening and policy & procedure manual

77.

Elections

78.

Proposals to go in

79.

DH-09-02-2011-001

80.

Think it's wrong; don't think restricting powers should be in constitution

81.

RP-03-03-2010-01

82.

Elder Doug: Compromise on newsletter- send postcards

83.

Elder Hank: Q: bulk rate?

84.

A: have to pay for so many, including returns

85.

Georgia: Have a fundraising interest

86.

Wanted to check into permissions to do it

87.

Chief Hatcher gave her permission

88.

Elder Doug: Cheryl & Georgia to handle PR

89.

Chief Hatcher gave permissions

90.

Resolution HH-01/03/2012-02: Disbursement Criteria received its 2nd Reading

91.

Susan: Events

92.

Weekend of 3/3: Pauwau in Monck's Corner

93.

Weekend of 3/10: Pauwau in Hardeeville

94.

3/28: Native American Advisory Meeting at USC-Lancaster

95.

May: Tuscarora Pauwau

96.

Elder Hank: introduced Steve & Lori Osborn

Susan  motioned to close the meeting; Neal seconded.

Meeting adjourned 7:55 pm.

Respectfully submitted by Michelle Hatcher on 3/15/12 at 2:26 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
