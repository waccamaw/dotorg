---
layout: post
title: "Veteran Stand Down 10/9/2021"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/veteran-stand-down.html
post_id: 5650044
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/veteran-stand-down.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Oct 4, 2021
- 1 min read

On **October 9th** on the Waccamaw Tribal Grounds (591 Bluewater Road, Aynor SC ). We will host at least three events.

The customers should not need to leave their cars. We expect to have three different automobile lines,  which will lead to:

1. The primary event is assistance to our **Veterans**. MOAA will be there to help, assist and honor our Veterans. Former and present members of all services are welcome and encouraged to come. Veterans, please bring some sort of verification that you are a veteran, because some of the services available are only available to veterans.There will be some gifts, some assistance for services, some gasoline cards, and even some experts on available assets for you. You will be among folks who can help you get repairs for your homes and file for other services that might be available.

2. There will be a food distribution for **anyone** who needs or wants food. United way is providing foods of all types to anyone who needs it. We believe we will have enough people to load the items in each car as the customer drives by.

3. Covid testing and possibly  shots if **anyone** wants one.

There will also be one station where children sized clothing including shoes, and assorted toys are available free to anyone needing them. You will need to dig through the boxes to find the sizes that you need.

The place is 591 Bluewater Road on October 9th beginning at 9:30. Everyone is welcome.

**Volunteers are needed**. If interested in volunteering, please send a note to this email, or just show up at 8:30 Am on the 9th of October.

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [community](https://www.waccamaw.org/updates/tags/community)
- [veterans](https://www.waccamaw.org/updates/tags/veterans)
- [covid-19](https://www.waccamaw.org/updates/tags/covid-19)
- [COVID19](https://www.waccamaw.org/updates/tags/covid19)
