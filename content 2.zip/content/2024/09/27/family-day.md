---
layout: post
title: "Family Day"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/family-day.html
post_id: 5649975
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/family-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 10, 2016
- 1 min read

The Tribal Council has declared February 17th, the date our Tribe became State recognized, as a Tribal holiday.  To celebrate this event, there will be a  Tribal gathering on February 18, 2017 at our Tribal grounds at 591 Bluewater Road, Aynor, SC.
