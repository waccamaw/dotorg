---
layout: post
title: "Coronavirus Precautions"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/coronavirus-precautions.html
post_id: 5649954
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/coronavirus-precautions.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Mar 15, 2020
- 1 min read

From CoC Rick:

To all Waccamaw Members, Due to the Corona Virus and the potential  spread of the virus, all functions and meetings including committee  meetings and work on the grounds are to be postponed until May 1st. I apologize for any inconvenience that may arise from this decision. We must ere to to side of caution. Historically disease and sickness have wiped out tribes in the past, as our numbers are few we simply can't afford the risk.

I ask that members and Tribal government  check your email for any additional changes that may occur. Tribal Council will continue to work via the internet , we will be pursuing means for council to have meetings online until it is safe to hold meetings at our office again.

I urge all members to stay in tune with public broadcast and avoid crowds if possible. Remember to wash hands frequently and or use disinfecting wipes when touching things that others have come in contact with.I hope that this is short lived and all will return to normal sooner than later. Depending on how long it is before the virus subsides the May 1st date could change so again look for announcements. If you have concerns or issues feel free to contact myself or other council members.

Long Live The Waccamaw People,

Chief of Tribal Council Ricky Hudnall

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
