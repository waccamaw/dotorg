---
layout: post
title: "Summer Solstice 6/18/2022"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/summer-solstice.html
post_id: 5650037
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2025-11-22T20:00:29-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/1fdd7c882d.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/1fdd7c882d.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/1fdd7c882d.jpg
url: /2024/09/27/summer-solstice.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jun 8, 2022
- 1 min read

![ree](https://waccamaw.micro.blog/uploads/2025/1fdd7c882d.jpg)

Summer Equinox: Fire ceremony will be Saturday, June 18 at 6:05am, 12:00 noon, and 7:00 pm.  Will you be joining us?

[#savethedate](https://www.waccamaw.org/updates/hashtags/savethedate)

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [solstice](https://www.waccamaw.org/updates/tags/solstice)
