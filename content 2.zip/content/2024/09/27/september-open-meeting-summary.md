---
layout: post
title: "September 2011 Open Meeting Summary 09022011"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/september-open-meeting-summary.html
post_id: 5649868
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 19, 2016
- 2 min read

Tribal Open Meeting Summary 9/02/2011 held at the Tribal Office in Aynor, SC

1. CoC Scott and CM's Neal, Robert, Homer, & Dalton present.

2. August minutes read.

            a. Dalton motioned to accept; Neal seconded

            b. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

3. Financial Report: 2nd Chief Iris

            a. $12,570 in bank

4. Online Votes

            a. Wheel: Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes, [Jeanie-yes]

            b. Grass Seed up to $300

                        1. Neal motioned; Homer seconded

                        2. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

            c. Pond- Current discussion (not online)

                        1. Discussion over nature attraction or trap

                        2. Homer motioned to fill; Dalton seconded

                        3. Homer-yes, Neal-no, Robert-no, Dalton-yes, Scott-yes

5. Committee Reports

            a. Grants: Michelle

                        1. Check our Facebook page for Fourstar link- $1000 chance each month

            b. Building & Grounds: Neal

                        1. first of year- grass

                        2. more dirt and bushes

            c. Arts & Crafts: Dalton

                        1. Committee is deciding how to deal with Webb & associates

                                    1. same as all other members

                        2. probably a pauwau booth, but undecided

            d. Pauwau: Michelle

                        1. We had 2 voting members resign & need Council to appoint 2 more

                        2. Michelle was made Chair

                        3. Budget needs to be approved: $11,106

                                    a. Dalton motioned; Robert seconded

                                    b. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

                        4. Copy of fliers and ad prices given to everyone

                        5. Program Book

                                    a. Governing Body- if you want a different picture, send it to Susan

                                    b. Judge Bernie requested more Veterans program material in book

                                    c. Donnie: Goodson Construction Co. should go in book

                                    d. Council approved material currently in book

                        6. Donnie will get golf cart & return it

6. Resolutions

            a. DH-07-08-2011-001: Tribal Newsletter Costs & Delivery Methods: 3rd reading

                        1. Dalton motioned; Robert seconded

                        2. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

            b. SB-07008-2011-001: Tribal Secretary 2011 Budget Proposal: 3rd Reading

                        1. Dalton motioned; Homer seconded

                        2. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

            c. DH-09-02-2011-001: Amendments to Modify Tribal Council Voting &        Attendance: 1st Reading

                        1. Received an Exception to Policy from Chief Hatcher via phone

                        2. Robert motioned; Homer seconded

                        3. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

            d. SB-09-02-2011-01: Tribal Constable Appointments: 1st Reading

                        1. Judge Bernie: they will have to be bonded

                        2. Homer: is there a meeting attendance requirement?

7. Membership Files

            a. Darin Sutton

                        1. Vote is pending paperwork

                        2. Neal motioned; Homer seconded

                        3. Homer-yes, Neal-yes, Robert-yes, Dalton-yes, Scott-yes

8. Notes from 2nd Chief Susan

            a. Letters of intent due

            b. Jobs Seminar 9/17

9. Upcoming Events

            a. Ongoing-11/12: First People of the Backcountry Exhibit @ Spartanburg        Museum

            b. Spring 2012 GWU Native American Political Leadership Program

10. Homer

            a. Donnie's trailer needs floor

                        1. Neal: get with Wayne on materials & refloor

                        2. Homer motioned to buy supplies

            b. stench coming from duct work

            c. 2nd Chief Iris: decks need done: pulled a nail out

11. Donnie's Receipts

            a. $69.30 for food: Check 1340

            b. $153.76 for gas: Check 1341

            c. $2.48 for grease from Rabon's: Check 1342

Robert motioned to close the meeting; Neal seconded.

Meeting adjourned 8:21 pm.

Respectfully submitted by Michelle Hatcher on 9/28/11 at 4:40 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
