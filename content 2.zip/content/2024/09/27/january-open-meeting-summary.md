---
layout: post
title: "January 2010 Open Meeting Summary 01082010"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/january-open-meeting-summary.html
post_id: 5649874
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- May 31, 2016
- 3 min read

Tribal Open Meeting Summary 1/8/2010 held at the Tribal Office in Aynor

1.

CoC Scott Beaver presented Certificate of Appreciation to Linda  Atkinson for work on PauWau

2.

December Meeting Summary read

3.

Motion to accept the summary made by Neal; second by Dalton

4.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Scott-yes

5.

Minutes accepted by majority

6.

Financial Reports

7.

Donations: Scott (from Jerry)

8.

December: $321

9.

2009: $7576

10.

Iris

11.

2009 cash on-hand: $9989.53

12.

Income including School Day and PauWau: $38, 817.80

13.

Expense including School Day and PauWau: $36,119.54

14.

2009 Net Income: $2698.26

15.

Still outstanding grants

16.

Includes checks for attorney

17.

Committee Reports

18.

Grants: Michelle

19.

SCAC

20.

Final Report sent in

21.

Due to budget cuts, we could receive less than initial grant amount

22.

Contact legislators to help keep arts budget in SC up

23.

Pepsi Refresh Grant

24.

Accepts 1000 ideas per month

25.

$5k-250k rewards

26.

6 categories

27.

Should be community-centered

28.

Arts & Crafts: Iris

29.

Last meeting cancelled due to office painting; not rescheduled

30.

Council needs to see something

31.

PauWau: Linda

32.

Had debriefing at Ryan’s

33.

Need to pick someone for PauWau 2010

34.

Linda will do again if committee chooses

35.

Buster & Susan did a great job for school days

36.

TV13 ad $200 approved by PauWau committee

37.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

38.

Passed unanimously

39.

PauWau 09 closed

40.

Building & Grounds: Neal

41.

Office trailer painted by Deborah & Charles Creech

42.

12 attended work day

43.

1/9- plan to load hay bales to field and burn but will need help

44.

Idea to make office bigger is to get a small double-wide instead of building on to this one

45.

Iris ready to get office set back up to work

46.

Online Votes

47.

Help Buster go to DC

48.

Susan- judge diesel and camping importance

49.

Buster appreciates it, but not necessary

50.

Homer originally said diesel, camping, and meals

51.

Give Buster $500 for DC trip

52.

Motion by Homer; second by Richia

53.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

54.

Passed unanimously

55.

Membership Files

56.

Kenlynn Sports

57.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

58.

Passed unanimously

59.

Teresa Cartwright

60.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

61.

Passed unanimously

62.

Linda Moore Barber (S)

63.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

64.

Passed unanimously

65.

Jerry Wayne Barber

66.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Jeanie-yes, Robert-yes, Scott-yes

67.

Passed unanimously

68.

Deva-Marie Barber

69.

File missing photo and agreement

70.

Tabled

71.

Adrian Jacobs (S)

72.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes

73.

Passed by majority

74.

Checklist for applications to be worked on by Susan, Iris, and Linda

75.

Letters of Intent- 3 Council, 1 Chief position

76.

Census 2010: Max Biggs (Florence Regional Office), Ms. Ramos (Sun News)

77.

SC up for Congressional seat

78.

Phone number & race are the most intrusive questions

79.

Statistical data turned over

80.

Hiring 2,000 from Florence Regional Office

81.

Age 18+, tested and passed, background check

82.

For every 1% who do not respond to the Census, government loses $80-90M

83.

April 1 Census Day

84.

American Community Survey does income now

85.

2nd Chief Iris Ewing

86.

Would like to sponsor Charles Creech for adopted membership

87.

Buster wants to sign-in on this

88.

Jeanie was not present for this, so tabled for the moment

89.

Thank you card from Susan Mack for help we gave her

90.

Ready to get office organized

91.

PC motherboard burned up; Doug said too old to repair

92.

Would like Council to approve limit of $600 for PC

93.

Richia & Iris to make a trip to Costco and relay information to Council for vote

94.

Fireproof cabinets

95.

Limit of $370

96.

Motion by Dalton; second by Neal

97.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes

98.

Passed by majority

99.

Filing Cabinets to be painted black

100.

Neal to paint and sanitize

101.

Neal will need reimbursement on paint depending on price

102.

Richia- Can we scan files and do away with paperwork?

103.

Neal and Craig

104.

Sweat lodge

105.

Spring Bank Retreat

106.

Dot will run sweat lodge for tribe until we have someone certified

107.

Provided link of Fort Jackson

108.

Robert to get up with Craig and Neal

109.

Resolution SB-01-08-001-2010 Submission of Tribal Roll for Federal Petition

110.

Chief Buster Hatcher

111.

Interstate is moving Donnie’s trailer

112.

No offer yet; prefer living quarters

113.

We can move trailer and be reimbursed up to a certain point

114.

Associate Judge David Windburn presented Chief Hatcher with WIP car tag and the tribal office with SC Summary Court Judges Association logos

115.

Intend to put together Waccamaw Police Force

116.

Big copying machine needs repairs

117.

Need 3 Judge’s robes

118.

Judge Bernie Hamilton needs small PC

119.

Resolution HH-01-08-001-2010 Exception to Rule

120.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes

121.

Passed by majority

122.

Linda

123.

Needs okay to get files to work on recognition

124.

Motion by Neal; second by Robert

125.

Neal-yes, Dalton- yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes

126.

Passed by majority

Homer motioned for the meeting to end; Neal seconded.

Meeting adjourned 9:49 pm.

Respectfully submitted by Michelle Hatcher on 1/19/10 at 2:19pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
