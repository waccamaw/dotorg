---
layout: post
title: "June 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/28/june-open-meeting-summary.html
post_id: 5649884
custom_summary: false
summary: ""
date: 2024-09-27T19:00:00-0500
lastmod: 2024-09-27T19:00:00-0500
type: post
url: /2024/09/27/june-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 21, 2018
- 2 min read

Tribal Open Meeting Summary 6/1/2018  held at the Tribal Office in Aynor, SC

1.

CM’s, Mark, Dalton, and Susan present. John served as aCoC. Elders Glenn T, and Ronnie present.

2.

May minutes

3.

Susan-abstain, John abstain

4.

Vote postponed until July meeting/ quorum

5.

Financial Report: Mark A

6.

Presented a monthly ledger of 2018 for the General Fund categorizing income & expenses

7.

Current General Fund: $11.339.73

8.

Building Fund unchanged: $1,917.40

9.

Cemetery Fund: $531.26

10.

Online Votes

11.

5/12 Allow funds for Loris Bog-Off

12.

Dalton: mixed up name; should have been for Aynor Hoe Down

13.

Susan-yes, Mark-yes, Dalton-yes, John-yes

14.

5/23 Allow tribe to pay for a dinner with a possible investor

15.

Susan-yes, Mark-yes, Dalton-yes, John-yes

16.

Old Business

17.

Cemetery Update

18.

Chief: 2C Cheryl is supposed to get an update today with the new deed

19.

John T: think the extra money should be set aside for fences & signs

20.

New Business

21.

Receipts

22.

Fuel $55.04 Check 696

23.

Susan-yes, Mark-yes, Dalton-yes, John-yes

24.

Color Guard uniform ribbons & shirts: $81.43 Check 697

25.

Susan-yes, Mark-yes, Dalton-yes, John-yes

26.

Committee Reports

27.

Buildings & Grounds: Glenn C

28.

Weedeated

29.

Work Day 6/2 with Mike G cooking

30.

Pipe to lay

31.

Arts & Crafts: Susan

32.

6/16 at 2pm: class on chokers

33.

Cost: $40; some money goes back to the tribe

34.

Language: Brandi

35.

Let her know if you are interested so she can set up classes or send Michelle an email

36.

Chief: suggest putting the lessons the website with worksheets for people to email back to you

37.

Pauwau: Michelle/ Glenn C

38.

Red Oak: Jason not responding; will try to contact again

39.

Susan: UMC grant could be for drum lessons

40.

Hog Heaven fundraiser: 6/12: 8 tickets left @ $20 each; half goes back to tribe

41.

Volunteers: email the PW Committee

42.

We will have 1 vendor to provide volunteer meals: Smokin’ Carolina

43.

Brandi: I’ve volunteered to cook for School Day

44.

Chief: If you put it up, tear it down; leave the grounds as you found them

45.

Chief

46.

Color Guard: Shane S, John T, Alan F, Ronnie F

47.

SCIAC wants to do a Veterans’ Branch: need a chair

48.

Shane wants the position

49.

Mike G volunteered

50.

People will be interviewed

51.

CMA

52.

Survey said they would do the hiring/ firing even if we sent someone up there; she wanted a way to discipline people- I told her to notify me

53.

CMA received a grant to show tribes how to grow crops

54.

I don’t want people putting us into a grant that they we didn’t agree to

55.

John T: do we have recourse?

56.

Chief: it’s in negotiation; we can write the grantor & request our name be taken off

57.

SCIAC would like to have a Voter’s Drive: need people to vote

58.

Art: game parts will require a hunter’s permit to put on the art

59.

Elders

60.

Dalton: have newsletters to fold, tape, & stamp; read to Council

61.

Alan F: solstice date?

62.

John T: 6/23

63.

Chief: introduced Dr Tracey from HGTC: Anthropology professor

Dalton motioned to close the meeting; Mark seconded.

Meeting adjourned 7:50 pm.

Respectfully submitted by Michelle Hatcher on 6/21/18 at 11:36 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
