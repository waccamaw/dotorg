---
layout: post
title: "#RIPCharles"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/ripcharles.html
post_id: 5650024
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/ripcharles.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 5, 2017
- 1 min read

It is with a deep sadness that I tell of another Waccamaw Elder that passed yesterday, Elder Charles Creech. He was a strong supporter of the tribe and was a big part of school day. He was part of the snares and traps area and went as far and made animals to be used in the demonstrations. You could always go to Elder Charles if you needed advise for anything. There will be no services or visitation per his wishes. Per the family, donations can be made to the Waccamaw Indian People, PO Box 628, Conway, SC 29528

He is now walking with the ancients.

[#RIP](https://www.waccamaw.org/updates/hashtags/RIP)
