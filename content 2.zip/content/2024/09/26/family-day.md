---
layout: post
title: "Family Day 2023"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/family-day.html
post_id: 5649976
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/family-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Feb 14, 2023
- 1 min read

SAVE THE DATE - FEBRUARY 18, 2023

[#Waccamaw](https://www.waccamaw.org/updates/hashtags/Waccamaw) Indian People Family Day

Please come out to the Tribal Grounds and join us in the celebration

of our Tribe and our fellowship. We start the day with our Sunrise Fire Ceremony,

also the Noon and Closing Fires. Lunch will be provided after the Noon

Fire Ceremony.

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [event](https://www.waccamaw.org/updates/tags/event)
- [community](https://www.waccamaw.org/updates/tags/community)
- [FamilyDay](https://www.waccamaw.org/updates/tags/familyday)
