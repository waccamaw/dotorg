---
layout: post
title: "Special Needs Fishing Day Update"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/special-needs-fishing-day-update.html
post_id: 5650030
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2025-11-22T20:00:09-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c1814cd118.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e730d23f24.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5e7734c91f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9905d67bea.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/806fac45cb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9738245b7d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7707282d64.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/017d7464a3.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae15e3cd68.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0ccbe5e93d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4d269414d3.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/757af36101.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/329e58647b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1688fbc54d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/946d181705.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/56c9f6451d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0bb8cf6a87.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/69da87c385.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2c83568e75.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ed773bd419.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b2311df618.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f5723a36dd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cc0666c562.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5061320776.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f2eace963b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ded922075e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1f15c803eb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d59098d05c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fcd6e1cfbc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/64de64f9a0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9fb2fe2ec0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4869597a90.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7ae98db855.jpg
url: /2024/09/26/special-needs-fishing-day-update.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Apr 15, 2017
- 2 min read

![image](https://waccamaw.micro.blog/uploads/2025/c1814cd118.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/c1814cd118.jpg)

SNFD1

![image](https://waccamaw.micro.blog/uploads/2025/e730d23f24.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/e730d23f24.jpg)

SNFD2

![image](https://waccamaw.micro.blog/uploads/2025/5e7734c91f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5e7734c91f.jpg)

SNFD3

![image](https://waccamaw.micro.blog/uploads/2025/9905d67bea.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9905d67bea.jpg)

SNFD4

![image](https://waccamaw.micro.blog/uploads/2025/806fac45cb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/806fac45cb.jpg)

SNFD5

![image](https://waccamaw.micro.blog/uploads/2025/9738245b7d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9738245b7d.jpg)

SNFD6

![image](https://waccamaw.micro.blog/uploads/2025/7707282d64.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7707282d64.jpg)

SNFD7

![image](https://waccamaw.micro.blog/uploads/2025/017d7464a3.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/017d7464a3.jpg)

SNFD8

![image](https://waccamaw.micro.blog/uploads/2025/ae15e3cd68.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ae15e3cd68.jpg)

SNFD9

![image](https://waccamaw.micro.blog/uploads/2025/0ccbe5e93d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/0ccbe5e93d.jpg)

SNFD10

![image](https://waccamaw.micro.blog/uploads/2025/4d269414d3.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4d269414d3.jpg)

SNFD11

![image](https://waccamaw.micro.blog/uploads/2025/757af36101.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/757af36101.jpg)

SNFD12

![image](https://waccamaw.micro.blog/uploads/2025/329e58647b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/329e58647b.jpg)

SNFD13

![image](https://waccamaw.micro.blog/uploads/2025/1688fbc54d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1688fbc54d.jpg)

SNFD14

![image](https://waccamaw.micro.blog/uploads/2025/946d181705.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/946d181705.jpg)

SNFD15

![image](https://waccamaw.micro.blog/uploads/2025/56c9f6451d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/56c9f6451d.jpg)

SNFD16

![image](https://waccamaw.micro.blog/uploads/2025/0bb8cf6a87.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/0bb8cf6a87.jpg)

SNFD17

![image](https://waccamaw.micro.blog/uploads/2025/69da87c385.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/69da87c385.jpg)

SNFD18

![image](https://waccamaw.micro.blog/uploads/2025/2c83568e75.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2c83568e75.jpg)

SNFD19

![image](https://waccamaw.micro.blog/uploads/2025/ed773bd419.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ed773bd419.jpg)

SNFD20

 A message from CoC Rick Hudnall about today's event:

Hello and Happy Easter Weekend to everyone,

Today the Waccamaw Indian People along with the help of The Crossway Church Archery and Motorcycle Ministries , the Bass Pro Professional Crappie Team ,Horry County Fire Department, South Carolina Department of Natural Resources, the folks from Special Needs Family Day and many other volunteers hosted the third annual Special Needs Fishing Day. The fishing was nothing short of amazing . A special thanks to Roger Barber for making the fishing outstanding . Participants enjoyed fishing , archery , target shooting , pictures with Chief Hatcher and lunch prepared by our own Councilman Mark Ammons. Thanks to Don and Toni Collins of the Bass Pro Crappie Fish Team its not every day folks get the chance to fish with a pro. Councilwoman Susan Hatcher who worked registration and helped make sure all the photos taken by Jessie Hudnall were hot off the press for the participants.  Thanks to those who helped at the fishing station John Turner  along with Wayne Turner  weighed and logged all the fish that were caught. Grandfather showered us all today with many blessings and sure many felt his presence today.  All that were at the grounds today left the grounds better for it . The smiles on the faces of the ones fishing and working was priceless.If I can offer any wisdom to my Tribe ,friends and my extended family it would be to give back every chance you can. I know in my heart and I promise you Grandfather will reward you seven fold. As for me I know my life is much richer after today. For those who couldn't make it today I am truly sorrow that you missed such a powerful day. Please forward this to anyone I missed or that you think would like to read it. Again thanks to all that helped pull off a great day for some less fortunate folks.

Thanks to all and Walk Softly,

Chief of the Waccamaw Tribal Council

Update from Tribal Secretary Michelle: Thanks to Jerri Hunter for providing pictures to me for our Special Needs Fishing Day 2017! As more pictures become available, we will post them!

![image](https://waccamaw.micro.blog/uploads/2025/b2311df618.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b2311df618.jpg)

SNFD21

![image](https://waccamaw.micro.blog/uploads/2025/f5723a36dd.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f5723a36dd.jpg)

SNFD22

![image](https://waccamaw.micro.blog/uploads/2025/cc0666c562.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/cc0666c562.jpg)

SNFD23

![image](https://waccamaw.micro.blog/uploads/2025/5061320776.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5061320776.jpg)

SNFD24

![image](https://waccamaw.micro.blog/uploads/2025/f2eace963b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f2eace963b.jpg)

SNFD25

![image](https://waccamaw.micro.blog/uploads/2025/ded922075e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ded922075e.jpg)

SNFD26

![image](https://waccamaw.micro.blog/uploads/2025/1f15c803eb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1f15c803eb.jpg)

SNFD27

![image](https://waccamaw.micro.blog/uploads/2025/d59098d05c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d59098d05c.jpg)

SNFD28

![image](https://waccamaw.micro.blog/uploads/2025/fcd6e1cfbc.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fcd6e1cfbc.jpg)

SNFD29

![image](https://waccamaw.micro.blog/uploads/2025/64de64f9a0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/64de64f9a0.jpg)

SNFD33

![image](https://waccamaw.micro.blog/uploads/2025/9fb2fe2ec0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9fb2fe2ec0.jpg)

SNFD30

![image](https://waccamaw.micro.blog/uploads/2025/4869597a90.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4869597a90.jpg)

SNFD31

![image](https://waccamaw.micro.blog/uploads/2025/7ae98db855.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7ae98db855.jpg)

SNFD32

[#community](https://www.waccamaw.org/updates/hashtags/community) [#SpecialNeeds](https://www.waccamaw.org/updates/hashtags/SpecialNeeds) [#Fishing](https://www.waccamaw.org/updates/hashtags/Fishing)
