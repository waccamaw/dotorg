---
layout: post
title: "COVID-19 Testing on Waccamaw Tribal Grounds"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/covid-testing-on-waccamaw-tribal.html
post_id: 5649955
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/covid-testing-on-waccamaw-tribal.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 14, 2020
- 1 min read

**4 days until August 18th**!

From Chief Hatcher:

Tanakahey y'all:

Just a reminder. We will do a free to the public, [#Covid19](https://www.waccamaw.org/updates/hashtags/Covid19) test on the 18th of August from 8 am until 11 am on our tribal grounds.

That's Tuesday, one week from today, if you get this on Tuesday the 11th of August.

I have only a couple of volunteers. I may need more but we won't be in the swabbing or recording part of it.

As I understand it, all our people will be doing is directing the cars through the site.

Wear a mask, show up on the grounds at 7:30 AM and we'll get it done.

Send this out and post as you can and will.

If you want to be tested, show up about 8 am and follow instructions from the volunteers.

If you are good at making signs, please make a few with arrows pointing and the words "Free Covid Test" .

Please let me know if you want to help.

[https://www.facebook.com/WaccamawIndianPeople/posts/3613613512006711](https://www.facebook.com/WaccamawIndianPeople/posts/3613613512006711)

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [event](https://www.waccamaw.org/updates/tags/event)
- [community](https://www.waccamaw.org/updates/tags/community)
- [COVID19](https://www.waccamaw.org/updates/tags/covid19)
