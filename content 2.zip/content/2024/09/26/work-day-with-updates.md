---
layout: post
title: "Work Day 3/23/2019 with Updates"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/work-day-with-updates.html
post_id: 5650060
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/work-day-with-updates.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Mar 18, 2019
- 2 min read

From Building & Grounds Chair Glenn C:

This coming Saturday 23rd we will start on the new wiring on the dance circle.  830 to until. This may run into Sunday also. I plan to start to get the grounds prepared on Friday.  Hope you can come out to help. This is s major project and will take time and labor. Everyone can help in some way. Don't forget the grub. Thank you all for your help and support.

**Update 1:** 3/18/2019: From Chief Hatcher:

The Tribe's vendor's circle has been failing lately. Every time we have a pauwau, we have problems.

Our ground's manager, Glenn Cook,  will be attempting to do some repairs on it this weekend. Saturday, the 23rd.

If you can, please plan to come for a couple of hours and help. I suspect there will be food and fun but we will stay focused on repairs.

Please, let Glenn (email in the "to" box above) know you can and will help. Anyone can help somehow, going to get parts, helping with the food or just to show that you care. So, if you like for the Tribe to stand by you, why not stand by the tribe.

I did get another 24 wool blankets and Glenn will have them on the grounds, available. If you need one.  First Come first served.  They are free.

Thank you!

Buster

**Update 2**: 3/27/2019: From B&G Chair Glenn C

Last weekend, we had a good turn out with help. We got almost all the wire in the ground and covered up. We worked until dark Sat and Sun. I personally did not leave the grounds until 8:30 pm Sunday and Marion did not leave to go home until Monday morning. Thank you all that came out to help with this. It is/was a big project and couldn't have done it without you all.

Marion C, John T, Larry Jacobs, Ronnie F, Rick H, Allen F, Neal R, Neal friend Chris, Cheryl C, Marie H, Starla V, Mike G, Metisa G, CJ C and Larry C for all your help!! Please forgive me if I left anyone out.

 Workday this coming Saturday 30th & Sunday 31st we will be working on connecting the new wiring around the dance circle.  830 to until. This will require you to know how to wire a receptacle and pull a little more wire, water pipe connections, raking, digging a stump. Hope to see you this weekend...  Thank you all for your help and support

[#community](https://www.waccamaw.org/updates/hashtags/community) [#WorkDay](https://www.waccamaw.org/updates/hashtags/WorkDay) [#BG](https://www.waccamaw.org/updates/hashtags/BG)
