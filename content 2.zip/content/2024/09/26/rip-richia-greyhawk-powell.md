---
layout: post
title: "#RIP Richia Greyhawk Powell"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/rip-richia-greyhawk-powell.html
post_id: 5650022
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2025-11-22T19:50:09-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
- https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
- https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1d5751032b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1bf5bc02b1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b0bfeb7188.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bc821f9a30.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/aad7cdfcc4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ff50136bae.jpg
url: /2024/09/26/rip-richia-greyhawk-powell.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Aug 19, 2021
- 2 min read

**Reba McCaffrey**: 8/14/2021: This morning my beautiful baby girl[ ](https://www.facebook.com/richia.greyhawk?__cft__[0]=AZVf1pNV4vqjDg165xZQoiCx38oKkXc3JP7TgHxZ5wQ5hO6Ld40PcbNrJCZ0z8c-dSh3yxmpRnBgXfFXHNo8rLh7w-GnbkPZMnAEv8eg-AjXqmJ68zWoOI_OvyKVkAY2U-E&__tn__=-)[Richia Greyhawk](https://www.facebook.com/richia.greyhawk?__cft__[0]=AZVf1pNV4vqjDg165xZQoiCx38oKkXc3JP7TgHxZ5wQ5hO6Ld40PcbNrJCZ0z8c-dSh3yxmpRnBgXfFXHNo8rLh7w-GnbkPZMnAEv8eg-AjXqmJ68zWoOI_OvyKVkAY2U-E&__tn__=-) , was called to be among the dancers in the heavens and stars. I know how many people loved her posts. I have no updates and no pending information at this time.  Her beautiful voice and smile and her red hair are forever with us. I just wanted to let those that loved her and shared her life to remember her as  sharing her life with you.

Fly high my baby girl far away from the struggles of this life. I love you to eternity and beyond

**Thomas Newman Powell**: Richia was my safe place. Someone I could tell anything too. I’m so glad that I had the chance to spend my life so far with her as she helped raise me as her own. She taught me a lot of lessons and a lot of recipes. I pray that someday I can have half of the heart and compassion she had towards others.

**Alan Faver**: My beautiful wife/angel has gone to be with the great creator she was loving and the protector of all animals including me love her forever

**Chief Hatcher**: Tanakahey:

I know that most of you know already that my beautiful niece, Richia (Powell) Grayhawk walked into eternity Saturday, the 14th of August 2021.

What I do know is that she loved, unconditionally. She loved animals, people, and trees. She raised a fuss a few years ago, when the Council decided to fill in the pond because it had fish in it.

The Council relented!

For reasons unknown to me, she thought I was a hero. I am proud to call her niece and to have had my little piece of her heart!

In her list of wishes, she asks that anyone who wants to honor her life, not to kill a beautiful flower but to make a donation to the Waccamaw Indian People in her honor.

Richia has been cremated and her ashes will be at Goldfinches'  funeral home in Conway, during the family visitation on Friday the 20th from 5 until 7 pm.

There will also be a memorial on the Tribal Grounds on August 28 beginning at 10 Am.

You are welcome to attend either or both.

**Services**:

[Richia Greyhawk](https://www.facebook.com/richia.greyhawk?__cft__[0]=AZXlrHfPit2jUn07SpvfNw0LyrmMdL1-svf6H1yus_Is-_JL4NYkl6JNXiohTCMXkpGBwXCQjR7GtcFvLw_KVM_PZKutxf4rpQ9GY9svpTv20Wr4zMESHZRcQra1ia09ZPo&__tn__=-) Powell visitation will be 5 to 7pm at Goldfinch in Conway Friday 20th. There will be a Memorial service Aug 28th at 10am at Waccamaw Tribal Grounds in Aynor.

There will be a church service at the Myrtle Beach Christian Church , however, that day is pending. I have to get with my minister and church family but will update as soon as we work the day out.

My thanks go to Alan Faver For including me in her arrangements. Our grief is different. A mother's love is beyond explaining. Alan loved her with his deepest love. The pain is real for all of us. Pray for us all as we make this journey. Prayers of peace and love for everyone. Thank you all for caring

![image](https://waccamaw.micro.blog/uploads/2025/1d5751032b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1d5751032b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1bf5bc02b1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1bf5bc02b1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b0bfeb7188.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b0bfeb7188.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/bc821f9a30.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/bc821f9a30.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/aad7cdfcc4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/aad7cdfcc4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ff50136bae.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ff50136bae.jpg)

There will also be a memorial on the Tribal Grounds on August 28 beginning at 10 Am.

Tags:

- [RIP](https://www.waccamaw.org/updates/tags/rip)
