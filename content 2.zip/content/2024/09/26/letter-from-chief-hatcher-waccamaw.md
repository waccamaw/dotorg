---
layout: post
title: "Letter from Chief Hatcher: Waccamaw Pauwau 2018"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/letter-from-chief-hatcher-waccamaw.html
post_id: 5649992
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/letter-from-chief-hatcher-waccamaw.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 18, 2018
- 4 min read

There are less than three months before the Waccamaw Pauwau. It will be held on the 3rd and 4th of November, rain or shine. As always, it will be the first Saturday and Sunday in November. Local schools will be in attendance for educational presentations the Thursday (1st) and Friday (2nd)  prior to the Pauwau. We will continue our tradition of providing the best educational and festive experience in South Carolina. Our Pauwau has been called "the premiere Pauwau in the state"!

The Pauwau Committee and the School Day coordinator, as usual, have done an excellent job putting the events on. These dedicated people begin planing and organizing the next pauwau and school event, almost as soon as the current event ends. They meet monthly, beginning in December, the month after the event is over.

Your Tribal Council, meets monthly, as well to keep the tribe honest and functional. Every expenditure, is reviewed at every meeting, in public and every vote is done in public, or reviewed in public. They are as transparent as water. What is amazing is they do what they do, for free.  The building and grounds, committee, work tirelessly making things last on the grounds, keeping the buildings and grounds looking good and functioning. File keepers, sit behind a desk, monitoring membership, making ID cards, filing documents, and on and on, all for love of their people, not for a single dime.

For the pauwau, I want to say, early enough, that I'd sure like to see our people come together this year, as better than they have ever done before. I'd really like to see some new faces there, doing things seting up and tearing down and other things necessary, other than attending. Although, attending is also important! The Golden Eagle family, not even members, come every year and kick butt in work to make our pauwau the best in the state. Thanks to the whole beautiful family

No one gets paid in the tribe. All of the Council, Elders, Chiefs and other managers, do what they do, because they are proud of their tribe and their families. We have an individual and a some members that work almost every weekend on the grounds, in the sun, doing physical labor. They provide their own tools and most of the supplies to work for the rest of us who have no skills (maybe no interest) in that area. Thanks to them!

Every Weekend after the Tribal Meeting, is a work day, where everyone is invited to come help. We will have supervisors there with the know how, if you can do minimal things to help, It would sure make an impact on their moral, if you just show up to show some support. We have people who live five miles from the grounds who were show up for anything except to the actual event.

This year, I am asking that the pauwau Committee designate a pin, ribbon, or some sort of thing that can only be worn by Waccamaw, so everyone whom attends will know you are a member of the host tribe. Step up and be proud of who you are and what we have accomplished. Hopefully, these pins will be different colors or maybe it should be a feather to show how much the wearer has done for their people.Even our judges, come and work  as well as our constables.

Also, There are roughly 400 members of Waccamaw, but we usually only have about 15 ads in our program booklet. If each of us, would sell one ad, we would have the pauwau almost paid for before we even start. If you do a lot of business with local (to you) business, just ask then to purchase an ad. You will be surprised at how easy it is. There are a couple of folks who have sold ten - fifteen ads by them selves. JS, yours truly! and others.The prices are not high so we need a lit of them to pay for the booklet.

The Wednesday, prior to the Pauwau, is our set-up day. We work for about half a day and then we eat. Its not hard and its not strenuous. Plan to be there. I believe you will actually enjoy it. After the set up, we usually have some guitar music, food, and plenty of ugly in our elders and Chief!  Remember, this will be twenty six years; a quarter century. Lets make it even bigger.

So mark your calendars now. Wednesday October 31, 09:00 Set up.   Thursday November 1st, and Friday November 2nd,  08:00 School Days. (usually over about noon)  Saturday and Sunday November 3rd and 4th, (9:00) Pauwau.We need ticket takers, parkers, runners, helpers, escorts, trash detail, (no bathrooms, they are managed by a contractor). We need servers in the kitchen, cooks, foods, whatever, you can imagine.

Volunteers should contact Michelle at  [[email protected]](/cdn-cgi/l/email-protection). Email is  always best but if you need a real people call the Tribal Office Number. 843-358-6877.  For ads contact Linsey Stamp at [[email protected]](/cdn-cgi/l/email-protection), for work on the grounds please contact Glenn Cook at [[email protected]](/cdn-cgi/l/email-protection).

I will be there, throughout. See you there!

Buster

[#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau)
