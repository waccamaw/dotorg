---
layout: post
title: "May 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/may-open-meeting-summary.html
post_id: 5649883
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/may-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- May 24, 2019
- 5 min read

Tribal Open Meeting Summary 5/3/2019  held at the Tribal Office in Aynor, SC

1.

CM’s Dalton, Alan, Susan, Robert, John, and CoC Rick present. Elders Doug, Becky, and Avalene present. 2C Cheryl present.

2.

Financial Report

3.

General Fund: $9,210.19

4.

Building Fund: $450.55

5.

Online Votes

6.

4/11 Allow PW Committee up to $500 for fundraiser tickets

7.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

8.

4/25 Accept April Meeting Summary

9.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

10.

Old Business

11.

Donnie’s AC

12.

Ductwork needs repairing

13.

New Business

14.

Committee Reports

15.

Buildings & Grounds

16.

Wayne T, Ronnie H, Chris H, Donnie H cleaned pond & weedeated

17.

Wayne T donated aquatic Roundup

18.

Thanks to all who helped with the Dance Circle- electric all around

19.

Water run to the pond; someone took the sink (have purchased one)

20.

Water & electric to Fire Circle

21.

Pipe ran for hookups to Tractor Shed/ where Chief parks his RV

22.

Water leaks in office- probably have to replace all of the pipes

23.

John T: thanks to Glenn C & his brother for cooking during Work Day

24.

2C Cheryl: Wayne T left a voicemail saying he sprayed; also left baits for rats

25.

Possible to get a construction office to turn into bathrooms; 2C Cheryl to talk to the man (Mr. Frye)

26.

He has a 10x45, 8x45; 2 of each; he said he would work with us on payment

27.

Use as a bathroom or museum

28.

He said he would remove things here if needed; delivery & setup

29.

Elder Becky: didn’t Charles Creech draw up plans for the bathhouse?

30.

Chief: museum

31.

2C Cheryl: it would help with year-round RV camping

32.

Arts & Crafts: Susan

33.

Sent the last manual to Council to review

34.

Looking for more items from the manual

35.

John T: think Council should take over the certification process

36.

Motion to make Tribal Council responsible for certifying artists; Robert seconded

37.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

38.

Dalton: we should rebuild the committee ASAP

39.

Pauwau: Dalton

40.

Tidal Wave Fundraiser

41.

200 tickets; they buy back all unused tickets

42.

If we sell them all, we make $1000

43.

2C Cheryl/ Dalton: was the check given to the car wash company signed or blank?

44.

Susan: the amount isn’t filled in because you settle up at the end of the fundraiser

45.

HGTC Fundraiser: 2C Cheryl

46.

Meet with Joe Bonaparte & Chef Umberto next Thursday to discuss our responsibility as far as food, donations, etc…

47.

They will promote and assist with ticket sales

48.

Would like to establish for Native students

49.

2C Cheryl motioned that the tribe be willing to procure donated foods & establish a scholarship of $500 out of the profits gained from ticket sales; Dalton & John T seconded & third

50.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

51.

John T: what happens if food isn’t donated?

52.

2C Cheryl: it’s our responsibility to get food, but they know where to get it

53.

2C Cheryl: we can also do silent auctions & have drum & dane there like with Scouts presentation

54.

Continue selling ads

55.

John T: any thoughts of putting ads on the website?

56.

Dalton: haven’t heard back from Doug; will try again

57.

Still looking for volunteers

58.

Submit stories for next year’s book now

59.

Glenn C: this year’s theme: Family

60.

We would like to get new pictures

61.

John T: who polices campsites to make sure everyone has paid?

62.

Susan H: most spots are taken up by volunteers

63.

Chief Hatcher: if you recognize the man from last year who didn’t pay, make him pay this year for both years

64.

Dalton: we also give a list of names to the gate

65.

Patty: you can give them an 8x10 camping sheet embossed with the logo

66.

Rick H: we’ll discuss it online

67.

Socastee Heritage Festival

68.

Donations received

69.

Attendance was down because of other things going on in area

70.

Starla V: PW Cards (business card reminding people 1st weekend on Nov)

71.

Also suggested adding a $1 off coupon if presented at the gate

72.

1 card, 1 person

73.

Lumbee PW: Susan H

74.

They have price listing, including weekend pass

75.

Drum: Glenn C

76.

No response from Kaya; will talk to him at Lumbee Pauwau

77.

Resolution: DH-03-01-2019-001: Firearms Restriction Exemption for Concealed Weapons Permit Holder: 3rd reading

78.

Susan: Are you going to put this out to the public?

79.

Alan F: add it as an attachment when the summary goes out?

80.

Robert-yes, Susan-yes, Alan-yes, John-no, Dalton-yes, Rick-yes

81.

2C Cheryl

82.

Played Sumac (sp?) video- organizational item like Sales Force

83.

Sales Force training was $4000, so we didn’t use it

84.

Different packages

85.

Silver: $95/month: 1 user + Cloud

86.

Gold: $90/ month: 2500 contacts, Multi-user, No Cloud

87.

Can add Cloud for an additional $50/month

88.

Dalton: send Council a link to to review it

89.

Membership file to review; file was never up for a vote

90.

Susan H: whose is it?

91.

2C Cheryl: Heath Dawsey- no response since 2016

92.

Susan H: pretty sure it was inactive because his card expired

93.

Chief: Marie has 30 years of business management experience; could help come up with procedures

94.

Federal Recognition Petition

95.

Went over criteria

96.

It will add more items to a file, including birth certificate & name change forms

97.

Show from 1900-present in 10-20 year increments depending on the narrative

98.

Chief Hatcher: 25CFR83.7 has been revised several times

99.

Criteria (e) will be the most difficult if they want us to establish from first contact (around 1689)

100.

Going through Congress: they could limit or take your rights

101.

Going through BIA: could take 20 years

102.

After reviewing the petition, they are supposed to send a list of things that need to be worked on/ changed

103.

Patty: does Catawba have someone who will look at ours?

104.

2C Cheryl: theirs is different; got it through lawsuit

105.

Chief: have Council & ELders recognition committee meet to discuss it in June

106.

2C Cheryl: drafted letters to the State Preservation Office concerning land/ graves

107.

Copy given to Council

108.

To be used to stop the excavation of remains

109.

Chief

110.

JR-HH-05-03-2019-001: Appointment of Waccamaw Genealogist: 1st Reading

111.

Will make Patty Burns the tribal genealogist

112.

SCIAC would like to have a meeting in our office

113.

Still need Council pictures for the wall

114.

Chief was nominated for being a lead veteran & other things because of tribal accomplishments

115.

Ceremony 6/30

116.

Have to do reports

117.

1 is the IRS postcard form

118.

We need something in writing designating who does the reports

119.

Elders

120.

Glenn T still sick

121.

Elder Doug: Elder Dan sends his apologies

122.

Would like to rent the office 8/10-12

123.

Elder Becky: donation from Powers Pharmacy: $100 for Fishing Day

124.

Donating 2 rods & reels for Fishing Day

125.

Rick: made a paddle for Reel Fix because of their help over last 3 years

126.

Susan H: $100 received from Horry Electric for Fishing Day

127.

2C Cheryl: office cleaned; workable

128.

Glenn C: website information is outdated

129.

Mike G: nominated for award concerning Desert Storm veterans

130.

John T: real estate box for flyers for people coming out here

131.

Recycle box needed

132.

Membership fees: approximately 278 voting members

133.

1/3 volunteers; still not getting money

134.

Receipts

135.

Rick Hudnall: $140.70 Check 739

136.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

137.

Wayne T: $50 Check 740

138.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

139.

2C Cheryl: $60 Check 741

140.

Robert-yes, Susan-yes, Alan-yes, John-yes, Dalton-yes, Rick-yes

141.

Fuel: $53.08 Check 743

John motioned to close the meeting; Robert seconded.

Meeting adjourned 9:00 pm.

Respectfully submitted by Michelle Hatcher on 5/24/2019 at 2:09 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
