---
layout: post
title: "Waccamaw Indian People Archiving Project"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/waccamaw-indian-people-archiving-project.html
post_id: 5650046
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2025-11-22T20:01:56-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/b5d3f9df8c.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/b5d3f9df8c.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/b5d3f9df8c.jpg
url: /2024/09/26/waccamaw-indian-people-archiving-project.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 9, 2022
- 1 min read

Updated: May 10, 2022

If you are a member and interested in assisting with the project, please contact 2C John Turner at: [[email protected]](/cdn-cgi/l/email-protection)

![ree](https://waccamaw.micro.blog/uploads/2025/b5d3f9df8c.jpg)

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [native](https://www.waccamaw.org/updates/tags/native-1)
- [waccamaw](https://www.waccamaw.org/updates/tags/waccamaw)
