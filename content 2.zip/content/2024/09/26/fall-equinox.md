---
layout: post
title: "Fall Equinox"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/fall-equinox.html
post_id: 5649973
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/fall-equinox.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 14, 2017
- 1 min read

The Fall Equinox celebration has been scheduled for Saturday October 7th at the Waccamaw Tribal Grounds. A sunrise ceremony, a noon ceremony and a closing ceremony will be observed. Please make plans to attend.

If there are any questions or concerns please contact the

Waccamaw Fire Keeper Robert Benton or CoC Ricky Hudnall.  Hope to see you all there.

[#ceremony](https://www.waccamaw.org/updates/hashtags/ceremony) [#equinox](https://www.waccamaw.org/updates/hashtags/equinox)
