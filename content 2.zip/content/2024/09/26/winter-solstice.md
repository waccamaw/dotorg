---
layout: post
title: "Winter Solstice 2017"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/winter-solstice.html
post_id: 5650053
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/winter-solstice.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Dec 12, 2017
- 1 min read

From CoC Rick:

On Saturday December 16th, the Waccamaw Indian People will celebrate the 2017 Winter Solstice. Ceremonies will begin at sunrise with a fire ceremony at our Fire Circle on the Tribal Grounds. Firekeepers Robert Benton and Marion Craddock will be directing the ceremony. There will also be a noon ceremony and a closing ceremony that afternoon. All members and any guest they wish to invite are welcome. I hope to see you all there as we celebrate the change of season. I would also like to wish everyone a Merry Christmas and a Happy New year.

Remember what the Christmas season is for , always give back and try to make a difference in the lives of others.

Walk Softly,

Chief of Tribal Council

Ricky Hudnall

[#ceremony](https://www.waccamaw.org/updates/hashtags/ceremony) [#solstice](https://www.waccamaw.org/updates/hashtags/solstice)
