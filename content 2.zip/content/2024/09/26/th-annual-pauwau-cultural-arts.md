---
layout: post
title: "24th Annual Pauwau & Cultural Arts Festival"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/th-annual-pauwau-cultural-arts.html
post_id: 5650039
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2025-11-22T20:01:36-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/0d8037b888.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/0d8037b888.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/0d8037b888.jpg
url: /2024/09/26/th-annual-pauwau-cultural-arts.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 10, 2016
- 1 min read

![image](https://waccamaw.micro.blog/uploads/2025/0d8037b888.jpg)

Our 24th Annual Cultural Arts Festival & Pauwau will be held Saturday, November 5th and Sunday, November 6th, 2016 at the tribal grounds, 591 Bluewater Rd, Aynor, SC.  We invite you to join us for the event.  The gates will open at 11:00 AM on both days.  There will be two Grand Entries on Saturday, held at 1:00 PM and 6:00 PM.  On Sunday there will be one Grand Entry held at 2:00 PM.

Our arena participants are:

Host Drum
 *Edisto River Singers*

Master of Ceremonies
 *John Blackfeather*

Arena Director
 *Doug Logan*

Lead Female Dance
 *Aki Day Hedgepeth*

Lead Male Dancer
 *Frederick Hawkins*

Adults $7.00, Seniors 60 and over $4.00, Children 6 and under free and 7-14 $4.00

HOST MOTEL

Econo Lodge

1101 Church St.

Conway, SC  29526

843 248-2285

Mention the Pauwau for the discounted rate of $53.00 + tax

For more information, please contact the Pauwau Committee by email: Jennifer Hatcher: [[email protected]](/cdn-cgi/l/email-protection)

Susan Hayes-Hatcher: [[email protected]](/cdn-cgi/l/email-protection)

Or by phone: (843) 358-6877.

[#community](https://www.waccamaw.org/updates/hashtags/community) [#volunteer](https://www.waccamaw.org/updates/hashtags/volunteer) [#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau)
