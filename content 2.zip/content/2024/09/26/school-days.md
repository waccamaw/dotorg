---
layout: post
title: "School Days 2016"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/school-days.html
post_id: 5650027
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/school-days.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 10, 2016
- 1 min read

Our next School Days event is currently scheduled for Thursday, November 3rd and Friday, November 4th, 2016 at the tribal grounds, 591 Bluewater Rd, Aynor, SC.  For more information on how to register for this event, please contact Susan Hayes-Hatcher at [[email protected]](/cdn-cgi/l/email-protection).

[#community](https://www.waccamaw.org/updates/hashtags/community) [#Schools](https://www.waccamaw.org/updates/hashtags/Schools)
