---
layout: post
title: "Tribal Elections 2020"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/tribal-elections.html
post_id: 5650041
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/tribal-elections.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Nov 25, 2020
- 1 min read

From Chief Hatcher:
Elder Dan and I met at the Tribal office today and finished the count of the last six votes.
The six ballots that were in question were avowed to be valid by our file keeper Starla and Glenn Cook.
This is the final tabulation and The Elders will be sending a certification soon.
For Chief of Tribal Council.
CM Hatcher 20 votes

CoC Hudnall 17 votes

For Council
Dalton Hatcher 33
Rick Hudnall 31
Glenn Cook  33
R. Benton     26
Marie McCall 31

Effective December 5th, 2020, the members of Council will be

Rick Hudnall
Dalton Hatcher CoC
Glen Cook
Marie McCall

The Elders will be issuing an official election summary soon.
Walk easy

Tags:

- [Elecctions](https://www.waccamaw.org/updates/tags/elecctions)
