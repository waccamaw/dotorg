---
layout: post
title: "September 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/september-open-meeting-summary.html
post_id: 5649877
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 21, 2018
- 2 min read

Tribal Open Meeting Summary 9/7/2018  held at the Tribal Office in Aynor, SC

1.

CM’s,  Robert, John, Dalton,  and CoC Rick present. Elders Dan, Doug, Ronnie, and Becky present.

2.

Financial Report

3.

General Fund: $11,799.15

4.

Building Fund: $1,969.12

5.

Online Votes

6.

8/23 Accept August Meeting Summary with change

7.

Robert-yes, John-yes, Dalton-yes, Rick-yes

8.

Old Business

9.

Cemetery Update

10.

Rick to Elder Dan: we need a current list of trustees

11.

Resolution: DH-04-06-2018-001 Subject: Exemption of membership fees for age, length of service, or large donations: Third Reading

12.

Not enough response online to discussion

13.

Dalton: a lot of the responses were things already approved

14.

John T :Rick’s suggestion was to simplify it by combining items

15.

With Susan’s response on hardship: I would leave it at renewing because poverty levels can change

16.

Make a lifetime card a renewal every year or every two years

17.

Instead of printing cards, put stick on it like car tags

18.

Tabled for further discussion

19.

Mike G: 3 months ago, Chief mentioned voter’s registration, it can be setup here & done online

20.

Mike G: flags should be available next month

21.

New Business

22.

Receipts

23.

Fuel: $122.03 Check 703

24.

Robert-yes, John-yes, Dalton-yes, Rick-yes

25.

Committee Reports

26.

Buildings & Grounds: Michelle (via Glenn’s email)

27.

No work day 9/8

28.

Pauwau: Michelle

29.

Looking for volunteers

30.

More trifolds are ready

31.

Alan: is a single-page flyer available?

32.

Michelle: need Susan to update it

33.

John T: will there be music playing early?

34.

Dalton: yes, & some from Edisto will be here to switch on/ off with Red Oak

35.

Drum: Rick

36.

Talked to Warpaint, but no time yet

37.

Constable Membership

38.

John T: do they have to be SLED-certified?

39.

Dalton: think so

40.

Memberships we have open files for

41.

Eric Morgan

42.

Joseph Carter

43.

Both tabled until Chief present to make them Honorary members

44.

Elders

45.

Get Letters of Intent into office if you plan to run for Council or Chief positions

John motioned to close the meeting; Dalton seconded.

Meeting adjourned 7:01 pm.

Respectfully submitted by Michelle Hatcher on 9/22/18 at 12:18 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
