---
layout: post
title: "Elections"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/elections.html
post_id: 5649967
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/elections.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Feb 15, 2020
- 1 min read

If you plan to run for Council, we have four spots open: Rick Hudnall, John Turner, Dalton Hatcher, and Robert Benton. Please send your letter of intent by 2/29/2020. Remember, if you plan to run for Chief of Council, you must declare it. We will post the letters of intent on the website and on Facebook as well as send them by email.
