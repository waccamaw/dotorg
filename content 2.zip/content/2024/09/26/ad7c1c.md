---
layout: post
title: "January 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/27/ad7c1c.html
post_id: 5649888
custom_summary: false
summary: ""
date: 2024-09-26T19:00:00-0500
lastmod: 2024-09-26T19:00:00-0500
type: post
url: /2024/09/26/ad7c1c.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jan 26, 2018
- 7 min read

Tribal Open Meeting Summary 1/12/2018  held at the Tribal Office in Aynor, SC

1.

CM’s Susan, Mark, Dalton, Jeania, and John present. John served as ACoC.  2C Cheryl served as proxy for Robert and also for Jeania once she left. Elder Dan present.

2.

December minutes with changes to 5(c)(i)(6)(q), 5(c)(vi)(b) made

3.

Dalton motioned to accept; John seconded

4.

Jeania-yes, Susan-abstain, Robert (2C Cheryl)-yes, Mark-yes, Dalton-yes, John-yes

5.

Financial Report

6.

General Fund: $12,664.66  (as of 1/11/2018 on CNB site)

7.

Building Fund: $2086.94 (as of 1/11/2018 on CNB site)

8.

Cemetery Fund: $531.26

9.

Old Business

10.

Waccamaw Family Day 2/17

11.

Alan: with 40-50 people, we can easily fo Low Country Boil with $200

12.

Mark: Rick wanted BBQ, but Low Country Boil is cheaper

13.

2C Cheryl: have donated deer meat for burgers

14.

Mark: we can do tea, lemonade, water for drinks

15.

John: activities: cornhole

16.

Cemetery Update

17.

2C Cheryl: meeting with attorney Tuesday at 2pm; Council needs to vote on how to proceed

18.

Chief: according to maps, cemetery is on Dog Bluff, but we think it’s on Jordanville Rd

19.

Deed was cut to Ms. Turner in 1987 and surveyed in 1987 that they wouldn’t accept

20.

John: they say we have 2 acres; we just don’t know where

21.

Chief: there’s a thing called adverse possession: no claim since 1987; we were there then with no dispute

22.

Elder Dan: some knew it was ours in 1950’s

23.

John: when was the first church there?

24.

Chief: 1800’s

25.

John showed new map proposal with 2 options for Council to review

26.

CoC Rick’s PW Concerns

27.

Elections done at the Pauwau

28.

Elections guidelines fall on the Elders to establish

29.

Michelle: which they did and Council dismissed

30.

Need Elders to write guidelines for elections for next open meeting

31.

Mark: concern about letting people vote at the PW is that some people will vote twice

32.

Susan: the Elders will see the ID# when they count the ballots

33.

Chief: At Pauwau, Elders are going to be on the gate, too busy to do anything else

34.

Susan: Rick said candidates should be able to politic  at the Pauwau

35.

Chief: can’t on the mic

36.

Free Passes to Pauwau

37.

Pauwau Committee and Governing Body get passes

38.

Susan: 4 passes each for Council meetings is a drop in the bucket compared to $10/hr wage set, not to mention work days at 3+ hours each; it says thank you

39.

Chief: it’s important to show respect

40.

2C Cheryl: free passes can increase attendance- free people can bring along people who otherwise wouldn’t have come

41.

Charles H: everyone should pay

42.

All members free contradicts passes

43.

There’s already a method to let people in free

44.

Mark: this is our major fundraiser for the year and people know that

45.

Dalton: if the people who live close by aren’t showing up for any other events, $7 isn’t going to do that

46.

Chief: could raise membership fees by $7

47.

Mark: leave it as-is

48.

Dalton motioned to give CoC 20 passes for Work Days

49.

John: should have a form signed by their supervisor

50.

Michelle: we have it, have used it, rarely filled out

51.

John: With the form, CoC wouldn’t need passes

52.

Michelle: Most work is also given in exchange for membership fees. Do they want to exchange their membership fee or gate pass

53.

Getting enough people to handle the Pauwau

54.

Chris H wants to be Arena Director

55.

Mark: he should shadow our Arena Director to see how we want it done; go to other Pauwaus to for confidence and practice

56.

Susan: he needs to shadow ours & David C said he’s more than happy to help him

57.

John: once confident, you can take over

58.

2C Cheryl: John A would like to stay on as MC and shadow John Blackfeather

59.

John: if interested in a position, let us know, so we can get you taught

60.

2C Cheryl: we also need someone to help fill Ronnie, Bill, & Susie’s spots too

61.

Electrical issues with vendor circle

62.

Currently in a flood zone

63.

Suggestion was to move it to the back 40 to higher ground

64.

John presented a proposal on how it would look

65.

Chief: looks good with the drawing

66.

John: going to have to talk to the county because the map says the back 40 is also in a flood zone

67.

We also need to figure out how to pay for it

68.

Chief: we can’t use the land, but we can get a loan

69.

Usually put it in my name with a commitment from people to send $15-20/ month to pay for it

70.

Dalton: are you leaving the fire circle where it is?

71.

John: thinking closer to the building, but up to the firekeeper

72.

John: would you be okay with giving $3000 of Pauwau proceeds to the loan?

73.

Chief: no, because it may rain one year, we won’t make any money, and still have to pay out to demonstrators

74.

Susan: emails sent out for positions like HM/ HL

75.

Rick in Work Day expressed that the Pauwau Committee should bring the names to Council and then Council decide the demonstrators

76.

If we bring it to Council and they don’t like it, we can run out of time. This PW group has worked well together

77.

Dalton & Susan: to 2C Cheryl, I give you my proxy and ask that you vote your conscience on Pauwau issues

78.

John: who is ultimately responsible for finances?

79.

Chief: Tribal Council

80.

John: then why is there a problem? Rick is looking for due diligence

81.

2C Cheryl: Council’s job is to approve/ not approve the budget, not micromanage the committee; things have to be done in a timely manner & while we wait for Council to say yes or no, demonstrators could book elsewhere

82.

Earl was brought up. Do you think that turning the Firekeeper position over to Robert during the Pauwau means he shouldn’t be paid?

83.

John: we need to see your process

84.

Dalton: you need to plan for the eventuality that you don’t approve any names

85.

The committee begs people to come to meetings. 2 Council members and a 2C are on the committee. It’s not hidden from the government.

86.

Goal is to plan and execute the pauwau; Council has other things to handle

87.

John: send us minutes as to why they are chosen

88.

2C Cheryl: you’re missing the point; that’s micromanaging every detail- it’s no longer a committee

89.

Susan: Rick doesn’t want to pay $400 + room for HM/ HL; food costs  + hotel would leave them with next to nothing

90.

2C Cheryl: it essentially implies that you don’t trust the committee to do its job

91.

Dalton: budget needs to come sooner, but without names, revise every month as necessary

92.

Chief: how many have been to a Pauwau? (hands raise)

93.

Which is best? (some say ours)

94.

If it isn’t broke, don’t fix it.

95.

Alan: if Council puts faith in the committee and approves the budget they have to trust the people on the committee to do their job, else put new people in

96.

Chief: If they brought you 3 names, how are you going to know who those 3 people are?

97.

If you don’t like their pick, you send the Chair a message and then that name doesn’t come back again

98.

Approve the budget, not the names

99.

Mark: we’re looking at lowering costs; man counted 27 cars that left Sunday because drum wasn’t drumming

100.

Dalton: that was 1 incident at 1 Pauwau

101.

John: if they screw up, they shouldn’t come back

102.

Chief: that could happen to you too

103.

John: helps to have the budget early

104.

Mark: need 2 drums: Edisto gets paid the same for School Day as Pauwau

105.

John: you’re paying for half a drum

106.

Jeri H: blanket dances for guest drums & Burke would like to come back to be HM

107.

Susan: Chief mentioned no second grand entry on Saturday

108.

Because Chiefs, dignitaries leave; MC will still call their names

109.

Susan: just do flags

110.

Friday night grand entry for vendors

111.

Jeri H: doesn’t make sense

112.

New Business

113.

Antifreeze for tractor: $12.00 Check 522

114.

Appoint Mark as bookkeeper

115.

Dalton: do you know how to do it?

116.

Mark: my wife will help me; I didn’t ask for it; Rick asked me too

117.

John motioned to accept; Dalton seconded

118.

Jeania (2C Cheryl)-yes, Susan-yes, Robert (2C Cheryl)-yes, Mark-yes, Dalton-yes, John- yes

119.

Committee Reports

120.

Arts & Crafts

121.

Nothing to Report

122.

Pauwau: Michelle

123.

Nominated Chair: Michelle

124.

Need Council to approve Glenn C as a voting member to replace Georgia

125.

Jenaia (2C Cheryl)-yes, Susan (2C Cheryl)- yes, Robert (2C Cheryl)-yes, Mark-yes, Dalton (2C Cheryl)-yes, John-yes

126.

Meetings are second Wed in Jan/ July & second Thurs in rest of the year

127.

Looking for volunteers & older pictures

128.

Drum

129.

Practice soon with Glen, Alan, Phil

130.

Chris H: son & I will too

131.

Misc

132.

Glen T: concrete idea: try before the next meeting

133.

Susan: Larry J called about a horse trail: wanted to do horse barrel ride

134.

Charge admission, charge for food

135.

John: need someone to write up something more detailed about it

136.

John: Chris H: sewage grinders: they do finance

137.

Get us an estimate with details

138.

2nd Chiefs

139.

Membership File: Bryan Turner: expired 2016

140.

Glen T: what does that mean for Bryan?

141.

Dalton: it’s currently in limbo

142.

Mark motioned to accept the file as full; Dalton seconded

143.

Jenaia (2C Cheryl)-yes, Susan (2C Cheryl)- yes, Robert (2C Cheryl)-yes, Mark-yes, Dalton (2C Cheryl)-yes, John-yes

144.

Send me an email with address/ phone change, or expired card issue

145.

Chief

146.

Are you caught up on ID cards?

147.

2C Cheryl: no; some things are in wrong files & not working on new files

148.

7 files that I don’t have a physical file for

149.

Have volunteers willing to write for a grant but need a proposal from Council allowing it

150.

Would like it to be in the area of language: hopefully done online, learn 10 or so words / week

151.

Meeting with candidates running for governor (at separate times), needs lots of tribal members to attend

152.

Alan & Joey: plan to get chairs of committees of the bills to move through the legislature

153.

Bill to stop further group formation

154.

Hunting/ fishing licenses

155.

Game/ animal parts

156.

Native American Advisor on CMA

157.

Write 1 paragraph letter to the state reps in support of these

158.

Management: there’s a tribe that throws people out when they don’t like what people do- we can’t do that

Mark motioned to close the meeting; John seconded.

Meeting adjourned 9:04 pm.

Respectfully submitted by Michelle Hatcher on 1/26/18 at 12:38 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
