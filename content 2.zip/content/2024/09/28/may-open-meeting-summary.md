---
layout: post
title: "May 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/may-open-meeting-summary.html
post_id: 5649900
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2024-09-28T19:00:00-0500
type: post
url: /2024/09/28/may-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- May 19, 2018
- 2 min read

Tribal Open Meeting Summary 5/4/2018  held at the Tribal Office in Aynor, SC

1.

CM’s Jeania, Robert, Mark, Dalton, and Rick present. Elders Glenn T, Doug,Ronnie, and Becky present. 2C Cheryl present.

2.

Financial Report

3.

General Fund: $11,364.79

4.

Building Fund: $1,917.40

5.

Cemetery Fund: $531.26

6.

Online Votes

7.

4/19 Cemetery Vote: whether to accept the proposal

8.

Jeania-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

9.

4/22 Accept April Minutes

10.

Jeania-yes, Robert-yes, Mark-absent, Dalton-yes, Rick-yes

11.

Old Business

12.

Finder’s Fee proposal: 2C Cheryl

13.

Doesn’t look good; terms aren’t good for us

14.

Website lists their name in different spellings

15.

Westgate

16.

Has means to invest and could do horses & tipis in several forms (traditional through glamping)

17.

Resolution: DH-04-06-2018-001 Subject: Exemption of membership fees for age, length of service, or large donations: Second Reading

18.

Please send emails to Dalton to discuss

19.

Jeania: why don’t we not have membership fees?

20.

Dalton: I have considered it, but we have more kids on the books than grandparents and have to think about 7 generations unborn

21.

New Business

22.

Receipts

23.

Fuel: $81.33 Check 693

24.

Jeania-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

25.

Solstice: $39.32 Check 694

26.

Jeania-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

27.

Events

28.

Horse Ride: Larry J

29.

It was a nice day; 34 people attended

30.

Mark: gout our name out there; thanks to Larry and all who helped

31.

Fishing Day: Rick

32.

Successful, but not as many kids as last year; thanks to all who helped

33.

Committee Reports

34.

Buildings & Grounds: Glenn C

35.

Thanks to Larry J, John T, and others for helping with WOrk Day

36.

Most of the gable is done; worksheet has been updated

37.

Work Day 6/2

38.

Mike Graham will be cooking

39.

Last month’s minutes- it was Charles Hughes’ tractor (5(C(i)(9)), April Meeting Summary)

40.

Elder Doug: the cemetery tombstones need to be acid-washed

41.

Glenn C: you have to be careful doing that

42.

Pauwau: Michelle/ Glenn C

43.

Narrowing down drum choices

44.

Looking at Red Oak and Warpaint

45.

6/12 Hog Heaven Fundraiser; Georgia is selling tickets

46.

Looking for Volunteers for Pauwau2018

47.

Budget in Google Drive; updated monthly for Council review

48.

Socastee Heritage Festival: $22 raised; Blue Angels flying overhead; flyers given out

49.

Drum

50.

Took it to Socastee Heritage Festival; Chris & Carson had something come up

51.

Raffle for lawn mower drawn: Dave Cox won & was notified during the meeting

52.

2nd Chief Cheryl

53.

Governing Body, please verify your contact information on these sheets to be submitted to the State

54.

JR-HH-05-01-2018-001: Appointment to External Position

55.

Appoint Ms. Jerri Hunter to serve as the Riverkeeper & Representative for the SCIAC Women’s Alliance

56.

Dalton motioned; Mark seconded

57.

Jeania-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

58.

Elders

59.

Museum Article: Honoring the Warrior Tradition of Native Americans by Dave Spiva

60.

Museum scheduled to be unveiled in 2020

61.

Link to article (pg 36 in VFW Magazine): [digitaledition.qwinc.com/publicati...](http://digitaledition.qwinc.com/publication/?i=486403&ver=html5&p=38#){%22page%22:%2238%22,%22issue_id%22:486403}

62.

Brandi Rayne Merithew Al-amasi

63.

If interested in learning language, let her know so she can create lesson plans

Dalton motioned to close the meeting; Mark seconded.

Meeting adjourned 8:30 pm.

Respectfully submitted by Michelle Hatcher on 5/19/18 at 8:55 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
