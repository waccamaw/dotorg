---
layout: post
title: "Equinox/ Solstice Ceremony"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/equinox-solstice-ceremony.html
post_id: 5649968
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2024-09-28T19:00:00-0500
type: post
url: /2024/09/28/equinox-solstice-ceremony.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Aug 10, 2016
- 1 min read

Equinox/Solstice Ceremonies

Robert Benton will be officiating our Autumn Equinox on September 25th on our tribal grounds.  The ceremonies will be at Sun up, Noon and Sunset.  Hope to see you there!

[#equinox](https://www.waccamaw.org/updates/hashtags/equinox) [#solstice](https://www.waccamaw.org/updates/hashtags/solstice)
