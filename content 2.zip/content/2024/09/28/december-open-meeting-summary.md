---
layout: post
title: "December 2017 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/december-open-meeting-summary.html
post_id: 5649899
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2024-09-28T19:00:00-0500
type: post
url: /2024/09/28/december-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Dec 11, 2017
- 7 min read

Tribal Open Meeting Summary 12/01/2017 held at the Tribal Office in Aynor, SC

1.

CM’s John, Mark, Dalton, Robert, Jeania, and CoC Rick  present. Elder Dan present. 2C Cheryl served as a proxy for Susan and arrived late.

2.

Financial Report

3.

General Fund: $15,149.46  (as of 11/30/2017 on CNB site)

4.

Building Fund: $1986.94 (as of 11/30/2017 on CNB site)

5.

Cemetery Fund: $531.26

6.

Online Votes

7.

11/4 Pay fuel bill $72.17 Check 513

8.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes

9.

11/17 Accept & Approve October Meeting Summary

10.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes

11.

11/30 Give $100 each to Donnie & Michelle for tribal work

12.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes

13.

Old Business

14.

Elder Position: Interview Becky Smith

15.

Jeania- are you prepared for the position

16.

Becky-yes

17.

Mark: based on attendance & speaking to her previously, no questions

18.

Dalton: same, she attends regularly

19.

Rick: Will you be okay around these old guys?

20.

Becky-yes

21.

Rick: motion to accept Becky as an Elder; Mark seconded

22.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes

23.

Rick swore Becky into Elder position

24.

Chief of Elders to ask Avalene to resign after checking into whether Chief Hatcher has sent her a letter

25.

Mark: possible to have honorary Elder positions? Leave the name, but none of the responsibility?

26.

New Business

27.

Waccamaw Family Day 2/17

28.

Alan: looking into Low Country Boil & BBQ prices

29.

Mark: and chips & hot dogs for children

30.

Mark to also check prices of a pig with sides

31.

Need drinks (cans, lemonade, water, or tea)

32.

Games: cornhole, horseshoes, karaoke, egg toss

33.

Time: 11-5:30, lunch at 1

34.

2C Cheryl to bring fireworks

35.

Entertainment by Chief Hatcher on guitar

36.

Craft lessons with Susan?

37.

2C Cheryl says yes

38.

Fishing at the pond

39.

Archery tournament for kids & adults: $50 prize for each?

40.

Elder Dan: do jewelry as prizes for 2nd & 3rd place

41.

Rick: motion for the tribe to allot $100 in total prize fund for Family Day; Mark seconded

42.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes, 2c Cheryl (Susan)-yes

43.

Facebook Event post

44.

Michelle: don’t just click “like,” be sure to share it so it reaches more people

45.

Elder Dan: why not have someone do face painting?

46.

Alan: have people drumming

47.

Rick: what about pony rides?

48.

Mark: we would need to rope off the area and make sure someone is watching at all times

49.

Email your friends

50.

John: create a call chain

51.

2C Cheryl: could do a robocall

52.

Dalton: in the future: free to members, $5 for non-members?

53.

Winter Solstice 12/21 (Thurs)

54.

Public ceremony 12/16 (Sat)

55.

Elder Becky: suggest everyone bring their own lunch

56.

Rick: the tribe could provide breakfast; others to bring covered dish to be shared by everyone

57.

Mark: sausage & pancakes: cheaper than biscuits

58.

Committee Reports

59.

Pauwau: Michelle

60.

Had our outbrief meeting, which is to be more fully discussed in January at open meeting

61.

Next Meeting 1/10 at 6pm at tribal office

62.

Looking for Volunteers for Pauwau2018

63.

Looking for older Pauwau pictures for program book

64.

Mark: please research last 5 years pauwau profits

65.

Rick: went around to vendors & this is what they said

66.

Sewage Dumping station

67.

Bath house

68.

More drums

69.

Upset about having to go to separate vendors for food & drink

70.

That was done so it wouldn’t impede the tribe’s ability to make money from drinks

71.

Want a Grand Entry on Friday

72.

Michelle: the vendors fussed about the extra cost for being open on Friday

73.

There should be no bare feet in the circle; children should be more supervised

74.

Less storytelling time

75.

2C Cheryl: that was, in part, because John didn’t have someone sitting with him to keep him on schedule

76.

More Missing Man Ceremonies

77.

Michelle: we have to work around Rolling Thunder’s schedule for that

78.

Better handicap parking: should be front row at vendors

79.

More P-o-P close to the circle

80.

Michelle: there were some on the other side of the vendors & at the fire circle

81.

Background music when drums are at rest

82.

Smudging at the dance circle

83.

Michelle, Mark: it’s smudged at sunrise before anyone enters

84.

John: we could do a second smudging to share our culture

85.

Elder Dan: can Chris H work with an Arena Director

86.

Michelle: he can shadow the Arena Director & learn this year

87.

Mark: Chris goes to events throughout the year; could be ready by next Pauwau

88.

Need Chris’ input at the Pauwau meeting

89.

Michelle: we have asked for more people to step up for positions so we could keep it local

90.

2C Cheryl: motion to assist Chris with attending Pauwaus & learning

91.

John: he’s already going to these events

92.

Handwashing stations

93.

Mark: they can be gotten from the same place as P-o-P

94.

Offer a trade blanket for vendors: vendors swap items

95.

Let members in for free

96.

Mark: they have to work 4+ hours to get in for free

97.

Dalton: they get into Family Day for free

98.

Michelle: there are solstices, equinoxes, and Family Day for them to get in free

99.

Mark: a member told a senior that they got a discount on books

100.

Dalton: every person on Council gets 4 passes; use them or give them away

101.

Donnie: that needs to stop too

102.

John: if it weren’t a fundraiser, would we have a Pauwau?

103.

Dalton: I imagine if we were rich tomorrow, yes

104.

John: then it could be argued they should get in free

105.

Michelle: it takes $5-6000 to pay basic utilities and administration costs

106.

That doesn’t take into account other projects we want to get done

107.

Drum: possible Northern drum, more drums, young drum seeking playtime

108.

Mark: there was miscommunication among the Edisto guys

109.

Pernell Richardson was a suggestion

110.

Jeania: why not play games during slower times?

111.

Alan: charge for a blowgun contest

112.

Dancers: feed them

113.

Michelle: we do; they are told when they register to go to the office if they want a free meal

114.

Rick: is there a gourd dancer?

115.

Mark: do a friendship dance during downtime

116.

Dancers: let them in free?

117.

Michelle: no, everyone pays at the gate. If they register in regalia, they can request their gate fee back

118.

This year, money was only paid back to tribal members

119.

Keep dancers in the circle more; more dance time

120.

Rick: Council should have more say so on committee decisions

121.

Dalton: Council can attend the meeting

122.

If Council is making the decisions, there’s so sense in having the committee

123.

We have begged for people to attend these meetings

124.

Mark: have asked Susan before an open meeting what’s been going on with the PW committee & was asked to come to the meeting

125.

Rick: we shouldn’t have to come to the meeting

126.

Michelle: that’s why committees give a report each month by resolution

127.

John: can I get a copy of the PW agenda & minutes?

128.

Michelle: yes, until now, not one of you have asked to ever see the summaries from PW meetings

129.

Friday night vending

130.

Michelle: again, vendors fussed about the extra cost for being open on Friday for School Day

131.

What is closing time? Arrange a time between 7-11?

132.

Michelle: it’s typically gone until dark, depending on how big of a crowd is there

133.

Each vendor can close up at whatever time they want

134.

Water hookups to every vendor site

135.

Mark: food court needs it

136.

It requires more work around the circle

137.

View of the circle

138.

Majority of vendors want it, but know it’s not always possible

139.

Majority want a circle lineup

140.

High scores on feelings about members

141.

7-8 out of 10 on PW as a whole

142.

Liked Grand Entry

143.

Most attend 1-25 PW’s each year

144.

Membership Dues

145.

Rick: can Jeania take care of that?

146.

Mark: think checks need to go to her address before being deposited

147.

Michelle: every deposit slip has a breakdown of how the money is allotted & for whom

148.

Council Tasks from Rick

149.

John is to look into PW research & development

150.

Mark is to do financial reporting

151.

Rick: he’ll need the banking account information

152.

Larry: horse poker rides in March: $10/ rider

153.

Fundraiser

154.

Flyers, advertising, chicken bog

155.

Rick: motion that we budget up to $500; Robert seconded

156.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes, 2c Cheryl (Susan)-yes

157.

Golf cart batteries

158.

Mark: motion to buy the batteries we didn’t buy last year

159.

Dalton: how much were they again?

160.

Mark: $500-600

161.

Dalton seconded

162.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes, 2c Cheryl (Susan)-yes

163.

Push lawnmower isn’t being used

164.

Mark: Donnie suggests selling it

165.

Rick: do a raffle on it with a limit of 1000 tickets

166.

Alan to check on legal issues

167.

Mark: Make sure it has a new battery to help with ticket sales

168.

Mark motioned to purchase black & white tickets for up to $75; Rick seconded

169.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes, 2c Cheryl (Susan)-yes

170.

2C Cheryl: motion to put the raffle money towards Special Needs Fishing Day; Mark seconded

171.

Mark-yes, Robert-yes, Dalton-yes, Jeania-yes, John-yes, Rick-yes, 2c Cheryl (Susan)-yes

172.

Mark: Doug & Jewell raise money for Fishing days

173.

Rick: we’re not stepping on them; we’ll use it all

174.

Rick: if we don’t have something to sell in a few months, buy something to raffle

175.

Mark: members & PW demonstrators are getting up in age; need to look for younger people

176.

Drum: Rick, Alan, Glenn playing in Jan

177.

Dalton: can you drum during PW?

178.

Rick: we need more at drum & more practice

179.

Mark: can I practice with you on drum on Saturdays after the open meeting?

180.

Rick: yes

181.

2C Cheryl: Cemetery Report

182.

Told Terry that Council isn’t happy with the report

183.

Probably have to file with Master-in-Equities court

184.

Rick: has Chief Hatcher refiled on the roof?

185.

Other Pauwau Outbrief items not mentioned

186.

Doing away with the second Grand Entry on Saturday because dancers/ people are leaving

187.

Need more Native recipes

188.

Mark: spoke with Paul & he said he will cook next year

189.

Rodlyn was upset about not being allowed to draw the numbers for the dance raffle

190.

She may not be back next year

191.

She needs to talk to Council

192.

Mark: she has a conflict of interest

193.

John: what was the issue?

194.

Michelle: her daughter competes

Mark motioned to close the meeting; John seconded.

Meeting adjourned 9:36 pm.

Respectfully submitted by Michelle Hatcher on 12/9/17 at 5:38 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
