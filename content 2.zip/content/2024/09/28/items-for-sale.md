---
layout: post
title: "Items for Sale"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/items-for-sale.html
post_id: 5649991
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2025-11-22T19:19:10-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/8c09ad174d.jpg
- https://cdn.uploads.micro.blog/272201/2025/25ebc0685c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb2db927fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/c2a2e2c3cc.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/8c09ad174d.jpg
- https://cdn.uploads.micro.blog/272201/2025/25ebc0685c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb2db927fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/c2a2e2c3cc.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/8c09ad174d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/25ebc0685c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb2db927fc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c2a2e2c3cc.jpg
url: /2024/09/28/items-for-sale.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 4, 2021
- 1 min read

Updated: Apr 19, 2021

The tribe has several items for sale:

Logoed T-shirts (size M-4x): $20 each or 2/$30

Logoed Coozies: $3 each or 2/$5

Plastic Logoed Cups: $3 each or 2/$5

23rd Annual Pauwau Program Books: $5 each

Contact Filekeeper Starla at [[email protected]](/cdn-cgi/l/email-protection#4c1f382d3e202d2829297a7d0c2b212d2520622f2321) for availability. There will be a shipping and handling fee added to your total.

![ree](https://waccamaw.micro.blog/uploads/2025/8c09ad174d.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/25ebc0685c.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/fb2db927fc.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/c2a2e2c3cc.jpg)
