---
layout: post
title: "Work Day 6/8/2019"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/work-day.html
post_id: 5650058
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2024-09-28T19:00:00-0500
type: post
url: /2024/09/28/work-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 6, 2019
- 1 min read

From B&G Chair Glenn Cook:

This coming Sat 8th 830am. Will be working on the office water  and weedeating. Do are in need of some water sealer for the benches. Hope to see you there.

[#WorkDay](https://www.waccamaw.org/updates/hashtags/WorkDay) [#BG](https://www.waccamaw.org/updates/hashtags/BG) [#volunteer](https://www.waccamaw.org/updates/hashtags/volunteer)
