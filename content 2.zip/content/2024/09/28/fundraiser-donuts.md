---
layout: post
title: "Fundraiser: Donuts!"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/fundraiser-donuts.html
post_id: 5649980
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2025-11-22T19:07:14-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/f528041ddc.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/f528041ddc.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/f528041ddc.jpg
url: /2024/09/28/fundraiser-donuts.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jun 8, 2023
- 1 min read

[#Fundraiser](https://www.facebook.com/hashtag/fundraiser?__eep__=6&__cft__[0]=AZUZtsJ_QcivVshgnkqf2-FnIJ3EkdUij_se5RxQaJpDGKf3vlCC7KT6bQgnpMJQn6vbvZVu5I5OSGYTnat8FbMgkxqZWwS6mz5ncc5sQtcZOLi4NEJlyZ7uTAWdLrISj296aoi1Kx3TG3jrMWtTufeDAzEn6OX4b1dHDFYnR6aQinBD6qP56Fa3BK1hiJ6Femk&__tn__=*NK-R) for the month of June at any Krispy Kreme in the US. Follow the directions in the link to help us meet our goal.

[https://www.groupraise.com/offer-campaigns/10957-waccamaw-indian-people-krispy-kreme-digital-dozens](https://www.groupraise.com/offer-campaigns/10957-waccamaw-indian-people-krispy-kreme-digital-dozens)

![ree](https://waccamaw.micro.blog/uploads/2025/f528041ddc.jpg)

Tags:

- [Fundraiser](https://www.waccamaw.org/updates/tags/fundraiser)
- [Donuts](https://www.waccamaw.org/updates/tags/donuts)
