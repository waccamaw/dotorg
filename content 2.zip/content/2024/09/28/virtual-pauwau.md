---
layout: post
title: "Virtual Pauwau 2021"
microblog: false
guid: http://waccamaw.micro.blog/2024/09/29/virtual-pauwau.html
post_id: 5650045
custom_summary: false
summary: ""
date: 2024-09-28T19:00:00-0500
lastmod: 2024-09-28T19:00:00-0500
type: post
url: /2024/09/28/virtual-pauwau.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Nov 30, 2021
- 1 min read

Updated: Dec 1, 2021

Introduction to Waccamaw Virtual Pauwau

Hunting and Trapping

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [event](https://www.waccamaw.org/updates/tags/event)
- [VirtualPauwau2021](https://www.waccamaw.org/updates/tags/virtualpauwau2021)
