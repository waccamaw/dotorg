---
layout: post
title: "Canadian Film Day 4/17/2024"
microblog: false
guid: http://waccamaw.micro.blog/2024/02/20/canadian-film-day.html
post_id: 5649948
custom_summary: false
summary: ""
date: 2024-02-19T19:00:00-0500
lastmod: 2024-02-19T19:00:00-0500
type: post
url: /2024/02/19/canadian-film-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Feb 20, 2024
- 1 min read

One of the masters of Canadian documentary cinema, Alanis Obomsawin has spent decades chronicling the injustices visited on First Nations communities, creating a remarkable body of work. In her latest film, she digs into the difficult history of Treaty 9, the infamous 1905 agreement in which First Nations communities allegedly relinquished their sovereignty over their traditional lands.

Setting the film against the recent resurgence of First Nations activism (Chief Theresa Spence’s hunger strike and the Idle No More movement), Obomsawin interviews legal, historical and cultural experts — as well as people whose ancestors were present when the treaty was signed — to explore some fundamental questions about Canada’s relationship with our First Nations.

Movie Trailer: [[www.youtube.com/watch](https://www.youtube.com/watch?v=Lst4meSmVck](https://www.youtube.com/watch?v=Lst4meSmVck))

We’d love to have you join us! As soon as I know more, I will share with you!

Best,Carolyn
