---
layout: post
title: "Waccamaw Pauwau 2024"
microblog: false
guid: http://waccamaw.micro.blog/2024/10/31/waccamaw-pauwau.html
post_id: 5650050
custom_summary: false
summary: ""
date: 2024-10-30T19:00:00-0500
lastmod: 2025-11-22T20:02:57-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5b6c6eead0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c21a3c9c10.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5fef72a43f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e3badc333e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/17386938e0.jpg
url: /2024/10/30/waccamaw-pauwau.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Oct 31, 2024
- 1 min read

![image](https://waccamaw.micro.blog/uploads/2025/5b6c6eead0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5b6c6eead0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/c21a3c9c10.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/c21a3c9c10.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5fef72a43f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5fef72a43f.jpg)

Gates open at 11am on Saturday and Sunday.  Grand Entry is at 1 pm on Saturday and 2 pm on Sunday. Don't forget to set your clock back an hour on Saturday night.

![image](https://waccamaw.micro.blog/uploads/2025/e3badc333e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/e3badc333e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/17386938e0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/17386938e0.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [Native](https://www.waccamaw.org/updates/tags/native)
- [event](https://www.waccamaw.org/updates/tags/event)
