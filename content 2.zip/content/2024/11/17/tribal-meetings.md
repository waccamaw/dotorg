---
layout: post
title: "Tribal Meetings"
microblog: false
guid: http://waccamaw.micro.blog/2024/11/17/tribal-meetings.html
post_id: 5649733
custom_summary: false
summary: ""
date: 2024-11-17T17:15:37-0500
lastmod: 2025-11-22T19:02:23-0500
type: post
thumbnail: https://s3.amazonaws.com/micro.blog/thumbnails/2025/11/22/waccamaw.micro.blog/7bf4c0352c70f4cc86c971b8af86bef0.png
opengraph:
  title: "Waccamaw.org - Tribal Meetings"
  image: https://s3.amazonaws.com/micro.blog/opengraph/2025/11/22/5649733.png
url: /2024/11/17/tribal-meetings.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Browse summaries and minutes from Waccamaw Indian People tribal meetings, executive sessions, and community gatherings.
