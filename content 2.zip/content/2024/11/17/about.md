---
layout: post
title: "About"
microblog: false
guid: http://waccamaw.micro.blog/2024/11/17/about.html
post_id: 5649628
custom_summary: false
summary: ""
date: 2024-11-17T17:15:37-0500
lastmod: 2025-11-22T19:01:59-0500
type: post
url: /2024/11/17/about.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---
Enterprise architecture and tech junkie
