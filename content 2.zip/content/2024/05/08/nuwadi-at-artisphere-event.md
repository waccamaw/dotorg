---
layout: post
title: "NuWaDi at Artisphere Event"
microblog: false
guid: http://waccamaw.micro.blog/2024/05/09/nuwadi-at-artisphere-event.html
post_id: 5650002
custom_summary: false
summary: ""
date: 2024-05-08T19:00:00-0500
lastmod: 2025-11-22T19:26:17-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/e1eadc97be.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/e1eadc97be.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/e1eadc97be.jpg
url: /2024/05/08/nuwadi-at-artisphere-event.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- May 9, 2024
- 1 min read

Greetings!

We are excited to be exhibiting at this year’s Artisphere ([https://artisphere.org/](https://artisphere.org/)) in Greenville, SC.  We would like to invite you to stop by and see us if you are in the area.  Festival Hours are listed below.  The Clemson NuWaDi Team will be located just north of the intersection of S. Main St. and Broad St. in downtown Greenville. Our location is diagonal from the Peace Center, across the street from the Courtyard by Marriott, and next to [Grill Marks at 209 S Main St, Greenville, SC 29601](https://www.google.com/maps/place/209+S+Main+St,+Greenville,+SC+29601/@34.8476662,-82.4004881,18.7z/data=!4m16!1m9!3m8!1s0x885831cd789021d3:0x638482f3ce5c50b3!2s209+S+Main+St,+Greenville,+SC+29601!3b1!8m2!3d34.8481326!4d-82.3998854!10e5!16s%2Fg%2F11bw3_fnqc!3m5!1s0x885831cd789021d3:0x638482f3ce5c50b3!8m2!3d34.8481326!4d-82.3998854!16s%2Fg%2F11bw3_fnqc?authuser=0&entry=ttu).  We hope to see you there!

Artisphere 2024 is taking place May 10 – 12. The daily hours are as follows:

•              Friday, May 10: 12 pm-8:00 pm

•              Saturday, May 11: 10 am-8:00 pm

•              Sunday, May 12: 11 am-6:00 pm

Have a good day!

![ree](https://waccamaw.micro.blog/uploads/2025/e1eadc97be.jpg)

**Cassandra Hicks-Brown, MHSA, SHRM-CP**

**Financial Analyst/Program Manager**

SC Universities Research and Education Foundation

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [event](https://www.waccamaw.org/updates/tags/event)
