---
layout: post
title: "Snow Island"
microblog: false
guid: http://waccamaw.micro.blog/2024/12/16/snow-island.html
post_id: 5650028
custom_summary: false
summary: ""
date: 2024-12-16T00:00:00-0500
lastmod: 2025-11-22T19:53:32-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/a8f975a5fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/29796fbfec.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fc4555648.jpg
- https://cdn.uploads.micro.blog/272201/2025/63b07151c0.jpg
- https://cdn.uploads.micro.blog/272201/2025/04b776b13b.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/a8f975a5fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/29796fbfec.jpg
- https://cdn.uploads.micro.blog/272201/2025/9fc4555648.jpg
- https://cdn.uploads.micro.blog/272201/2025/63b07151c0.jpg
- https://cdn.uploads.micro.blog/272201/2025/04b776b13b.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/a8f975a5fc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/29796fbfec.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9fc4555648.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/63b07151c0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/04b776b13b.jpg
url: /2024/12/16/snow-island.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# Snow Island

-

Michelle Hatcher
- Dec 16, 2024
- 1 min read

Updated: Jan 9

From Idle No More South Carolina Environmental Justice:

Spent the day (12/16/2024) with partners from Winyah Rivers Alliance and Open Space Institute at Snow Island to celebrate protection of lands and rivers that have significant cultural and historical value for Indigenous people. The history is often presented from the point of colonial occupation, in this case, Francis Marion and his elusive camps. But there are more conversations that need to be occuring. To learn more about the conservation work by partners, check out WPDE-15. Story by Tonya Brown. "7600 acres of historic land now protected in lower Florence County."  [https://tinyurl.com/4u5as99v](https://tinyurl.com/4u5as99v)

![ree](https://waccamaw.micro.blog/uploads/2025/a8f975a5fc.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/29796fbfec.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/9fc4555648.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/63b07151c0.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/04b776b13b.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [education](https://www.waccamaw.org/updates/tags/education)
- [#SnowIsland](https://www.waccamaw.org/updates/tags/snowisland)
