---
layout: post
title: "Winter Solstice 2024"
microblog: false
guid: http://waccamaw.micro.blog/2024/12/15/winter-solstice.html
post_id: 5649737
custom_summary: false
summary: ""
date: 2024-12-14T19:00:00-0500
lastmod: 2025-11-22T16:58:12-0500
type: post
categories:
- "updates"
- "community"
- "ceremonies"
images:
- https://cdn.uploads.micro.blog/272201/2025/75dc1baf5b.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/75dc1baf5b.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/75dc1baf5b.jpg
url: /2024/12/14/winter-solstice.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Join us for our annual Winter Solstice ceremony and celebration. This sacred time marks the shortest day and longest night of the year, a time for reflection, gratitude, and community gathering.

The ceremony will include traditional songs, storytelling, and a shared meal. All tribal members and their families are welcome to attend.

![Winter Solstice celebration](https://waccamaw.micro.blog/uploads/2025/75dc1baf5b.jpg)

**When:** December 21, 2024, starting at 6:00 PM  
**Where:** Tribal Grounds, Dog Bluff Community

Please bring a dish to share if you're able. We look forward to celebrating this special time together as a community.
