---
layout: post
title: "Waccamaw Spring Equinox & Community Day"
microblog: false
guid: http://waccamaw.micro.blog/2024/01/31/waccamaw-spring-equinox-community-day.html
post_id: 5650052
custom_summary: false
summary: ""
date: 2024-01-30T19:00:00-0500
lastmod: 2025-11-22T20:03:02-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/b4f5d41303.jpg
- https://cdn.uploads.micro.blog/272201/2025/8a947db7ec.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/b4f5d41303.jpg
- https://cdn.uploads.micro.blog/272201/2025/8a947db7ec.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/b4f5d41303.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/8a947db7ec.jpg
url: /2024/01/30/waccamaw-spring-equinox-community-day.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jan 31, 2024
- 0 min read

![ree](https://waccamaw.micro.blog/uploads/2025/b4f5d41303.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/8a947db7ec.jpg)

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [community](https://www.waccamaw.org/updates/tags/community)
- [Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-2)
- [Equinox](https://www.waccamaw.org/updates/tags/equinox-1)
