---
layout: post
title: "Tap E Ya Bernard Hamilton"
microblog: false
guid: http://waccamaw.micro.blog/2024/01/03/tap-e-ya-bernard-hamilton.html
post_id: 5650038
custom_summary: false
summary: ""
date: 2024-01-02T19:00:00-0500
lastmod: 2025-11-22T20:01:26-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
- https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
- https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/efcf402916.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1a81a5c376.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b504fd9702.jpg
url: /2024/01/02/tap-e-ya-bernard-hamilton.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jan 3, 2024
- 1 min read

Sad News

Tanakahey:

I am informed that Bernie Hamilton, died last night in a hospital emergency room.

I don't know the details and the arrangements have not

 yet been finalized. I'll share them when I have them.

I'm sorry for our collective loss.

Buster

![image](https://waccamaw.micro.blog/uploads/2025/efcf402916.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/efcf402916.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1a81a5c376.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1a81a5c376.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b504fd9702.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b504fd9702.jpg)

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-2)
- [RIP](https://www.waccamaw.org/updates/tags/rip)
