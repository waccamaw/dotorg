---
layout: post
title: "Reminder: Keep Your File Updated"
microblog: false
guid: http://waccamaw.micro.blog/2024/01/06/reminder-keep-your-file-updated.html
post_id: 5650010
custom_summary: false
summary: ""
date: 2024-01-05T19:00:00-0500
lastmod: 2025-11-22T19:27:35-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/1c97ba1325.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/1c97ba1325.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/1c97ba1325.jpg
url: /2024/01/05/reminder-keep-your-file-updated.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jan 6, 2024
- 1 min read

![ree](https://waccamaw.micro.blog/uploads/2025/1c97ba1325.jpg)

Members, it's that time again- look at your ID card and see if the address is correct and that it hasn't expired.

If your address is different or you haven't contacted the committee within the last year, please send Michelle (me) your new contact information (address, phone, email) to ensure you receive updates on meetings and events. This will help keep your file current.

If your ID card has expired, don't hesitate to get in touch with me (Michelle) so I can check if your membership fees are current or if your ID has changed from Active status. If your membership fees are in arrears, I can let you know the amount due to update your card based on deposits to the bank. I can also send you a hard copy of the ID renewal form.

Thanks,

Chell

Waccamaw Tribal Secretary

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-2)
- [#Membership](https://www.waccamaw.org/updates/tags/membership)
