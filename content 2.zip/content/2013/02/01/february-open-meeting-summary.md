---
layout: post
title: "February Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/02/02/february-open-meeting-summary.html
post_id: 5649634
custom_summary: false
summary: ""
date: 2013-02-01T19:00:00-0500
lastmod: 2025-11-22T19:02:07-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/02/01/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/1/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Neal, Susan, Dalton, Richia, Robert, and Homer, present.

2. Richia and Robert sworn-in to office

3. January Minutes Read

            a. Change 5e: redirecting to waccamaw.org site- not doing away with

                        1. Neal motioned to accept with change; Robert seconded

                                    a. Neal-yes, Susan-yes, Richia-yes, Robert-yes, Homer-yes, Dalton-yes,                                              Scott-yes

4.  Financial Report: Michelle

            a. General Fund: $5379.22

            b. Building Fund: $1622.29

5. Unfinished Business

            a. Online Votes

                        a. 1/17 Authorize $150 to make feathers, necklaces, chokers, for Austria

                                    1. Neal-yes, Susan-abstain, Dalton-yes, Homer-yes, Neal-yes

                        b. 1/19 Authorize purchase of 250 pieces of letterhead/ envelopes

                                    1. Susan-yes, Neal-yes, Dalton-yes, Homer-yes, Scott-yes

6. New Business

            a. Committee Reports

                        1. Grants: Michelle

                                    a. NCAI: 10 $2500 cash prizes to high school students

                                                1. Details on Facebook & G+ pages

                                    b. AgDiscovery Program: Agricultural Science

                                                1. 1. Details on Facebook & G+ pages

                                    c. SCAC 3/15

                                    d. Lowe's Community & Education Grants in March

                        2. Buildings & Grounds: Neal

                                                a. Roof: took 8 buckets to do roof

                                                b. Work Day: Sunday 12pm

                        3. Arts & Crafts: Susan

                                    a. Nothing to report

                                    b. Chief Hatcher: something needs to happen

                                                1. A&C used to make all feathers for rank & tribal

                                    c. Dalton: on phone calls: people talk over each over

                                    d.  Chief Hatcher: Make it so voting member of committee are from here

                                    e. Susan: get with CoC Scott & Dalton to work it out

                        4. Pauwau: Michelle

                                    a. Meeting 2/13: Coastal Ale House: Conway: 6:30pm

                                    b. Suggestions after Aug 1 will be considered for 2014

            b. CoC Scott

                        1. Members Donald, Esther, Patricia Bryant

                                    a. discovered dual membership

                                    b. Letter signed by all of Council, signed & sent to them

                        2. Putting Dalton in charge of Tribal Roll Book (Inactive status)

                        3. Council Work Day- Feb.- TBA

                        4. Website: Susan/ Gary

                        5. Going to meet with people about files & move files back to office

                        6. Neal: work day in Feb to inventory what we have & don't have to avoid excess                                 spending

                        7. People are not doing what they said they would do in office & will be spoken to

            c. 2nd Chief Cheryl

                        1. Grand Strand Magazine: 4pg article with photos

                                    a. Come out for follow-up in Sept/ Oct

                        2. Logo for T-shorts- solid white T's

                                    a. John to get with Michelle or CoC Scott for guidelines

                                                1. Present guidelines to Council for approval

                        3. Flash Mob Round Dance 2/2: Colonial Mall

                                    a. Idle No More Event

            d. CoC Scott

                        1. Closing TRB with exceptions

                        2. Elder Frank: Close now; reopen on necessity/ benefit of tribe

                        3. Homer: like interview idea (applicant comes before Council)

                        4. Chief Hatcher: have to define what closing TRB means first

                                    a. Ex: does it mean that no apps go out anymore?

                        5. Susan: Also need to look at %'s first after Dalton scrubs TRB

                        6. Paul Fisk: No consequence for no participation

                        7. Neal: get them interested at age 18

                        8. Chief Hatcher: set ground rules

                        9. 2nd Chief Cheryl: usually 10% people doing 90% work

                                    a. Mohegan: prerequisite for stipend was work

                                    b. reward is better than penalty for motivation

10. Chief Hatcher: membership fee

11. Homer: bring up at gathering

                                    a. Also: where does it say kids are auto-members at 18?

                                                1. Chief Hatcher: it doesn't

12. John: Prison system requires anyone he serves/ works with to be members

                                    1. Chief Hatcher: need to work with prison system to change law for all                                                 Native Americans

            e. Chief Hatcher

                        1. Met with Finance Minister & Prime Minister from Austria

                                    a: Question is How, not If on business deal

                                    b. High school/ College Exchange Student Program

            2. Met with:

                        a. Dr. Franz Wohlfahrt of Novomatic

                        b. Dr. Karl Stoss & Herr Richard Lehrner

                        c. Prof. Gerhard Skoff of Stage4Solutions

                        d. Herr Gunter Haidenbauer

            3. Estimated price on Federal Recognition: $500,000

            4. Tom Rice: have to make another trip to DC to meet with him to put bill in

            5. Committee to discuss ways to help people once recognition goes through

                        a. Johnnie Marie: set standards

                        b. 2nd Chief Cheryl: social programs can lead to an increase in handouts

                        c. John: reward education; pre-roll like Catawba

            6. Once people from Austria come here, want people with suggestions & involved

            7. We should take care of Natives, not just ourselves

            8. TRB & Website Maintenance

            9. Set Council Work Day each month: routine

                        a. Put in newsletter

10. Need to plan better

11. Would like to retire: those interested- start planning

Homer motioned to close the meeting; Neal seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 2/23/13 at 11:04 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
