---
layout: post
title: "October 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/10/05/october-open-meeting-summary.html
post_id: 5649668
custom_summary: false
summary: ""
date: 2013-10-04T19:00:00-0500
lastmod: 2013-10-04T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/10/04/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/4/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott and CM’s Dalton, Susan, Homer, Richia, Robert, and John present.

2. September minutes read

3. Dalton motioned to accept; Homer seconded

4. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

5. Financial Report: Alan

6. General Fund: deposits: $1852.50, debits: $809.21, balance: $6263.08

7. $381.00 coming back due to fraudulent debit charge

8. Building Fund: deposits: $290.00, debits: $60.00, balance: $2215.85

9. Online Votes

10. 9/7 Add Cemetery Manager, grounds manager, committee heads to Res J-HH-09-06-2013-001

11. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-abstain, Dalton-yes, Scott-yes

12. 9/8 Add names to Waccamaw Bucks award list

13. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-abstain, Dalton-yes, Scott-yes

14. 9/19 Add names to Waccamaw Bucks Award list

15. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-absent, Dalton-yes, Scott-yes

16. 10/1 Restrict cash donations to $200 in Waccamaw Bucks

17. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-abstain, Dalton-yes, Scott-yes

18. 10/1 Approval of Revised Res J-HH-09-06-2013-001

19. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-abstain, Dalton-yes, Scott-yes

20. Old Business

21. Policy Letters: Susan

22. Susan to send to Council again

23. Use of the Tribal Office

24. Susan: can’t we just put a locking door handle in place?

25. Chief Hatcher: want to be careful with people around the files

26. Take out nonmembers; Jeania K mentioned adding arbitration

27. Change it to “not be held responsible”- 2nd Chief Cheryl to draft

28. Use of the Tribal Grounds

29. Susan: same clause in policy letter is on vendor applications

30. change disclaimer, allow non-members

31. Camping on the Tribal Grounds (Excluding Pauwau)

32. Add illegal drugs to policy letters

33. To Rick: electric heaters blow circuit breakers

34. Use of the Tribal Logo

35. Dispute on charges- $1 was too much

36. Susan: not looking just at John A; looking at everyone

37. Dalton: $50 flat fee per release

38. Susan: devil’s advocate: what if they sell 100 & then want to get 100 more?

39. Dalton: just 1000 people with our shirts will get our name out

40. 2nd Chief Cheryl: talked about copyright infringement- civil & criminal

41. Dalton: best thing would be to be selective on who we let use it

42. Make them put a date on it

43. Elder Doug: issue permit for 1 year & then not allow them to sell it

44. Susan: $100 & it can’t be Waccamaw Bucks

45. Richia & Robert seconded

46. Jeania K: ex: you have 10 people who want to use the logo- do you get 10 times cost?

47. Answer: yes- one per person per release

48. Susan motions member only, $100 per run, & not Waccamaw Bucks

49. Robert seconded

50. Homer-no, Robert-yes, John-no, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

51. New Business

52. Committee Reports

53. Grants: Michelle

54. Nothing  at  this time

55. Buildings & Grounds: John T

56. Work Day 10/5

57. Paint Drum circle shed area, trash can

58. Scott thanked John for pride he puts in the committee

59. Pauwau: Michelle

60. John: Hoe Down- gave out 400 fliers

61. Rolling Thunder was proud of us

62. Vendor Applications received to date: 11

63. Meeting 10/9 at Shoney’s at 6:30

64. Chief Hatcher: change 20ft front vendor space to $250

65. Scott: Scouts want to dance this year

66. Committee agreed, but also that they could not compete

67. 2nd Chief Iris: could use it as a demonstration

68. Homer: limit it, else more will want to

69. John: other than Pauwau/ Family Day, no one seems to get involved

70. Elevate Family Day, have more than one

71. Classes with history, heritage, language

72. Susan: Are you going to take the lead?

73. John: Would, but lack knowledge

74. Sell Arts & Crafts for money

75. Chief Hatcher explained certification process

76. Proposal on internet first

77. Catawba language (Rock Hill)

78. Program Book presented to Council for approval

79. Still needs one page

80. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

81. Aynor’s 100th Anniversary Special- thanks given to Rick & Donnie

82. Fuel Receipts: $37.56 Check 1027

83. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

84. 2nd Chief Iris

85. No meeting recording on tribal website

86. Johnnie F to email them to Doug

87. Bookkeeper- gave report to Alan F

88. Categories, 1099’s, Chart of Accounts

89. Question: waiting period on minors that turn 18- must be responsible for their own file

90. Sign the member’s agreement, application, & roll book as themselves

91. On 18th birthday, 90 days later- gone if not updated

92. Extend minor ID cards to 90 days

93. Dalton motioned: minor member file is inactive 90 days after their 18th birthday, the member is removed

94. Dalton/ John T seconded

95. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

96. Tabled for now

97. Question: ID sent to brand new member & it came back as bad address, inactive after 3rd mailing

98. Chief Hatcher

99. Human Affairs Commission wants to setup at Pauwau

100. Used ID printer- needs printhead- $500

101. Sumter Band wants to buy it from us

102. Chief Hatcher proposes we donate it; Susan seconded

103. J-HH-10-06-2013-002: Donation of ID Card Printer

104. Homer-yes, Robert-yes, John-yes, Richia-yes, Susan-yes, Dalton-yes, Scott-yes

105. Res J-HH-10-06-2013-001: Appointment of Elders

106. Seconded by Dalton

107. Appointed Glenn Turner to Elders Council

108. Say thank you to people more often

109. Rats are eating new table; looking in to ways to treat it

110. Johnnie F

111. Will be glad to deliver printer to Sumter Band

112. Wed before Pauwau (10/30)- setup tents, hay, etc….

Homer motioned to close the meeting; Robert seconded.

Meeting adjourned 9:40 pm.

Respectfully submitted by Michelle Hatcher on 12/5/13 at 3:03 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
