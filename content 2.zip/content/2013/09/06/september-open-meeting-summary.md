---
layout: post
title: "September 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/09/07/september-open-meeting-summary.html
post_id: 5649667
custom_summary: false
summary: ""
date: 2013-09-06T19:00:00-0500
lastmod: 2013-09-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/09/06/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 9/6/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott and CM’s Dalton, Homer, and John present.

2. CoC Scott: A podium has been added to the room for questions and comments.

3. August minutes read

4. Dalton motioned to accept; Homer seconded

5. Homer-yes, John-yes, Dalton-yes, Scott-yes

6. Financial Report: Alan

7. General Fund: deposits: $3033.75, debits: $390.18, balance: $5219.79

8. $2000 of deposits earmarked for dance raffle

9. Building Fund: deposits: $830.00, debits: $255.00, balance: $1985.85

10. Online Votes

11. 8/10 Transfer money from TD Bank to General Fund to cover dance raffle

12. Homer-yes, John-yes, Dalton-yes, Scott-yes

13. New Business

14. Committee Reports

15. Grants: Michelle

16. Waiting to hear from Lowe’s Education Grant

17. Buildings & Grounds: John T

18. Planting, Work Day 9/7 at 7am

19. John T: is there electricity in the other trailer or how much would it cost?

20. Answer: none at the moment; cost would be $200-250 per month

21. John T: do you mind if I paint it?

22. Answer: no

23. John T: and underpin it or how much it would cost?

24. Darlene: cost about $1100 to do hers

25. John T: would be nice if we could find someone to paint a mural on it

26. Pauwau: Michelle

27. Need Council to confirm 2nd Chief Cheryl as a voting member

28. Homer-yes, John-yes, Dalton-yes, Scott-yes

29. Meeting 9/11 at Shoney’s in Conway at 6:30pm

30. Asking members for donations of water, paper products

31. Aynor Hoe Down: Scott

32. Sept 21 with 12x12 spot costs $60 and would allow us to tell people about the pauwau and Natives

33. Joey W and Wayne T donated money to pay for table

34. John T to help with Hoe Down

35. Oct 19 is Aynor’s 100 Anniversary Festival and would be free

36. Policy Letters

37. Associate/ Honorary/ Spousal Membership

38. Dalton motioned; Homer seconded

39. Homer-yes, John-yes, Dalton-yes, Scott-yes

40. Reviewing Files

41. Dalton motioned; Homer seconded

42. Homer-yes, John-yes, Dalton-yes, Scott-yes

43. Family Day & Other Events

44. John motioned; Dalton seconded

45. Homer-yes, John-yes, Dalton-yes, Scott-yes

46. Making Loans

47. John motioned; Homer seconded

48. Homer-yes, John-yes, Dalton-yes, Scott-yes

49. Members Files

50. Would remove spouse/ children

51. Tabled for Constitution Change

52. Spousal Membership

53. Should say ‘reapply’ in last sentence

54. Chief Hatcher: not sure why they’d have to reapply

55. Tabled for now

56. Use of the Tribal Grounds

57. Should say ‘injury’ not injure

58. Chief Hatcher: make it a deposit & give it back if they clean up

59. Alan mentioned costs (Water, electric, etc…)

60. Chief Hatcher: doesn’t include office, just the grounds

61. Dalton: make it a deposit for members, fee for nonmembers

62. John questioned legality of the harmless clause

63. Dalton motioned; Homer seconded

64. Homer-yes, John-yes, Dalton-yes, Scott-yes

65. Use of the Tribal Office

66. Chief Hatcher: don’t think anyone should use office w/o a member of government here because of files

67. Dalton: remove specificity in ‘bring your own products’

68. Change to ‘bring products you will need’

69. Darlene: costs seem backwards- office is worth more, should at least be equal

70. Dalton: $75 deposit ($25 returned, $25 for utilities, $25 for official who stays to watch files); $150 for nonmembers

71. Chief Hatcher: think you could also say ‘no use of the office’

72. Dalton: could do members only

73. Tabled for now

74. Money for Flowers

75. Dalton: no problem with first part; remove part allowing people to ask for donations (doesn’t need to be there)

76. John motioned; Homer seconded

77. Homer-yes, John-yes, Dalton-yes, Scott-yes

78. Camping on the Tribal Grounds (Excluding Pauwau)

79. Dalton: change donation to fee

80. Also add it to list of Waccamaw Bucks items

81. No alcohol or illegal drugs

82. Added: except medicinal?

83. Rick H: if it’s hot outside, who’s policing them turning AC on?

84. Tabled for now

85. Also separate campers from RV’s

86. Membership Fees

87. Add fee to last sentence

88. Chief Hatcher: don’t think it’s tax-deductible because it’s a fee

89. Make them responsible for notifying us

90. John A: reading from fundraisers.org, think it is

91. Chief Hatcher: kids go to school; we can sell arts as native crafts

92. John T: should tax-deductible be in there?

93. 2nd Chief Cheryl: should be in there for transparency

94. John A: it’s incentive for people who may otherwise not pay

95. Dalton: change it to ‘if paid before 8/1, it’s $50

96. “The member has the option to prepay a year. If they choose to do so and they pay before August 1, their fee will be $50. 2013 fees can be paid any time prior to Aug 1, 2014 and receive the $50 rate”

97. Dalton motioned; Homer seconded

98. Homer-yes, John-yes, Dalton-yes, Scott-yes

99. Use of the Tribal Logo

100. Dalton: change ‘used’ to ‘made’

101. John A: wouldn’t go with a timeframe; be glad someone’s putting name out there

102. Make stipulations about changing logo and what-not

103. 2nd Chief Phil: wouldn’t go with $1

104. Go off what they sell- 2-5%

105. Chief Hatcher: not sure how you’ll manage it

106. Just because someone says they get 100 items, they could get 200

107. John T: why wasn’t there any discussion over last couple months on this?

108. Michelle: Susan sent emails to Council asking for input

109. Dalton: John A’s asking for it to be low enough for people to make a profit

110. Darlene: could have t-shirts made & here in 2 weeks

111. Dalton: Aug 1 was cutoff for Pauwau 2013

112. Committee works hard all year and has told everyone for months that there was cutoff

113. They shouldn’t have to come up with someone to do this job too

114. Darlene: what if I buy the shirts, tribe pays for the booth, & tribe gets the money?

115. We’d discuss at Wed’s meeting; everyone’s welcome

116. Johnnie F: willing to pick up & deliver the shirts

117. Scott: looking for policy; not profit & loss

118. Change part about changes to logo

119. Dalton: 2-5%?

120. Last sentence should read: “It can only be used with consent of tribal council.”

121. Tabled for now

122. 2nd Chief Cheryl

123. Presented forms to modify for our use

124. Membership Fee Discount

125. Area of Concern: asks people to disclose other assistance

126. Dalton: why does it just ask for 1 program (Program Participation section)

127. 2nd Chief Cheryl: no need to qualify further

128. Volunteer Service Hours Log

129. Turned in by the member & returned to Council

130. John T: who keeps up with the log?

131. 2nd Chief Cheryl: each member is responsible

132. 2nd Chief Cheryl: could be modified for line-by-line signatures by Chairperson/ supervisor

133. Dalton: at bottom, let member & person it gets turned into sign there

134. Elder Doug

135. Firekeeper: consider training John or another person?

136. John C is certified and Rick H would like to train

137. Donnie’s fuel receipts

138. Fuel: $78.61 Check 1525

139. Homer-yes, John-yes, Dalton-yes, Scott-yes

140. Chief Hatcher

141. Ms. Carolyn: ½ acre land to donate

142. Need to help her empty sheds

143. Think Susan wanted pots/ pans, Washer/ Dryer out for tribe

144. Ms. Carolyn will call Susan to set date

145. Online votes: right now, they are for emergencies and time-sensitive things

146. Think that has to change- you have to be able to work

147. Res. J-HH-09-06-2013-002: Appointment of Elders

148. Would make Charles Creech an Elder

149. Need to spell Creech correctly on form

150. Dalton motioned to accept with spelling change; Homer seconded

151. Homer-yes, John-yes, Dalton-yes, Scott-yes

152. Res. J-HH-09-06-2013-001: Exemption of Membership Fees for Anyone Serving in the Tribal Government

153. Homer: add Firekeeper to list?

154. Chief Hatcher: no problem with that

155. Dalton motioned to accept with change; Scott seconded

156. Homer-yes, John-yes, Dalton-yes, Scott-yes

157. Waccamaw Bucks

158. Add camp fees to list

159. Added names to list based off 2012 Volunteer Sheet

160. List given to Chief Hatcher by Michelle

161. Dalton motioned to accept; Homer seconded

162. Homer-yes, John-yes, Dalton-yes, Scott-yes

163. Smudging

164. Need someone to do it if we plan to do it

165. Should we do it?

166. Most everyone in room: yes

167. Scott: being smudges is a choice

168. Darlene: would need to clear room quick for those who can’t breathe well

169. Scott: smudge room, open windows to allow it to cover office

170. Drum donated by Rick H

171. Want everyone to sign it

172. John C’s Statement

173. “Filled with honor; humbled to be here. Apologize for family’s past transgressions. Can’t express feelings to be here; thank-you for letting me be here. Rethought my life over last few years”

174. Chief Hatcher: we want the building to be smudged each month & during pauwau

175. John C agreed to do it

176. John C also agreed to train apprentices

Dalton motioned to close the meeting; Homer seconded.

Meeting adjourned 9:30 pm.

Respectfully submitted by Michelle Hatcher on 9/19/13 at 2:35 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
