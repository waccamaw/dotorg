---
layout: post
title: "April 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/04/06/april-open-meeting-summary.html
post_id: 5649663
custom_summary: false
summary: ""
date: 2013-04-05T19:00:00-0500
lastmod: 2013-04-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/04/05/april-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 4/5/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Neal, Susan, Dalton, Richia, and Homer present.

2. March minutes read.

            a. Neal motioned; Scott seconded

                        1. Homer: thought 4(a)(2) application fee was supposed to be $20?

                                    a. Dalton: thought it was $25

                                                1. Dalton motions someone listens to the tape & provide correct                                                            amount

                                                2. Chief Hatcher: establish dollar amount now

                                                3. Homer: $20

                                                            a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes,                                                     Scott-yes

                                                            b. Authorize Susan to change the dollar amount on                                                                                applications

                                                                        1. Neal-yes, Homer-yes, Susan-yes, Richia-yes,                                                                                   Dalton-yes, Scott-yes

3. Financial Report: Michelle

            a. General Fund: $3755.63

            b. Building Fund: $2426.83

4. New Business

            a. Committee Reports

                        1. Grants: Michelle

                                    a. SCAC filed on 3/15 for School Day

                                    b. Lowe's Community Grant: 3/1-4/30, 6/1-7/30: need B&G help

                                    c. Lowe's Education Grant: 8/1-10/15 for Pauwau

                        2. Buildings & Grounds: Neal

                                    a. Work day last month in office

                                    b. Asking for help with Donnie's shower- quote is $200 if anyone can                                        donate

                                                1. Funds obtained

                                                2. Neal asked attendees if extra funds could go to building fund

                                                            a. they agreed

                        3. Arts & Crafts: Susan

                                    a. Nothing available

                        4. Pauwau: Michelle

                                    a. Meeting 4/10 @ Coastal Ale House in Conway @ 6:30pm

                                    b. Demonstrators / key roles nearly all confirmed

                                    c. Reconfiguring budget as we know what prices have changed

                                    d. Neal resigned: have 6 voting members, could use 1 more

                                                1. Let Michelle know if you're interested

            b. Membership

                        1. Susan: Need a system because someone could just volunteer for 1 year to get a                                 plastic card & never come back

                        2. Chief Hatcher: alto talked about membership fees in case people cannot work

                                    a. they'd be able to attend meetings for 1 year to decide if they want to stay

                                    b. they could work the dollar amount off or Council could decide the                                         person didn't have to pay it for 1 year

                        3. 2nd Chief Cheryl: monthly would be difficult for people to remember to pay                           fees

                                    a. suggests quarterly, yearly, or as you renew ID

                        4. Audience: $5 per month is fine (about same as cigarette/ drink prices)

                        5. Homer: $5 per month or $50 per year (slight break that way)

                        6. Susan: suggestion: ID cards for Associate members should be paper. After 1                                     year, go to regular card

                                    1. Dalton motioned; Susan seconded

                                                a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-                                                      yes

                        7. Chief Hatcher: during trial period, do they get to vote?

                                    a. Dalton: no, they're associate members

                        8. Chief Hatcher: Are any associate members eligible for full membership?

                                    a. Homer: they have to earn it

                        9. Elder Hank: What about expired ID cards?

                                    a. Susan: call 2nd Chief Iris to update your card

            c. Membership Files

                        1. Daryl Lynn Barber

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        2. Amy Narron Barber

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        3. Murray Keith Jones

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        4. Dianne Tanner Hatcher

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        5. George Kelly Jones

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        6. Howard Elwood Ammons

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        7. Willie Ray Ammons, Sr.

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        8. Sean Strickland

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

                        9. Michele Lin Ammons

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

10. Julius Hatcher

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

11. Samantha Sellers

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

12. Tonya Lee Lewis

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

13. Kaylee Rae Madison Lewis

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

14. Amber Rae Hatcher

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

15. Abigail Faith Hatcher

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

16. Sienna Grace Hatcher

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

17. Sylvia Jean Jones

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

18. Amber Ridenhour

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

19. Heather Studley

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

20. James J. Murphy

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

            c. Resolution: DH-04-05-2013-001: Firearms Restrictions: 1st Reading

                        1. Donnie: will need "No Trespassing" signs

            d. Susan presented policy letters for Council to look over:

                        1. Tribal Members Camping on the Tribal Grounds (Excluding Pauwau Time)

                        2. Making Loans

                        3. Spousal Membership

                        4. Use of the Tribal Grounds

                        5. Use of the Tribal Logo

                        6. Use of the Tribal Office

                        7. Paperwork Brought into Tribal Office

                        8. Members Files

                        9. Associate Membership

10. Reviewing Files

            e. Event: 8th Annual NCAI Policy Research Center Conference 6/24-27

                        1. Policy, research, vendor presentations, scholar forum

            f. Falmouth Training list gone over

            g. Susan: Genealogy Book

                        1. Some of the people who should be there aren't there- can she add them in the                                    book?

                                    a. Dalton: should be evolving constantly

                                    b. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

            h. Chief

                        1. Meeting last week in Lancaster

                                    a. Indian Arts Crafts Law in federal Congress: extends rights to groups

                                    b. trying to get all animal parts used at the SC level

                                    c. 2002: Reciprocity & Natives: not all schools in all states do this

                                                1. this measure passed here

                                    d. CMA decides who gets recognized in state

                                                1. They have to assign someone to the empty seat

                                                            2. Resolution J-HH-04-05-2013-001: Appointment of                                                              Member Joey Watford to the Commission for Minority                                                             Affairs Recognition Committee

                                                                        a. Dalton motioned; Susan seconded

                                                                                    1. Neal-yes, Homer-yes, Susan-yes, Richia-                                                                                         yes, Dalton-yes, Scott-yes

                                                            3. Letter sent to CMA's Thomas Smith requesting that Mr.                                                                    Watford fill the seat

                        2. Anonymous letter sent to Chief Hatcher accusing him of being a thief

                                    a. Elder Frank: we talked about sending letter out showing expenditures

                        3. Cemetery: how long will it be before we can out a fence around rest of it?

                                    a. Chief Hatcher: if we can get the money, will make that change until                                         judge says otherwise

            i. Fuel

                        1. Donnie's fuel receipt: $18.50 Check 1514

                                    a. Neal-yes, Homer-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

            j. Dalton: Need to appoint another elder

            k. 2nd Chief Cheryl: would like an "of Council" position to be given if Chief Hatcher                   retires

                        1. Dalton: new Chief has to be able to do his job without hindrances

Susan motioned to close the meeting; Homer seconded.

Meeting adjourned 8:12 pm.

Respectfully submitted by Michelle Hatcher on 4/19/13 at 4:28 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
