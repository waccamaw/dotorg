---
layout: post
title: "December 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/12/07/december-open-meeting-summary.html
post_id: 5649669
custom_summary: false
summary: ""
date: 2013-12-06T19:00:00-0500
lastmod: 2013-12-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/12/06/december-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 12/6/2013 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Susan, Homer, Richia, and John present. 2nd Chief Iris served as proxy for CoC Scott.

2. Dalton chaired the meeting in CoC Scott’s place.

3. October minutes read

4. 2nd Chief Iris motioned to accept; Susan seconded

5. Homer-yes, 2nd Chief Iris-yes, Susan-yes, John-yes, Richia-yes, Dalton-yes

6. Financial Report: Alan

7. General Fund:

8. Oct: deposits: $4262.63, debits: $1531.24, balance: $8994.47

9. 2 $125.00 deposit items returned

10. Nov: deposits: $11,148.67, debits: $5516.07, balance: $14627.07

11. 2 $125.00 deposit items credited

12. $381.00 fraudulent charge deposited back into account

13. Building Fund:

14. Oct: deposits: $100.00, debits: $0.00, balance: $2315.85

15. Nov: deposits: $900.00, debits: $2069.98, balance: $1145.87

16. Made third loan payment

17. Chief Hatcher: would like to get enough money into Building Fund account to make final payment and leave $100 in it to keep the account

18. Richia motioned; Homer seconded to transfer BB&T funds to pay off loan on the Building Fund

19. Homer-yes, 2nd Chief Iris-yes, Susan-yes, John-yes, Richia-yes, Dalton-yes

20. Online Votes

21. 11/17 Allow tribal member use of office

22. Homer-no, 2nd Chief Iris (Scott)-yes, Susan-yes, John-yes, Richia-yes

23. Chief Hatcher proposes online votes go to everybody before the vote is taken

24. Dalton suggested Michelle as point of contact since she has email addresses for most everybody

25. John: on this issue: didn’t we have a policy on the office?

26. Chief Hatcher: Jeanie forwarded an email saying rent, which could be done with Waccamaw Bucks and he asked for an exception

27. 11/26 Re-vote to allow tribal member use of office

28. 2nd Chief Iris (Scott)-yes, Susan-yes, John-absent, Richia-yes, Dalton-yes

29. 12/2 Pay Tuscarora Youth Dancers for Pauwau Demonstrations $200

30. 2nd Chief Iris (Scott)-yes, Susan-yes, John-yes, Homer-absent, Richia-yes, Dalton-yes

31. New Business

32. Committee Reports

33. Grants: Michelle

34. Nothing new till January & then start looking at sponsorships

35. Buildings & Grounds: John

36. Steps built, some painting done

37. Possible Work Day 12/7

38. Pauwau: Michelle

39. Very successful Pauwau, Karl was impressed

40. Debriefing 12/7 @ Ryan’s in Conway for volunteers

41. Homer: Karl and couple with him were very impressed

42. Chief Hatcher: thought attendance was less, but dollar amount says different

43. However, we don’t have an accurate count of demographics

44. Homer: women missed kids from last year that hung at out gate and helped with books

45. Mark A: possible help with count for next year: clicker device

46. John: the count is important for advertising and grants

47. John: sister in-law came & was impressed; never felt left out, even at fire circle

48. Inactive Tribal Members

49. Chief Hatcher suggested tabling it for 1 month

50. Richia; Homer seconded

51. Homer-yes, 2nd Chief Iris-yes, Susan-yes, John-yes, Richia-yes, Dalton-yes

52. Mark A: Bathroom Project

53. I have been working with SC State Representative Alan Clemmons, on getting the sewer tap, he has put me in touch with the Grand Strand Water and Sewer Authority, Who has given us a price of $3630.00 per no unforeseen problems. This would include the tank and grinder pump, along with the sewer tap.

54. I have two leads on grants that I am currently pursuing. If the grants don't work out we can continue to pursue the bathroom, bathhouse project, Grand Strand Water & Sewer will finance the connection with a down payment of $190.00, they would finance the balance over 20 years, with interest, and the payment would be less than $20.00 a month.

55. Crescent plumbing of South Carolina LLC, Has given me a written commitment to supply all fixtures, to include, handicap toilets, sinks and showers, and to do all the work involved to plumb the bath houses free of charge.

56. My suggestion and what I'm working on is to get a prefab storage building, 12x20 to turn into a bath house. I will keep you informed on the progress of this project.

57. Susan motioned to allow Mark to proceed; Richia; Homer seconded

58. Homer-yes, 2nd Chief Iris-yes, Susan-yes, John-yes, Richia-yes, Dalton-yes

59. Chief Hatcher

60. Jeanie W got her high school diploma & now enrolled in low enforcement

61. To 2nd Chief Phil: certificate of appreciation from Sumter Band

62. 45 acres in land that may be donated

63. $500 drawing date

64. Susan motioned for 12/7; Richia seconded

65. Homer-no, 2nd Chief Iris-no, Susan-no, John-no, Richia-yes, Dalton-yes

66. John motioned for Family Day; Dalton seconded

67. Homer-yes, 2nd Chief Iris-yes, Susan-yes, John-yes, Richia-no, Dalton-yes

68. Fuel Receipts: $18.00 Check 1555

69. 2nd Chief Iris-yes, Homer-yes,  John-yes, Richia-yes, Susan-yes, Dalton-yes

70. John C: thanked Steve for helping at fire circle during Pauwau

71. Johnnie F: Family Day & shrimp: will need help purchasing shrimp this year since price went up (if we want the same thing as last year)

72. Chief Hatcher: Please sign card to Tubby

Susan motioned to close the meeting; 2nd Chief Iris seconded.

Meeting adjourned 8:30 pm.

Respectfully submitted by Michelle Hatcher on 12/9/13 at 11:44 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
