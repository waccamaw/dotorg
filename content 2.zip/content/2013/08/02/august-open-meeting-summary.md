---
layout: post
title: "August 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/08/03/august-open-meeting-summary.html
post_id: 5649666
custom_summary: false
summary: ""
date: 2013-08-02T19:00:00-0500
lastmod: 2013-08-02T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/08/02/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 8/2/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott and CM’s Dalton, Susan, Homer, and Richia present.

2. Open Council seat: John Turner sworn into office.

3. July minutes read.

4. Dalton motioned to accept; Susan seconded

5. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

6. Financial Report: Alan

7. General Fund: deposits: $0, expenses: $377.80 balance $2576.22

8. Building Fund: deposits: $295.00, balance $1410.85

9. Online Votes

10. 7/13 Reapprove PW Budget

11. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

12. New Business

13. Committee Reports

14. Grants: Michelle

15. Lowe’s Education Grant: 8/1-10/15

16. Lowe’s Small Project Grants: no dates, up to $2500

17. Buildings & Grounds: Scott

18. Need to begin cleaning out storage trailer

19. Nominate John T to B&G Chairperson

20. Homer-yes, Susan-yes, Richia-yes, Dalton-yes, John-abstain, Scott-yes

21. Pauwau: Michelle

22. Meeting 8/14 @ Shoney’s in Conway @ 6:30pm

23. All suggestions will be considered for 2014 now

24. Everyone can assist with ads, drinks, paper products

25. Inactive Membership: Dalton

26. Res DH-08-03-2012-001 read

27. Dalton motioned; Susan seconded to change 12 month period to 90 days

28. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

29. Announcement by CoC Scott: Jerry Smith resigned as both an Elder and tribal member

30. Reminder by CoC Scott: Work Day at HGTC on 8/10

31. Susan: propose that members cannot renew cards earlier than 30 days before expiration dates. Also, payments would be $50/year (if paid in advance), $15/ quarter, or $5/month

32. John A: think there needs to be something to make you keep up with dues: 7 year fee is hardship to cough up at one time

33. Alan: you’re going to have people not pay dues unless tribe becomes profitable; think people should have to reapply if they lapse

34. John A: think cards should be issued annually

35. Chief Hatcher: if it gets too complicated, you won’t be able to manage it

36. 2nd Chief Iris: need a compiled list of hardship/ volunteer people

37. Homer: suggests $50 right now or $5/ month

38. Susan: ever 8/1, membership fees are due, whether it’s $50 in advance for the year or $5/ month, regardless of ID expiration date

39. Chief Hatcher: will have to do newsletters each year

40. Pick/up at Work Day

41. 2nd Chief Iris: also involves financial hardships- contact CoC

42. Donnie’s receipts

43. Fuel: $118.02 Check 1522

44. Tractor: 21.11 Check 1523

45. Tractor and Fuel vote

46. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

47. Inactive Status- removing 108 members at midnight

48. Dalton motioned; Homer seconded

49. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

50. 2nd Chief Iris

51. Letter of Commitment needs to be rewritten

52. Linda Hammond: asked for TCard extension, but hasn’t called 2nd Chief Iris

53. Dalton motions to decline her request; Susan seconded

54. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

55. Victoria England: William Moore’s adopted daughter

56. Asked her to send a copy of her adoption papers to have on file

57. Ms. England hasn’t done so

58. Dalton motioned; Homer seconded to allow Buster to handle the file until next open meeting

59. Homer-yes, John-yes, Susan-yes, Richia-yes, Dalton-yes, Scott-yes

60. Elder Doug: don’t think you should take membership away because a spouse dies

61. Johnnie Marie: Kiki Robertson says Gov. Haley sends her regrets that she cannot attend the pauwau this year

62. Chief Hatcher

63. Lobbying firm will help with federal recognition

64. John A: Bennettsville & prison system: great time with small group of guys

65. 2nd Chief Cheryl: JRLong & Life Recovery has 24-25 people

66. Those interested, early spring on a Saturday, will have a certification training

67. At Allendale and Bennettsville now

68. Elder Doug: many of these guys will benefit from drug & alcohol counseling

69. Chief Hatcher: would like to expand it to other tribes in the state

70. DNR Meeting: they want to see that you’re certified

71. Thinking that artist certification should be on back of ID card

72. Let 2nd Chief Iris handle best way to put on certification on card

73. Arts & Committee to make SOP

74. CMA- propose term limits

75. 1st time in awhile that all 3 2nd Chiefs have been present

76. Presented Chief Ben Thompson

77. Dalton: How do you see it working from an administrative point of view?

78. Chief Ben: our members would have to register as Waccamaw, but we would be in Charleston as a band, following Waccamaw constitution and bylaws

79. John T: Would you have someone attending here each month?

80. Chief Ben: yes

81. Elder Doug: how does that benefit the Waccamaw?

82. Chief Ben: more artists, laborers

83. Homer: How can you assure me that you won’t do the same as before?

84. Chief Ben: I can’t

85. Chief Hatcher: don’t put him on the spot

86. John: What would be the difference in his group and say 40 people in Texas meeting monthly? I see it as an advantage to have some distance

87. Homer: How will we know those 40 are active?

88. Susan: Would you come in as a regular member?

89. Chief Ben: yes and as a Chief of the band

90. Homer: Where is it in the constitution that a band can happen?

91. Chief Hatcher: it’s not

92. Homer: How many of these 40 have Native American ties?

93. Chief Ben: all of them

94. Dalton: TRB closed isn’t a major barrier; Council can open/ closes it at anytime. Administrative is different- 5 Chiefs; we’d have to create a new position

95. Chief Hatcher: Talks have to start somewhere. Chief Ben’s been an asset; he has some of the best artists in the state

96. 2nd Chief Cheryl: Winyah are  Waccamaw; banding together

97. Elder Doug: Waccamaw have a good reputation; how are you going to control the band?

98. Issue tabled for now

99. Homer asked Chief Hatcher about the status of John Cox

100. Chief Hatcher: he’s had surgery

101. Homer: he’s got 12 months

Dalton motioned to close the meeting; Homer seconded.

Meeting adjourned 8:12 pm.

Respectfully submitted by Michelle Hatcher on 9/3/13 at 7:03 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
