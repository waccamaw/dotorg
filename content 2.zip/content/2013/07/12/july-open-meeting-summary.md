---
layout: post
title: "July 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/07/13/july-open-meeting-summary.html
post_id: 5649665
custom_summary: false
summary: ""
date: 2013-07-12T19:00:00-0500
lastmod: 2013-07-12T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/07/12/july-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 7/12/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Susan, Dalton, and Homer present.

2. June Minutes read.

3. Dalton motioned to accept; Susan seconded

4. Homer-yes, Susan-yes, Dalton-yes, Scott-yes

5. Financial Report: Alan

6. General Fund: $2873.75

7. Building Fund: $1165.85

8. Please get receipts to Alan/ Michelle ASAP

9. New Business

10. Committee Reports

11. Grants: Michelle

12. Lowe’s Community Grant: due 7/30

13. Working with Rick Hudnall on longhouse

14. Lowe’s Education Grant: 8/1-10/15 for Pauwau

15. Lowe’s Small Project Grant- no date grant, up to $2500

16. Working with Rick Hudnall on roof project

17. Pauwau: Michelle

18. Meeting 7/10, 8/14 at Shoney’s in Conway at 6:30pm

19. Suggestions for 2013 due by Aug 1

20. Contracts for demonstrators are in

21. Neal & Sonya have resigned from committee

22. Budget ready for approval

23. Dalton motioned to accept; Homer seconded

24. Homer-yes, Susan-yes, Dalton-yes, Scott-yes

25. Buildings & Grounds: CoC Scott

26. Roses moved

27. Porch painted by John T

28. Will screen porch in once painting complete

29. New Waccamaw sign at gate

30. Resolution DH-05-03-2013-001: Membership Fees: 3rd Reading

31. Rewrote 3rd “be it resolved” section

32. Dalton motioned to accept with change; Homer seconded

33. Homer-yes, Dalton-yes, Susan-yes, Scott-yes

34. John T: how will people be notified?

35. Dalton: Facebook, tribal website, newsletter

36. 2nd Chief Iris: who will keep track of who has paid?

37. Dalton: bookkeeper

38. Alan F: need a copy of the tribal roll book

39. 2nd Chief Iris: Alan F is spousal; I need tribal permission to send him a copy

40. Alan: would prefer a printout at next meeting

41. Susan: Do Associate members keep getting cards?

42. Dalton: yes, but they can’t vote

43. Susan: they keep getting ID’s

44. Dalton: have no problem charging them ID renewal fees

45. Susan: someone could say drop them to Associate to keep from paying the fee

46. Dalton: I would tell them no

47. 2nd Chief Iris: they need to reapply if they do that

48. CoC Scott: Neal turned in CM, B&G, PW Committee resignations

49. Open council seat: CoC Scott nominated John T

50. Dalton nominated Georgia C

51. Chief Hatcher has to decide

52. Constitution

53. 2nd Chief Iris: Right now, there are two sets of ID’s

54. 1 is full–fledge voting members

55. 1 is TCard for 12 months & then review

56. Designated in database to tell them apart

57. Susan: revisit the Inactive Status resolution to limit term on Inactive

58. Dalton: Wasn’t a rush; why not give them a chance just in case they sue

59. Chief Hatcher: important to clean it up now; set up a Saturday work day

60. 2nd Chief Iris: they violate WIP operating procedures by not keeping information updated

61. Chief Hatcher: they violate the membership agreement to get a membership

62. Dalton: wanted a blanket, simple procedure

63. 2nd Chief Iris: Permanent card is their responsibility to keep updated

64. Susan: Contact 3 times & know some have been contacted more

65. Dalton: 1 was supposed to be by certified mail; Resolution took care of that: after 1 year of no renewal, they’re gone

66. Alan F: Something needs to be in place before federal recognition

67. Susan: set a day aside for next month, 4-5 hours

68. 2nd Chief Iris

69. New ID printer: works well, enough supplies for 1000 cards

70. Neal is moving to be with family, as is Sonya J

71. Would like us to do something for them

72. Need Events Coordinator (ongoing)

73. Donnie’s fuel receipt: $37.75 check 1521 (plus his $20 cash for non-gas items)

74. Homer motioned; Dalton seconded

75. Homer-yes, Susan-yes, Dalton-yes, Scott-yes

76. Chief Hatcher

77. Thanks to Steve & Lori Osborn

78. Steve & Lori O helping with Investor policy letter

79. Recognition Policy

80. Federal 25 CFR 83.7: 1st sustained white contact to today

81. Looks like it will change to 1935 except for part e

82. Part e is kinship to a known Indian entity

83. Dimery settlement: 1813

84. Write BIA, Congressman & ask for their support

85. Class: ½ day soon: pay to decision-makers

86. Ben Thompson: Chief of Winyah: wants to become Waccamaw branch of Winyah

87. Told him to put something in writing to present to Tribal Council

88. Membership fee: people will need to be notified; newsletters will need to be sent

89. Need policies upfront and not as you go

90. Council of Elders and Council Member spots open

91. Rather John T be on Council of Elders

92. John T asked about CM’s not showing up

93. Chief Hatcher: they could ask for a Leave of Absence

94. Dispute over colored version of tribal logo

95. Disclaimer sent to Tribal Council

96. Disclaimer was made out to Elder Jerry and the tribe

97. Susan approached Becky about logo because we were looking at color logo for shirts/ jackets

98. Chief Hatcher: asked Susan to get ahold of her people to make a color logo but price is higher than expected

99. Dalton: know someone who may be able to do it

100. Meeting in Columbia about S611 to stop recognizing groups in SC

101. Prison Program: Elder Doug, John A, asking Steve O

102. John T had several questions answered by Chief Hatcher and Tribal Council about external & internal matters, respectively

103. Rick H: Can we get a sign for the fire circle? (no electronics, pictures, etc…)

104. Elder Doug: Can we open & close with prayer, smudge?

105. Susan: how’s CMA recognition readings?

106. Joey W: nothing of substance through September

107. Chief Hatcher: on groups & 51%- how do they prove the 51% are native?

108. Susan: Work Day: Policy letters, Constitution 8/10 @ 11am-until

Dalton motioned to close the meeting; Homer seconded.

Meeting adjourned 8:12 pm.

Respectfully submitted by Michelle Hatcher on 7/24/13 at 11:07 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
