---
layout: post
title: "January 2013 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2013/01/12/january-open-meeting-summary.html
post_id: 5649661
custom_summary: false
summary: ""
date: 2013-01-11T19:00:00-0500
lastmod: 2013-01-11T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2013/01/11/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 1/11/2013 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Neal, Susan, Dalton, and Homer, present.

2. Neal sworn-in to office

3. December minutes read

            a. Susan motioned to accept; Dalton seconded

                        1. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

4. Financial Report: Michelle

            a. General Fund: $5507.17

            b. Building Fund: $2035.01

5. New Business

            a. Committee Reports

                        1. Grants: Michelle

                                    a. SCAC: money received

                                    b. NCAI: Connect Grant Conference Call 1/16

                                    c. NCAI: 10 $2500 cash prizes to high school students

                        2. Buildings & Grounds: Neal

                                    a. Roof- need to pressure wash & seal

                        3. Arts & Crafts: Susan

                                    a. Meeting past Tuesday

                                    b. All officers remain the same

                                    c. 1 new application, needs hard copy

                        4. Pauwau: Michelle

                                    a. First meeting 1/9; Michelle is chairperson

                                    b. Need to confirm Sonya as voting member

                                                1. Dalton motioned; Neal seconded

                                                            a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

                                    c. New location for meetings: Coastal Ale House: Conway

                                                1. They've given towards WIP causes

                                    d. Suggestions after Aug. 1 will be considered for 2014

                                                1. Budget already approved; money allocated

                                    e. Work days 2 days per month on grounds to prep for pauwau

                                                1. assist with electrical, RV, circle size, etc...

                                    f.  Next meeting: 2/13/2013 at 6:30pm

            b. Proposal: SB-07-08-2011-001: Tribal Secretary Budget: just need 2013 funding

                        1. Office supplies for minutes, applications, etc... $250.82

                                    a. Susan motioned; Dalton seconded

                                                1. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

            c. Membership Files

                        1. Monica Sanders

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

                        2. Austin Swindler

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

                        3. LaShawn Swindler

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

                        4. Alexander Swindler

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

                        5. Courtney Hayes

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

            d. Chief Hatcher

                        1. Business trip to Austria on 1/20/2013

                        2. Tom Rice: make an appointment with him on federal status

                        3. Need to close Tribal Roll Book- Council work days

                                    a. 1 year to earn membership & Council votes on apps again

                        4. Have 8 RV spots again

                        5. No votes accepted from Richia or Robert- no oath of office taken

                                    a. CoC to write letter & rest of Council to sign

                        6. New sign for office: blue/ white logo in memory of Leola Mitchell

                        7. Still looking at CT & TN land

            e. Susan: Tribal site moving to waccamaw.org

            f. Dalton: Suggestion: membership fees: $10/year

                        1. Exclude volunteer work, committee, tribal government

                        2. Contact him with suggestions

                        3. Elder Frank: think everyone should pay fee

                                    a. have Chief Hatcher send every member an itemized list of all                                                  problems we have to pay for

                                    b. Do direct mailing around tax time

            g. Susan: Family Day: 2/16/2013

                        1. cooking: Alan & Johnnie Faver

                        2. boil & hush puppies

                        3. $1 card Bingo

                        4. Georgia: soccer balls

                        5. Sonya: tub of toys

                        6. Allocate  up to $250 for food & drink

                                    a. Dalton motioned; Neal seconded

                                                1. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

            h. Chief Hatcher: need stamps, labels, letterhead for mailing

                        1. Dalton motioned; Susan seconded

                                    a. Susan-yes, Homer-yes, Neal-yes, Dalton-yes, Scott-yes

Neal motioned to close the meeting; Homer seconded.

Meeting adjourned 7:48 pm.

Respectfully submitted by Michelle Hatcher on 1/31/13 at 10:50 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
