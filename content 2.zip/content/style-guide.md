---
title: "Style Guide"
date: 2000-11-17T17:15:37-05:00
layout: "style-guide"
---

# Waccamaw.org Style Guide

This page documents the visual design system, colors, typography, and branding elements used throughout the Waccamaw Indian People website.
