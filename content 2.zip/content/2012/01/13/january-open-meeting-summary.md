---
layout: post
title: "January Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/01/14/january-open-meeting-summary.html
post_id: 5649633
custom_summary: false
summary: ""
date: 2012-01-13T19:00:00-0500
lastmod: 2025-11-22T19:02:04-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/01/13/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 01/13/2012 held at the Senior Center in Aynor, SC

1. CoC Scott, and CM's Homer, Robert, and Neal present.

2. December Minutes read

            a. Neal motioned to accept; Homer seconded

                        1. Homer-yes, Neal-yes, Robert-yes, Scott-yes

3. Financial Report

            a. General Account at BB&T: $9305.92

            b. Building Fund Account at CNB: $3299.65

            c. 2nd Chief Iris: Transfer of Bookkeeping to Michelle: receipts, records, etc...

                        1. Authorization for Quickbooks Pro 2012 Software: $230

                                    a. Robert motioned; Neal seconded

                                                1. Homer-yes, Neal-yes, Robert-yes, Scott-yes

                        2. 2012 Secretary Budget $625 Includes Software vote just taken

                                    a. Neal motioned; Robert seconded

                                                1. Homer-yes, Neal-yes, Robert-yes, Scott-yes

4. Online Votes

            a. Newspaper Plaque: Neal-no, Robert-no, Homer-no, Scott-no

            b. Donnie's Trailer: Neal-yes, Robert-yes, Scott-yes, Homer-yes

5. Leave of Absence: Dalton's letter presented

            a. Scott will go month by month with him

            b. Dalton will resign if he misses 3 meetings

6. Committee Reports

            a. Grants: Michelle

                        1. SCAC 3/15

            b. Pauwau: Michelle

                        1. Advertising book from ICC, will email to committee

                        2. First meeting in Feb; will email date when we solidify it

                        3. All welcome to volunteer, please make sure we have updated email

            c. Building & Grounds: Neal

                        1. Donnie needs help at cemetery- set up a work day

                                    a. 1st Sat. in Feb.

                        2. House: On grounds; other office- shower soon

                                    a. permits, concrete done

                                    b. law: rock or brick foundation

                                    c. $2500 more

                        3. Michelle: to Council- please let me know what check is for so money                                    comes from right account

7. Donnie's Fuel: $35.60

            a. Neal motioned; Homer seconded

                        1. Homer-yes, Neal-yes, Robert-yes, Scott-yes

                        2. Check 1410 to Sunhouse 1

8. Family Day: 2nd Chief Iris

            a. Please set up a tent for the kids

            b. Susan is trying to get a caterer

9. Membership Files

            a. Joan Ammons

                        1. Homer-yes, Neal-yes, Robert-yes, Scott-yes (4yes, 3absent)

            b. Jeremiah Mann

                        1. Mentioned at December meeting- let him serve & come back

                        2. 2nd Chief Iris: extend T-card 7years because he is in the military
                                    a. Neal motioned; Robert seconded

                                                1. Homer-yes, Neal-yes, Robert-yes, Scott-yes

10. 2nd Chief Iris

            a. Procedures are her next project after files

            b. Michelle's ID card- what expiration date- Secretary but also Associate Member

                        1. Council: use Dalton's expiration date

11. Craig Talbot

            a. Will be out of town for Feb. meeting

            b. Gave list of events he has participated in for the last month

12. Elder Doug

            a. Thanked everyone for the support they gave after loss of Ms. Kathleen

            b. Homer: Also keep Cha'kwaina & husband in prayers

Homer  motioned to close the meeting; Robert seconded.

Meeting adjourned 7:30 pm.

Respectfully submitted by Michelle Hatcher on 1/29/12 at 3:13 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
