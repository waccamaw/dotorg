---
layout: post
title: "October 2012 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/10/06/october-open-meeting-summary.html
post_id: 5649659
custom_summary: false
summary: ""
date: 2012-10-05T19:00:00-0500
lastmod: 2012-10-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/10/05/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/5/2012 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Neal, Susan, Dalton, and Richia present. Homer arrived when discussing files.

2. September minutes read.

            a. Dalton motioned to accept; Neal seconded

                        1. Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

3. Financial Report: Michelle

            a. General Fund: $4717.02

            b. Building Fund: $1467.71

4. Online Votes

            a. 9/12 Accept the program book

                        1. Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

            b. 9/13 Purchase gravel for driveway

                        1. Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

            c. 9/21 Get logo done in color for side of office

                        1. Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

            d. 9/21 Videos/ calendars

                        1. Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

                        2. CoC Scott: Elder Doug will finance calendars & we can pay him back

                                    a. CM Susan: late in year- 2013- we would have to sell now

                                    b. CM Richia: people will buy for photos & info

                                    c. Chief Hatcher: do a 2014 calendar

                                    d. Elder Doug: don't know that people will buy a year in advance

                                    e. Donnie: make it a perpetual calendar

                                    f. $800 for 2013 Richia motioned; Neal seconded

                                                1. Neal-yes, Susan-yes, Dalton-abstain, Richia-yes, Scott-yes

5. Committee Reports

            a. Grants: Michelle

                        1. SCAC: Ms. Carroll said they were slow on getting packets out

                        2. Lowe's grant: requires eligibility test, will look into it

                        3. Elder Hank: call Food Lion

            b. Building & Grounds: Neal

                        1. Roof needs to be done

                        2. Asphalt: 260+75: needs to be spread out

                        3. Work day Sunday

                                    a. Donnie: my sewer needs fixed

            c. Arts & Crafts: Susan

                        1. Meeting on 10/9

            d. Pauwau: Michelle

                        1. Meeting 10/10

                        2. Vendors application still coming in

6. Elections Committee 2012

            a. Council appointed Michelle, Susan, Jerry, Becky, and Angela to count ballots

7. Susan for Iris about files

            a. Files approved- fees paid by check and check bounced- send files back to people

                        1. Chief Hatcher: add to constitution- not member till checks clear

                        2. CM Richia: all things should be in order before they are members

                        3. CM Susan: change wording on application to money order/ cashier's check

                                    a. or valid process fee

                        4. CM Dalton: only limit seen in constitution is due process

                                    a. until requirements are met, they aren't members

                        5. For list of people whose checks have bounced:

                                    a. Homer- no, Neal-no, Susan-no, Dalton-no, Richia-no, Scott-no

                                    b. vote means they aren't members yet

8. Resolution DH-08-03-2012-001: Creating an Inactive Membership Status: 3rd Reading

            a. Neal motioned to accept; Homer seconded

            b. Homer- yes, Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

9. Elder Jerry: logo: color on vinyl sign- red hawk- paid for by Elder Jerry

            a. T-shirts- blue or white with logo

                        1. 13-48: $9.50 or 144: $7.55

                        2. 7 day notice to start

            b. Decal: 5x5

                        1. $2.25-3.00

            c. Chief Hatcher: he can't copyright our logo; will have to sign off on contract

10. Donnie's fuel receipt: $80.10 Check 1455

            a. Susan motioned; Homer seconded

            b. Homer- yes, Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

11. Rick: back deck & nails: $138.19 Building Fund

            a. Neal motioned; Homer seconded

            b. Homer- yes, Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

12. Michael Goodson: asphalt: $335.00 Check 1456

            a. Neal motioned; Dalton seconded

            b. Homer- yes, Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

13. Chief Hatcher

            a. Rick Hudnall application: ancestry not filled out, but worked a lot here

                        1. Homer motioned; Dalton seconded pending picture

                        2. Homer- yes, Neal-yes, Susan-yes, Dalton-yes, Richia-yes, Scott-yes

            b. HobCaw presentation: $300 for us

            c. Meeting with Ben Thompson: Chief of Winyah

            d. USC- Lancaster: Native American Museum- leans Catawba

                        1. Right & responsibility to put WIP items in there

                        2. Items would belong to us, just on display there

            e. Documentary: $642: Sell for what we want- $15-20 to get back what it cost us

                        1. SC-ETV, USC, CMA mentioned

            f. Pauwau ad running on TV now

            g. Online tickets sold at half price

            h. For every $100 spent, we need 6 people through the gate

            i. Event: 10/6  McColl  Pauwau

            j. Continue work on Policy Book; shouldn't need to start from scratch

            k. Allendale Prison: 10/10

                        1. Working with prison system so inmates can ask for & use Native spiritual leaders

                                    a. SC doesn't recognize them at the moment

            l. CoC Scott: certificate to Constable David Windburn for Pauwau Security

14. CM Homer

            a. Donnie's trailer

                        1. Paul replaced the sink, but venting still wrong

                        2. Sewer needs fixed

                        3. CoC Scott: work with Paul & tell us what you need

            b. Signs on table from Lori

                        1. Waccamaw, Pauwau, Handicapped

Neal motioned to close the meeting; Dalton seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 12/06/12 at 10:45 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
