---
layout: post
title: "May 2012 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/05/05/may-open-meeting-summary.html
post_id: 5649656
custom_summary: false
summary: ""
date: 2012-05-04T19:00:00-0500
lastmod: 2012-05-04T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/05/04/may-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 05/04/2012 held at the Senior Center in Aynor, SC

1. CoC Scott, CM's Susan, Neal, and Dalton present. Homer arrived shortly after meeting started.

2. April minutes read

            a. Dalton motioned to accept; Susan seconded

            b. Dalton-yes, Susan-yes, Neal-yes, Scott-yes

3. Financial Report

            a. General Fund: $6996.39

            b. Building Fund: $2407.65

4. Donnie's Fuel Receipt: $42.84

            a. Neal motioned; Dalton seconded

            b. Dalton-yes, Susan-yes, Neal-yes, Homer-yes, Scott-yes

5. Committee Reports

            a. Grants: Michelle

                        1. Waiting on word from SCAC

            b. Arts & Crafts: Susan

                        1. Nothing from Carol Ann

            c. Pauwau: Michelle

                        1. Send suggestions for committee to the committee

                        2. Ads have been sold

                        3. Vendor's app available for download on our website

                        4. Meetings are Wednesday after the tribal meeting

            d. Buildings & Grounds: Neal

                        1. Found leak

                        2. Need to shovel gravel

                        3. Carpet able to go back over; linoleum not as easy

                        4. Bearing wall- must be careful

                        5. Need plumbing & A/C

                                    a. 2nd Chief Iris: can old A/C be used?

                                                1. Neal: not sure; not enough knowledge

                                                2. Susan: hotel-type

                                    b. Donation of vacuums: Hank, Scott

6. Membership Files Updated

            a. Deborah Beaver

                        1. Dalton-yes, Susan-yes, Neal-yes, Homer-yes, Scott-yes

            b. Jonathan Beaver

                        1. Dalton-yes, Susan-yes, Neal-yes, Homer-yes, Scott-yes

            c. Jacob Beaver

                        1. Dalton-yes, Susan-yes, Neal-yes, Homer-yes, Scott-yes

            d. Jennifer Michelle Hatcher

                        1. Dalton-abstain, Susan-yes, Neal-yes, Homer-yes, Scott-yes

7. Chief Hatcher

            a. NCAI

            b. Child born to tribal parents-are they automatically members?

                        1. 2nd Chief Iris: they are; they still have to have a file

                        2. They get a card at age 10, with membership based on their parents

                        3. They get a new card at 18

                        4. Karson Kross Bryant

                                    a. Dalton-yes, Susan-yes, Neal-yes, Homer-yes, Scott-yes

            c. Webb funding people for college and using our name

                        1. received a call from a young man who tried to use Chief Hatcher's                             mother's number

            d. Who manages associate members?

                        1. Susan: Chief

                        2. Dalton: still have to go before Council to be voted in

                        3. Iris: Council approved them; Council would take them out

                        4. Chief Hatcher: needs to be decided

                        5. Neal: bring person in 1/2 hour before a meeting with the Chief; make                                     them inactive

                        6. Dalton: at inactive and continuous issues, removal

                        7. Chief Hatcher: okay with that; needs to be written up

            e. Service of Legal Documents

                        1. People recently served

                                    a. Refused to sign

                                    b.  1 has a new address

                                    c. 1 served at last known address

                        2. Judge wants to hold a hearing

                        3. Recommendation to Judge- we met the requirements of the proposal

            f. Alleged Discrimination at Golden Corral at end of Hwy 22 in MB

                        1. Lawsuit: individually & as a tribe

Susan  motioned to close the meeting; Dalton seconded.

Meeting adjourned 7:15 pm.

Respectfully submitted by Michelle Hatcher on 5/30/12 at 9:58 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
