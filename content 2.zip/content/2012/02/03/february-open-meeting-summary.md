---
layout: post
title: "February 2012 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/02/04/february-open-meeting-summary.html
post_id: 5649653
custom_summary: false
summary: ""
date: 2012-02-03T19:00:00-0500
lastmod: 2012-02-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/02/03/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 02/03/2012 held at the Senior Center in Aynor, SC

1. CoC Scott, and CM's Susan, Robert, and Neal present. 2nd Chief Iris served as proxy for CM Homer and 2nd Chief Phil served as proxy for CM Dalton.

2. January Minutes read

            a. Neal motioned to accept; Susan seconded

                        1. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris (Homer)-yes, 2nd Chief                  Phil (Dalton)-yes, CoC Scott- yes

3. 2nd Chief Phil and 2nd Chief Iris sworn-in to office

4. Rolling Thunder presented tribe with plaque and letter, expressing gratitude for allowing us to have the Missing Man Table at the pauwau and for paying tribute to veterans

5. Financial Report: Michelle

            a. General Funds Account: $10,015.72

            b. Building Fund Account: $3294.65

6. Online Votes

            a. 1/19 Put Genesis Foundation donation check into Building Fund account

                        a. Susan-yes, 2nd Chief Iris (Homer)-yes, Neal-yes, Robert-yes, CoC                          Scott-yes

            b. 1/22 Block Underpinning using 2nd quote

                        a. Susan-yes, Neal-yes, Robert-yes, 2nd Chief Phil (Dalton)-yes, 2nd                           Chief Iris (Homer)-yes, CoC Scott-yes

7. Committee Reports

            a. Grants: Michelle

                        1. SCAC 3/15

            b. Building & Grounds: Neal

                        1. Block work started

                        2. Ronnie: idea- dig up river birch trees to plant around fire circle and                            outline parking area

                                    a. Neal: let's blueprint it first

                                    b. Dance circle needs something; like between vendors and circle

                                    c. 2nd Chief Phil: motion to trust Ronnie's judgment/ CoC Scott                                                 seconded

                                                1. 2nd Chief Iris: not certain about around dance circle-                                                             high traffic area

                                                2. Ronnie: they could be 30 feet apart and take several                                                  years to grow

                                                3. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris                                                                   (Homer)-yes, 2nd Chief Phil (Dalton)-yes, CoC Scott- yes

                        3. Donnie's pipes: galvanized pipes and bad drinking water need to be                           looked at

                        4. Work Day: 2/4 at 8am with stiff hoes at big cemetery

            c. Arts & Crafts: Susan

                        1. No word from Carol Ann on next meeting

            d. Pauwau: Michelle

                        1. Meeting 2/8 at Shoney's at 6:30pm to include discussion on pets and                                     who we give certificates to on Family Day

                        2. Please make sure we have your email address if you wish to join the                          discussion- some discussions change rapidly or require answers quickly

                        3. Start talking to your contacts about the pauwau for advertising                                               purposes- all feedback forms show that as the weakest element from last                                   year

                        4. Send all information for the program book to Susan. If you don't have                                    her email address, send it to me and I'll forward it to her.

8. Family Day

            a. 2nd Chief Iris asked about a Fire Ceremony- Robert says there will be 2

                        1. the first will be at noon

            b. Susan: the caterer (Dwayne) said it would be about $5 per person for 45 people

            c. port-o-potty cost- not the same as taking pw costs and dividing to get to 1 day

            d. Neal motioned to use Aynor Park at 1pm if we can get it; Susan seconded

                        1. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris (Homer)-yes, 2nd Chief                  Phil (Dalton)-yes, CoC Scott- yes

            e. Use caterer (Dwayne)- Susan motioned

                        1. Elder Doug: what about each family bring their own?

                        2. Susan motioned that each family bring its own picnic lunch instead of                          tribe using a caterer; 2nd Chief Iris (Homer) seconded

                                    a. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris (Homer)-yes,                                              2nd Chief Phil (Dalton)-yes, CoC Scott- yes

9. Membership Files

            a. Isabel Jasmine Veliz

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- abstain, 2nd                                 Chief Phil (Dalton)-yes, CoC Scott-yes (5 yes, 1 abstain, 1 absent)

            b. Lesly Rianna Veliz

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- abstain, 2nd                                 Chief Phil (Dalton)-yes, CoC Scott-yes (5 yes, 1 abstain, 1 absent)

            c. Valente Ivan Veliz

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- abstain, 2nd                                 Chief Phil (Dalton)-yes, CoC Scott-yes (5 yes, 1 abstain, 1 absent)

            d. Jadein A. Toler

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- abstain, 2nd                                 Chief Phil (Dalton)-yes, CoC Scott-yes (5 yes, 1 abstain, 1 absent)

            e. Iseiah Stensind

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- abstain, 2nd                                 Chief Phil (Dalton)-yes, CoC Scott-yes (5 yes, 1 abstain, 1 absent)

            f. John Abrams

                        1. Neal-yes, Susan-yes, Robert-yes, 2nd Chief Iris (Homer)- yes, 2nd                          Chief Phil (Dalton)-yes, CoC Scott-yes (6 yes, 1 abstain)

            g. Tribal Secretary's Note: 2nd Chief Iris had not viewed files a-e

10. Susan: Elections are coming up. Email Michelle if you want to run so we can put your letter of intent in the newsletter.

11. 2nd Chief Iris: Need Member's feathers & Postage ($44)

            a. Council needs to set a price on the donated building- have to report fair market                      value

                        1. Ronnie: tax assessor's office could ballpark it

                        2. Chief Hatcher to call and check it out

                                    a. Neal motioned; Robert seconded

                                                1. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris                                                                   (Homer)-yes, 2nd Chief Phil (Dalton)-yes, CoC Scott- yes

12. Chief Hatcher

            a. Building Fund: 14 committed to help

            b. Council: start thinking about closing roll book as we get more help with          recognition

            c. Resolution HH-01/03/2012-02 Disbursement Criteria

                        1. Susan: can it be a living document?

                                    a. Chief Hatcher: if you make it that way

                        2.  Susan: contributions: too open-ended- my definitions could be different                     than another's

                                    a. 2nd Chief Iris: think it should be based on accomplishment

                                    b. Chief Hatcher: disagreed; think it has to be based on heart &                                                 intent

                        3. Susan: how do we determine the increase to give?

                                    a. Chief Hatcher: goes up by 20

                        4. 2nd Chief Iris: seen people given certificates & feathers that didn't earn                                  it or because of favoritism

                                    a. Ronnie: that happens all over

                        5. Ronnie: suggest closing roll book when recognition is submitted

            d. Resolution HH-01/03/2012-01: Disbursement Criteria and Donated Moneys

                        1. Only requires 1 reading; Susan seconded

                        2. Robert-yes, Susan-yes, Neal-yes, 2nd Chief Iris (Homer)-yes, 2nd Chief                  Phil (Dalton)-yes, CoC Scott- yes

            e. History Project: Susan needs a couple of pictures

            f. ANA is asking for readers

            g. Chief Hatcher to ask for Council salary for work day in meeting on 2/4

                        1. salaries only applies to those required to be at the meeting

            h. Past Agreement with Mr. Henry to be disregarded

                        1. Susan suggests a one-time finder's fee

                        2. Ronnie suggests either give them a deadline or move on

                        3. Chief Hatcher to see what meeting holds

            i. Chief Hatcher asked if the tribe wanted him to prosecute people for stealing and         keeping property despite order

Susan  motioned to close the meeting; Neal seconded.

Meeting adjourned 8:55 pm.

Respectfully submitted by Michelle Hatcher on 2/14/12 at 7:56 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
