---
layout: post
title: "April 2012 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/04/07/april-open-meeting-summary.html
post_id: 5649655
custom_summary: false
summary: ""
date: 2012-04-06T19:00:00-0500
lastmod: 2012-04-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/04/06/april-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 04/06/2012 held at the Senior Center in Aynor, SC

1. CoC Scott, CM's Susan, Neal, Dalton, Robert, and Homer present.

2. March minutes read

            a. Susan motioned to accept; Robert seconded

            b. Homer-yes, Susan-yes, Neal-yes, Dalton-abstain, Robert-yes, Scott-yes

3. Donnie's fuel receipt: Sunhouse 1: $66.68 check 1427

            a. Neal motioned; Dalton seconded

            b. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

4. Financial Report

            a. General Fund: $7540.27

            b. Building Fund: $1990.65

5. Online Votes

            a. Tar: Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            b. Fertilizer: Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            c. Join NCAI: Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

6. Committee Reports

            a. Building & Grounds: Neal

                        1. tarring roof, may still need supplies

                        2. repairing water, A/C, roof, floors, need 5 pieces of plywood

                        3. electrical issues, carpet

                        4. Jeff to do all work for $1500

                        5. Wayne to also email Scott about what he thinks building needs

                        6. Cheryl to also check on A/C unit

            b. Pauwau: Michelle

                        1. Nominate Georgia for voting membership

                                    a. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-                                         yes

                        2. Next meeting 4/11 at 6:30 at Shoney's in Conway

                        3. Program Book idea: Susan:   one or two-liner for Council (meet your                                     Tribal Council)

            c. Arts & Crafts: Susan

                        1. Talked to Carol Ann & suggested internet meeting

                        2. Nominated Carol Ann for Chair

7. Membership Files

            a. Maxie Sellers

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            b. Billie Sellers

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            c. Georgia Comfort

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            d. Mark Sellers

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

8. Chief Hatcher

            a. Mentioned & welcomed Georgia Comfort

            b. Need $40 for NCAI: Neal motioned; Robert seconded

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            c. Homes that need repairs: address, what needs to be done, but you must own             your place

            d. Native American Commission in SC

                        1. Need vote to put Susan on it: Neal motioned; Robert seconded

                        2. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            e. Cemeteries now federally protected

                        1. Hatcher: Juno Rd, Dimery: Pisgah Church Rd, Bethel: Bethel Rd

            f. SoS Registration Renewal

            g. Founding member of SC Council  of Tribes

            h. TV Documentary almost finished: to air on UNC-TV, USC-TV, PBS

                        1. Will get copies for those on it

            i. USC wants to archive our docs: Dalton motioned; Neal seconded

                        1. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            j. Letter about Craig to go in his file

            k. Resolution HH-01/03/2012-02: Disbursement Criteria: 3rd Reading

                        1. Robert motioned to accept after typo changes are fixed; Susan seconded

                        2. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            l. Resolution J-HH004/06/2012-01: Recognition of Northern Chickamauga       Cherokee tribe of Missouri

                        1. Susan seconded

                        2. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            m. Recognition of David Winburn, Sr

                        1. Homer motioned; Robert seconded

                        2. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

            n. Tuscarora 5/13-14/2012- Raffling Queen Ridge Pendleton Blanket

                        1. $1 ticket or 6 tickets for $5

                        2. Susan motioned; Dalton seconded

                        3. Homer-yes, Susan-yes, Neal-yes, Dalton-yes, Robert-yes, Scott-yes

Susan  motioned to close the meeting; Neal seconded.

Meeting adjourned 8:30 pm.

Respectfully submitted by Michelle Hatcher on 5/01/12 at 2:20 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
