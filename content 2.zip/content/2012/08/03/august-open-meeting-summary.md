---
layout: post
title: "August 2012 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2012/08/04/august-open-meeting-summary.html
post_id: 5649658
custom_summary: false
summary: ""
date: 2012-08-03T19:00:00-0500
lastmod: 2012-08-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2012/08/03/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 08/3/2012 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM's Susan, Neal, Homer, Robert, and Dalton present. Richia arrived shortly after meeting started.

2. July minutes read

            a. Neal motioned to accept; Dalton seconded

                        1. Neal-yes, Robert-yes, Dalton-yes, Homer-yes, Susan-yes, Scott-yes

3. Financial Report: Michelle

            a. General Fund: $4544.48

            b. Building Fund: $1145.70

4. Online Votes

            a. lawn mower blades

                        1. Neal-yes, Robert-yes, Dalton-yes, Homer-yes, Susan-yes, Scott-yes

5. Committee Reports

            a. Grants

                        1. SCAC: Michelle

                                    a. Legislature overrode the Governor's vetoes

                                    b. We will receive $1260 on a 1:1 match

            b. Buildings & Grounds: Neal

                        1. Work Day: 8/4 @ 10AM - Ramp, roofing

                        2. Driveway done, grass coming up from being planted 1 year ago

            c. Arts & Crafts: Susan

                        1. Choker came in from Susan Mack

            d. Pauwau: Michelle

                        1. We are looking for older pictures of the grounds for the program book

                        2. We are looking for cups, plates, napkins, sugar/ sugar substitutes, toilet paper for the pauwau and general use

                        3. Tribal Member vending : 10ft: $93.75, 20ft $168.75, food booth: $243.75

                        4. As always, be accurate with your information and specific about what you are selling

                        5. Next meeting 8/8 @ Shoney's @ 6:30pm

6. 2nd Chief Iris: Expired ID Numbers

            a. Members possibly in Tim Creel's tribe need to be contacted by Chief Hatcher or CoC Scott to verify dual membership (against constitution)

            b. Give 1 more chance to people on more than sheet

                        1. Dalton: put them all in inactive status tonight

            c. Problem with people not signing Tribal Roll Book- give same procedure as TCard- sign book before card is renewed

            d. Chief Hatcher: tribal law says is if a parent leaves the tribe, the kids go too; want to change it so kids can stay

                        1. 2nd Chief Iris: good project for 2nd Chief Cheryl

7. Res: DH-08-03-2012-001: Creating an Inactive Membership Status

            a. Created to deal with people that have let things expire and stay expire

                        1. Chief Hatcher: due process has to be in writing

                        a. Process has to be managed

                                    1. Dalton: may need a committee to handle it

                        b. Susan motioned; Dalton seconded

                                    1. Richia-yes, Neal-yes, Robert-yes, Dalton-yes, Homer-yes, Susan-yes, Scott-yes

8. Membership File

            a. Martha Todd-Soles

                        1. Neal-yes, Richia-yes, Neal-yes, Dalton-yes, Homer-yes, Susan-yes, Scott-yes

9. Chief Hatcher

            a. Recognition to Rick Hudnall & Paul for doing the primer

            b. Need to work on doing the indoor flooring

            c. Held Tribal court- 30 day waiting period because of appeal process

            d. Judge heard cemetery case

            e. Council given business cards

            f. Letters of Intent received from Neal, Robert, and Richia

10. GoNativeAmerican.com Presentation: Jack & Stan

            a. Everything Site

                        1. your tribe shown nationally

                        2. history- map

                        3. webpage- free

                        4. marketplace to sell crafts (coming soon)

                        5. gathering (Facebook-like)- blogs, classifieds, calendar

                                    a. http://www.nativeamericangathering.com/

                                                1. already open

            b. they do not add people to the site without verifying you with your tribe first

            c. free to set up; sell an item, there is a commission to cover overhead costs

            d. G+ , Like, & Twitter buttons will be on individual pages

            e. Tribe benefits from each sale in the tribal store

Neal motioned to close the meeting; Robert seconded.

Meeting adjourned 8:28 pm.

Respectfully submitted by Michelle Hatcher on 8/16/12 at 2:00 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
