---
layout: post
title: "December 2011 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2011/12/03/december-open-meeting-summary.html
post_id: 5649652
custom_summary: false
summary: ""
date: 2011-12-02T19:00:00-0500
lastmod: 2011-12-02T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2011/12/02/december-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 12/02/2011 held at the Tribal Office in Aynor, SC

1. CoC Scott, and CM's Dalton, Homer, Robert, Neal, and Susan present. CM Richia arrived at 6:55 just as minutes were being approved.

2. Res. DH-12-02-2011-001 Certification of the 2011 Tribal Election

            a. Neal motioned; Homer seconded

            b. Homer-yes, Dalton-yes, Robert-yes, Neal-yes, Scott-yes (5yes: 2 absent)

            c. Council sworn in

            d. Elect CoC

                        1. Dalton nominated Scott;  Homer seconded- Scott will accept

                        2. Homer-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes, Scott-abstain

            e. Chief sworn in

3. October minutes read

            a. Clarification: 4(c): tractor (tires)

            b. Neal motioned to accept with change; Dalton seconded

            c. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes, Scott-yes

4. Financial Report

            a. $10, 675.22 in bank

5. Online Votes

            a. Donnie's trailer: Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes,   Scott-yes

6. Committee Reports

            a. Grants: Michelle

                        1. ANA 1/31

                        2. SCAC 3/15

            b. Arts & Crafts: Susan

                        1. 5 vended at pauwau

                        2. elections in  January

                        3. training classes

            c. Building & Grounds: Neal

                        1. Black mold in Donnie's trailer- more boards for approval- $1000

                                    a. Jeff to give proposal on cost to fix before money given out

                        2. Pond filled in, but still a pond there. gate approval?

                        3. Susan on committee now & will work on budget for committee

                        4. don't have all the information on the donated house yet

                        5. Homer: pond has to be kept up if we keep it

                        6. Neal: would like to take up a collection for Donnie for Christmas for                          work he does

            d. Pauwau: Michelle

                        1. Unconfirmed raffle by vendor

                        2. Gaffney- gives free vendor spots

                        3. Homer & Chief Hatcher: we give away too much

                                    a. A&C committee has been talking for a year now to get our own                                            young  people to learn drum & dance

                        4. Homer: biggest complaint at gate: roads & ads

                        5. pet issues: one bit Chief of Police

7. Res. J-HH-12-02-2011-001 Second Chief Appointments

            a. Susan motioned; Richia seconded

            b. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes, Scott-yes

            c. Cheryl sworn in as 2nd Chief and Richia sworn in as CM

8. Membership Files

            a. Grayson R. Osborn

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            b. Amber M. Osborn Pearson

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            c. Steve Osborn

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            d. Joey  F. Watford

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            e. Elizabeth Osborn

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            f. Christopher M. Watford

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            g. Christine L. Osborn (S)

                        1. Homer-yes, Richia-abstain, Dalton-yes, Neal-yes, Robert-yes, Susan-                                  yes, Scott-yes

            h. Note: Richia abstained because she hadn't reviewed the files before they were            being voted on

9. CoC Scott: Bookkeeping: authorize Michelle $598 to take course from Penn Foster

            a. Susan motioned; Homer seconded

            b. Homer-yes, Richia-yes, Dalton-yes, Neal-yes, Robert-yes, Susan-yes, Scott-yes

            c. check 1405

10. 2nd Chief

            a. Susan would like to thank everyone for their support during her time as 2nd   Chief

11. Chuck Mann: Can a member in Afghanistan let his father sign the roll book for him?

            a. 2nd Chief Cheryl: his Power of Attorney can sign

            b. Chief Hatcher: a note can be put in his file

12. Chief Hatcher

            a. We should take the building that's been donated to us

                        1. will co-sign a loan if we can get enough people to help pay it back

                                    a. all money would go towards the building

                                    b. Res: HH-12/02/2011-003: Authorization for Targeted Donations

                                                1. Chief Hatcher motioned; Susan seconded

                                                2. 2nd Chief Cheryl: why not open it up to all types of                                                   maintenance?

                                                            a. Chief Hatcher: with $7000, there's an end in sight

                                                            b. $7000 doesn't include repairing the floor

                                                3. Homer: how's the plumbing, wiring?

                                                4. Susan: can meet at Senior Center/ Library when house is                                                       moved here

                                                5. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-                                                         yes, Susan-yes, Scott-yes

            b.  Res. HH-12/02/2011-04: Authorization to Secure a Loan in the Name of     Waccamaw Indian People

                        1. Chief Hatcher motioned; Susan seconded

                        2. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes,                                  Scott-yes

            c. Res. J-HH-12-02-2011-002: Assistant to the 2nd Chief External Affairs       Appointment

                        1. Chief Hatcher motioned; Neal seconded

                        2. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes,                                  Scott-yes

            d. Letter to Fab4 about missing items

                        1. Pete Bryant gave documents to Chief Hatcher

                        2. James Webb emailed Homer

                        3. Pete requests his membership again & retain his old number

                                    a. Richia: yes; haven't we all done things?

                                    b. Homer: he should have to start over & apologize in open                                                       meeting

                                    c. Elder Doug: he made a conscious decision to do it

                                    d. 2nd Chief Cheryl: an apology won't be enough

                                    e. Trevor: it was our property; why can't this be his punishment?

                                    f. Elder Doug: bring it up 5 years from now

                                    g. Elder Frank: he's (Pete) only guilty of  being ignorant

                                    h. Elder Dan: he's (Pete) guilty of being led

                                    i. Chief Hatcher: think Elder Doug position might be best

                                    j. Dalton: When we took Fab4 back, all their other members were                                             screwed

                                                1. Makes me want to give them all opportunity to apply

                                                2. Also: letting them back in allows them to go before                                                    Ronnie

                        4. Revisit in 5 years, but without old number

                        5. Elder Doug: we need a PR Committee

            e. General James Vaught: veterans support group

                        1. would like to use our Federal ID showing we support their effort getting                     houses for disabled

                        2. Council approve

            f. Received a plaque from the Census Bureau

            g. Coastal Observer article framed: cost $200 to keep

                        1. Neal motioned not to keep; Susan seconded

13. Susan: School Day: $7500 ( up $400 from last year)

            a. Will have to increase to 3 days or more than once per year

14. Homer: about volunteer dinner

            a. thought he was told to resign if he didn't agree with position

            b. Dalton: there are people I'm going to anger fairly often

            c. Neal: going to argue my opinion to bitter end

            d. Dalton: not about having to honor them; it's about having the opportunity to    honor them

15. Donnie's receipts

            a. $112.17 to Sunhouse 1: Homer motioned; Dalton seconded

            b. Homer-yes, Richia-yes, Dalton-yes, Robert-yes, Neal-yes, Susan-yes, Scott-yes

            c. CoC Scott has one receipt for $40 at home

            d. check 1320

16. Authorize $100 for Billy

            a. check 1402

Susan motioned to close the meeting; Homer seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 1/5/12 at 11:26 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
