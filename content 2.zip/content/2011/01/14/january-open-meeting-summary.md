---
layout: post
title: "January 2011 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2011/01/15/january-open-meeting-summary.html
post_id: 5649647
custom_summary: false
summary: ""
date: 2011-01-14T19:00:00-0500
lastmod: 2011-01-14T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2011/01/14/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

1.      Tribal Open Meeting Summary 1/14/2011 held at the Tribal Office in Aynor

1.      December minutes read.

            A. Dalton reminded people about email of minutes

            B. Michelle reminded people about audio of minutes

C. Richia: comment on 9A- language isn't for us to decide; it is Catawba

1. Homer volunteered Richia to help Mr. Moore with language

D. Richia: comment on 10C- who is that 1 person?

1. answer: groundskeeper (currently Donnie); only 1 residence on grounds

E. Dalton motioned to accept; Homer seconded

1. Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

2.      Financial Report

A. $6347.97 in bank

B. Does not include bills except the water bill

3.      Online Votes

A. Election Certification format change

1.      Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

B. Letterhead

2.      Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

4.      Resolution SB-10-01-2010-001 Establishing Elections Committee- 3rd reading

A. Neal motioned; Dalton seconded

B. Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes (1 absent: Robert)

5.      Committee Reports

A. Building & Grounds: Neal

1.      Need electricity to storage trailer

2.      Floor in office should be fixed before next meeting

3.      Donnie has list of things he needs

4.      Check with Chief Hatcher/ Derek about heater

B. PW: no report

C. Grants: Michelle

5.      Nothing new to report

D. Arts & Crafts: Brian

6.      Meeting next Friday @ 3pm

7.      Elect director and officers

8.      Expect some to resign from voting membership

9.      Will update Council

6.      Vote to loan a tribal member $200 with promissory note signed: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-abstain, Scott-yes

7.      Membership files

A. Brenda Odem: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

B. Christopher Barber: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

C. Amanda Veliz: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

D. Teresa Jones: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

E. Murray Jones III: Homer-yes, Richia- yes, Neal-yes, Dalton-yes, Jeanie-yes, Scott-yes

8.      Craig Talbot

A. Provided gifts for CoC Scott Beaver, Chief Hatcher, 2nd chief Iris Ewing, and CM Homer Johnson

B. Read an accounting of where he's been and what he's done over the last year into the record

9.      CoC Scott about Chief Hatcher

A. Chief Hatcher is in Columbia and had had a meeting with the attorney

B. Chief Hatcher can be contacted via email if you need him

10.  Recognition

A.  CM Neal recognized Ricky from Whiteville and would like to see him and more of the young folks more at the pau wau

11.  CM Homer asked about plans for Family Day

A. The weekend falls around Feb. 19

B. Will have to check with Linda

12.  Elder Doug: thinks calendars are good advertising for tribe and brought some to show.

Homer motioned for the meeting to end; Neal seconded.

Meeting adjourned at 7:30pm.

Respectfully submitted by Michelle Hatcher on 1/21/2011 @ 3:08pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
