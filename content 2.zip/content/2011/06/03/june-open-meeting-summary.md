---
layout: post
title: "June 2011 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2011/06/04/june-open-meeting-summary.html
post_id: 5649648
custom_summary: false
summary: ""
date: 2011-06-03T19:00:00-0500
lastmod: 2011-06-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2011/06/03/june-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 6/03/2011 held at the Tribal Office in Aynor

1. CoC Scott, and CM's Homer, Richia, Neal, and Dalton present. CM Jeanie arrived at 8:15pm during Chief Hatcher's presentation.

2. CoC Scott expressed appreciation for calls and prayers received after his father passed.

3. May minutes read

            a. Homer motioned to accept; Dalton seconded

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

4. Financial Report: Michelle

            a. $3287.64 online balance

5. Online Votes

            a. Chief: Sat Council meeting 6/4

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

            b. Allow Longest Walk participants to camp on grounds 6/23-6/24

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Robert-yes, Jeanie-yes                                  Scott-yes (7yes, 0no, 0abstain, 0absent: passed unanimously)

6. Committee Reports

            a. Building & Grounds: Neal

                        1. Donnie- working to flatten dirt on grounds

                        2. Next Sun. hope - Sweat Lodge

                                    a. Elder Jerry: what is our liability?

                                    b. Craig: is there a disclaimer?

                                    c. Homer: Longest Walk weekend?

                                                1. on grounds 6/23-6/24

            b. Arts & Crafts: 2nd Chief Susan

                        1. had meeting on 20th

                        2. elected chairperson

                        3. sent letters to people who didn't have all paperwork in

                        4. classes here every quarter/ month for a fee to pay for electric

                        5. Dalton assured committee he doesn't get 2 votes (Committee &                                             Council)

                        6. Cha'kwaina wants Dalton to look at "certification" and streamline it

                        7. Elder Doug: would like to have an Arts & Crafts day during spring

                                    a. 2nd Chief Iris: is just for tribal artists, let the committee handle it

                                    b. Chief Hatcher: 1st Saturday of the month: yard sale, Arts &                                       Crafts, let everybody vend

                                                1. Homer: instead of 1st Sat, let's do Sat. after each meeting                                          (for those who travel)

                                    c. people to help Linda with yard sale: Scott, Neal, Dan, Homer                                                (day of meeting), Richia

                                    d. Chief Hatcher: need to advertise: papers, coffee news- Becky &                                           Elder Jerry to help

                                    e. Date for first yard sale: 7/9 @ 7:30 am

                                    f. bring own tables $15; we supply table $25- first come, first serve

                                    g. 2nd Chief Susan" hot dogs/ chips

                                                1. Chief Hatcher: let Donnie cook and keep money

                                                            a. 2nd Chief Iris: if he buys supplies

                                    h. 2nd Chief Hatcher: bring tent and umbrella

                                    i. 2nd Chief Hatcher: A&C- make a booth to sell items

                                    j. send an email for volunteers

                                    k. Point of contact: Becky's cell for ad

                        8. Dalton: volunteers needed; for conference calls, you need to contact                          Cha'kwaina for codes

            c. Pauwau: Linda

                        1. no drum yet

                                    a. Eastern Bull can't come School Day

                                    b. School Day and PW are separate, but we try to coordinate for                                              pricing

                                    c. Rick Bird wants $4k; Edisto still has to quote

                                                1. Craig has quotes from some (Rick- in training)

                                    d. Homer: what happened to Harland?

                                                1. he got another gig faster

                                    e. Elder Jerry: guy from Harborwalk

                                                1. Craig: same guy that I'm talking about

                                    f. Bernie: any up & coming drums we can get?

                                                1. Linda: Rodlyn will be looking on the internet

                        2. Committee concerned about vendors we have

                                    a. if you see something new & exciting, let us know

                        3. 4 food vendors

                        4. volunteers jump in to help

                        5. Bernie: saw a silversmith at Edisto that wants to come

                        6. 2nd Chief Susan: Eglin AF Base (Panama City)has PW same weekend                                  as ours

                        7. Next meeting: 6/8 @ 6:30pm - Shoney's

                        8. Homer: anyone heard from Reggie or Stephanie?

                                    a. Linda: no responses

                        9. Program Book: Brian's picture will be on front

10. Elder Hank: 2nd Chief Phil can drum; Linda to contact him

11. Can sell ads now and need everyone to do so

            d. Grants: Michelle

                        1. EITC Grant: 85% match though. still looking into details

                        2. Frontier: Richia

7. Donnie: gas $69.25 to Sunhouse 1

            a. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

                        1. Check 1326

                        2. 2nd Chief Iris recommends budget to avoid votes each month

8. Membership Files

            a. Beverly Jean Halsdorf Moore

                        1. Vote is contingent upon applicant providing a front-faced picture

                        2. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

            b. Victoria Ann Moore England

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

            c. Angel Yvonne Moore Kent

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

            d. William M. Moore III

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

            e. Charles Andrew Ammons

                        1. Homer-yes, Richia-yes, Neal-yes, Dalton-yes, Scott-yes (5yes, 0no,                                     0abstain, 2 absent: passed by majority)

9. 2nd Chief Susan: newsletter will be sent out soon

10. Chief Hatcher

            a. Brooke Richardson wrote DOI & provided them with Elder's Hearing and                 information

                        1. DOI responded & may request evidence dating back to 1992

                        2. Bernie: they have to go before me and tell me where the money went

                        3. concerned about "removal from office" & how arbiter did it

                        4. supplemental order still isn't signed

                        5. Bernie: there is someone to appeal to

                        6. older, proposed newsletter will be sent out

                        7. They may not like a cutoff date; arbiter may change it

                                    a. Council does elections and needs to stand firm

                        8. willing to take a stand

                                    a. Council to sign statements about whether they would step down                                             if not re-elected

                                    b. All people holding electable positions are re-appointed tonight

                                                1. A Chief can't run the tribe alone

                                                2. Attorney Snow thinks Buster is the only officer of the                                                             tribe because of the wording in the order

                        9. Elder Frank: think we are blowing smoke when we don't need to be

10. Chief Hatcher will run again

11. Chief Hatcher & 2nd Chief Iris preparing election rules

                                    a. 2nd Chief Iris: our decision; other side has to agree & arbiter                                                 works out the differences

12. Questions about filling in the pond; some said not to do it

13. Jeanie: question about accepting donation checks; Answer: yes

14. Dalton: please sign the sign-in sheet if you haven't done so

11. Craig

            a. Feb.- Present

                        1. Pee Dee PW

                        2. Edisto PW

                        3. Sparkleberry Festival

                        4. Beaver Creek

                        5. Harborwalk

                        6. Gullah Geechee (sp?) Festival

                        7. Magazine: Natural Awakenings

                        8. Sweat Lodge x4

                        9. Silver Heels Drum

10. Pipe Circle x3

11. Teach OSHA Native American Spirit Pip

12. Holy Man for Wolf Creek

            b. Homer: Lakota-Sioux PW in September (where Mr. Moore was from)

                        1. would like for some of us to go

                        2. it's for the kids (pw & funds)

Homer motioned to close the meeting; Richia seconded.

Meeting adjourned 8:55 pm.

Respectfully submitted by Michelle Hatcher on 6/30/11 at 5:14 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
