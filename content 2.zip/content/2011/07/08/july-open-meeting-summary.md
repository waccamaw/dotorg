---
layout: post
title: "July 2011 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2011/07/09/july-open-meeting-summary.html
post_id: 5649649
custom_summary: false
summary: ""
date: 2011-07-08T19:00:00-0500
lastmod: 2011-07-08T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2011/07/08/july-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 7/08/2011 held at the Aynor Senior Center in Aynor

1. CoC Scott, and CM's Homer, Neal, and Dalton present. 2nd Chief Iris was proxy for Jeanie; 2nd Chief Susan was proxy for Robert.

2. June minutes read

            a. Homer motioned to accept; Dalton seconded

            b. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief Susan        (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

3. Financial Report: 2nd Chief Iris

            a. $13,903.40

            b. Discussed budget; need to prorate items & deduct priorities (deck, floor,       Donnie's trailer, bathroom, attorney)

                        1. Chief Hatcher: priorities: Donnie's trailer, showers & bathrooms (have                                   blocks), develop more RV spots & upgrade their electricity (to rent out)

                                    a. Office & Donnie's trailer are not sufficient

                        2. Get in touch with people moving houses on road here

            c. 2nd Chief Iris to crunch budget & redistribute

4. Online Votes

            a. Attorney & Arbitrator: Dalton-yes, [Richia-yes], Neal-yes, Homer-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief Susan (Robert)-yes, Scott-yes

            b. Floor & wood: Dalton-yes, Neal-yes, Homer-yes, 2nd Chief Iris (Jeanie)-yes,          2nd Chief Susan (Robert)-yes, Scott-yes

            c. End Date to announce candidacy 8/31: Dalton-yes, Neal-yes, Homer-yes, 2nd          Chief Iris (Jeanie)-yes, Scott-yes

5. Committee Reports

            a. Grants: Michelle

                        1. SCAC- veto overridden; may apply for funds again in March

                        2. Chief Davidson mentioned two things to look into

                                    a. USDA to help with buildings

                                    b. NFL sponsorships

            b. Pauwau: 2nd Chief Susan

                        1. all contracts sent, hotel letter sent, program book being worked on

                        2. 3 ads * 20people= $6000

                        3. Meal tickets, tri-fold flyer, Roy Glass (flutist)

                        4. Next meeting 7/13 @ 6:30pm

            c. Arts & Crafts: 2nd Chief Susan

                        1. Donnie has friend with 2 kilns & wanted to know if anyone was                                             interested in using them

                        2. Next meeting 7/15

                        3. Arts & Crafts to showcase separate from yard sale

            d. Building & Grounds: Neal

                        1. new floor in tribal office

                        2. sweat lodge went ok during Longest Walk

                        3. 14 projects at the moment

6. Resolutions

            a. DH-07-08-2011-001: Tribal Newsletter Costs & Delivery Methods received its       1st reading

                        1. 2nd Chief Iris: add number of newsletter per year; quarterly

                        2. 2nd Chief Susan: realize this is for 2 sheets of 11x17

                        3. Chief Hatcher: could put that $10 option on application & make it $17

                                    a. 2nd Chief Iris: don't think it should be part of application

                                                1. 2nd Chief Susan: put insert with ID card

                                                2. Dalton: set up communication for non-member                                                                      distribution

                        4. 2nd Chief Susan: 1 newsletter per household address

                        5. Chief Hatcher: probably ok to increase application fee after 20 years

                                    a. make things simple to them manageable

                        6. Cheryl: Don't we have birthdates for kids?

                        7. 2nd Chief Susan thanked Dalton, Michelle, 2nd Chief Iris

            b. SB-07-08-2011-001: Tribal Secretary 2011 Budget Proposal received its 1st           reading

            c. DH-07-08-2011-002: Election of a Sergeant at Arms received its 1st reading

                        1. changes will have to be made

7. Membership Files

            a. Elaine Choo

                        1. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief                  Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

            b. Brianna Riha

                        1. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief                  Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

            c. Kaitlyn Riha

                        1. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief                  Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

            d. Portia Riha

                        1. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief                  Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

            e. Troy Riha

                        1. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief                  Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

8. 2nd Chief Susan

            a. Freecycle- used medical equipment 843-249-6643- American Legion

            b. Policy Letter on Camping

                        1. Neal motioned to accept; Homer seconded

                                    a. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes,                                              2nd Chief Susan (Robert)-yes, Scott-yes (6yes, 1absent, passed by                                          majority)

9. Donnie: gas $75.10 check 1331 to Sunhouse 1

            a. Homer-yes, Neal-yes, Dalton-yes, 2nd Chief Iris (Jeanie)-yes, 2nd Chief Susan         (Robert)-yes, Scott-yes (6yes, 1absent, passed by majority)

10. Craig

            a. Natural Awakenings Magazine

                        1. Craig's piece on Red Road

                        2. will advertise for our pauwau

                        3. will do a pauwau edition

            b. Wellness Council- possible source of funding

            c. excellent sweat lodge

11. CoC thanked Chief Hatcher for his help on tree ceremony

12. Chief Hatcher

            a. Certificates for family of members being honored

            b. Why not list kids & spouse on applications? Why do people have to apply at a          young age if automatically a member?

            c. Homer: frame certificates if only $1-2; Scott/ Buster: yes

            d. Tim Creel wants to have gathering on grounds in Sept.

                        1. 2nd Chief Iris: leave it way they found it

                        2. Homer: people in that group that don't like us & would like to hurt us

                        3. Cheryl: liabilities involved; get a disclaimer

                        4. Dan: think Sandy may join them

                        5. 2nd Chief Iris: would like to know who their members are first

                        6. Homer, Dalton, 2nd Chief Iris vote no with apologies

            e. Ms. Hayden @ CMA on 6/24- alleged our order had been appealed (Mr. Snow       said it hadn't been)

                        1. appeal process open till next Friday

                        2. Sumter Band of Cheraw Indians: Ms. Hayden mentioned another                              injunction

                        3. several people complained& now there will be a hearing on her

                        4. only 10-11 people at that in meeting in Nov. last year at CMA

                                    a. We got a letter to vend 10/19; cutoff date was 10/16

                        5. CMA website still not updated

                        6. On CMA, recognized tribes & groups get to vote- there are 7 tribes & 5                               groups

                                    a. Past- proposal to stop recognizing groups- if not done, could                                                 lead to non-natives deciding Native issues

                        7. Game animal parts

                        8. Flyer in welcome centers with Chief Gene Norris

                        9. Tribal Issues

                                    a. oath of Office: people need to show up

                                                1. don't believe if you're a spiritual leader, you can be in                                                             politics

                                                            a. 2nd Chief Iris: and being a spiritual leader isn't at                                                                    your convenience

                                    b. 2nd Chief Susan: no proxy

                                    c. Homer: concerns all offices

                                                1. Dalton: except judges

                                    d. Smudging isn't done anymore

                                    e. Scott to email Council

13. Becky: 7/28 Food Giveaway @ Oakdale Baptist Church in Loris- 4th Thursday of every month

Neal motioned to close the meeting; Homer seconded.

Meeting adjourned 9:00 pm.

Respectfully submitted by Michelle Hatcher on 7/31/11 at 3:04 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
