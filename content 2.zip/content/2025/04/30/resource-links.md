---
layout: post
title: "Resource Links"
microblog: false
guid: http://waccamaw.micro.blog/2025/05/01/resource-links.html
post_id: 5650012
custom_summary: false
summary: ""
date: 2025-04-30T19:00:00-0500
lastmod: 2025-04-30T19:00:00-0500
type: post
url: /2025/04/30/resource-links.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jan 14, 2010
- 1 min read

Updated: May 1

1.

American Indian Chamber of Commerce

[http://www.aiccsc.org/](http://www.aiccsc.org/)

2. SC Department of Archives & History

 [https://scdah.sc.gov/](https://scdah.sc.gov/)

3. SC Native American Indian Business Directory & Resource Guide

[cma.sc.gov/sites/def...](https://cma.sc.gov/sites/default/files/Documents/SC-Native-American-Buisness-Directory-final.pdf)

4. SC Native American Educational Resource Guide

[cma.sc.gov/sites/def...](https://cma.sc.gov/sites/default/files/Documents/NAI_EducationResourceGuide_2017_final.pdf)

5. Native American Advisory Committee

[cma.sc.gov/minority-...](https://cma.sc.gov/minority-population-initiatives/native-american-affairs)

6. Native American Legislation

[cma.sc.gov/minority-...](https://cma.sc.gov/minority-population-initiatives/native-american-affairs)

7. Grants for State Tribes

[cma.sc.gov/minority-...](https://cma.sc.gov/minority-population-initiatives/native-american-affairs)/grants-state-tribes

8. Native American Resources

[cma.sc.gov/minority-...](https://cma.sc.gov/minority-population-initiatives/native-american-affairs)/state-and-local-resource-links

9. Statistical Profiles By County

[cma.sc.gov/sites/def...](https://cma.sc.gov/sites/default/files/Documents/Statistical-Profile-By-Counties-February-2016.pdf)

10. Genealogy Research

[cma.sc.gov/minority-...](https://cma.sc.gov/minority-population-initiatives/native-american-affairs)/genealogy-research

11. Internships

[cma.sc.gov/sites/def...](https://cma.sc.gov/sites/default/files/Documents/Advisory-Committee-model-updated-17Nov17.pdf)

12. Other States' Indian Affairs Offices

[http://www.ncsl.org/research/state-tribal-institute/state-tribal-relations-committees-and-commissions.aspx](http://www.ncsl.org/research/state-tribal-institute/state-tribal-relations-committees-and-commissions.aspx)

13. SC Indigenous Women's Alliance

[https://www.coladaily.com/event/indigenous-womens-alliance-south-carolina-conference-2018/](https://www.coladaily.com/event/indigenous-womens-alliance-south-carolina-conference-2018/)

1.

The Ultimate Guide to Free and Low-Cost Healthcare Resources for Minority Communities

[https://onlinemhaprograms.org/free-low-cost-healthcare-resources-minority-communities/](https://onlinemhaprograms.org/free-low-cost-healthcare-resources-minority-communities/)

Tags:

- [education](https://www.waccamaw.org/updates/tags/education)
- [business](https://www.waccamaw.org/updates/tags/business)
- [chamber of commerce](https://www.waccamaw.org/updates/tags/chamber-of-commerce)
- [grants](https://www.waccamaw.org/updates/tags/grants)
- [genealogy](https://www.waccamaw.org/updates/tags/genealogy)
- [statistics](https://www.waccamaw.org/updates/tags/statistics)
- [Women](https://www.waccamaw.org/updates/tags/women)
- [legislation](https://www.waccamaw.org/updates/tags/legislation)
