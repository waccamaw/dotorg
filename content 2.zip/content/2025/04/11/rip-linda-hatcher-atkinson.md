---
layout: post
title: "RIP Linda Hatcher Atkinson"
microblog: false
guid: http://waccamaw.micro.blog/2025/04/12/rip-linda-hatcher-atkinson.html
post_id: 5650021
custom_summary: false
summary: ""
date: 2025-04-11T19:00:00-0500
lastmod: 2025-11-22T19:49:30-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
- https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
- https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/355dfbdbd6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/195ff4c9ca.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/8b88c510d6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/40ed60c9a4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6f5cc281ed.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/0597c5f5c5.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d81eb709fb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b64400682c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/178108bf4d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f4b54abda1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/46fe91067d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fd9abf230f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2fc4934887.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/36054d63b4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/473ef2e22b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9eda22c3bb.jpg
url: /2025/04/11/rip-linda-hatcher-atkinson.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 12
- 2 min read

![ree](https://waccamaw.micro.blog/uploads/2025/195ff4c9ca.jpg)

It is with a heavy heart that we bid farewell to Elder Linda Hatcher Atkinson, a woman whose spirit was as strong and enduring as the land of her Waccamaw Indian ancestors. Linda was a loving mother, grandmother, sister, and cousin, her heart overflowing with warmth and devotion for her family. They were her constant joy, and her love will undoubtedly live on through them.

Beyond her family, Linda was a fierce advocate, a warrior in her own right. She understood the fundamental importance of the right to vote and stood tall in the fight to ensure that Native Americans were recognized and empowered at the ballot box. Her determination and unwavering belief in justice leave a lasting legacy for her children, community, and all who share her commitment to equality. This passion for her heritage also shone brightly through her work as a dedicated genealogist, meticulously tracing the threads of her ancestry, connecting generations, and keeping the stories of her people alive.

Linda's connection to her heritage extended beyond historical records. She was a gifted storyteller, weaving narratives that captivated audiences and brought the rich history and traditions of the Waccamaw people to life. Her voice, whether spoken or expressed through the strokes of a brush as a talented painter, held the wisdom of generations. Her artwork often reflected the beauty of her culture and the deep connection to the land she cherished.

Linda also possessed a remarkable ability to bring people together. As a skilled event coordinator, she orchestrated gatherings that fostered community, celebrated culture, and strengthened bonds. Her meticulous planning and warm spirit made every occasion memorable. This talent for connection was also invaluable in her dedicated service on the federal recognition committee. She poured her energy and knowledge into this vital work, tirelessly advocating for the formal acknowledgement and rights of the Waccamaw Indian people. Her contributions to this effort were a testament to her unwavering commitment and deep love for her community.

Though we mourn her passing, let us also celebrate the life of a woman who loved deeply, fought bravely, and shared her many gifts so generously. May her memory be a source of comfort and inspiration, give strength to those closest to her, and may she rest in peace, her stories and her spirit continuing to resonate within us all.

[https://www.goldfinchfuneralhome.com/obituaries/linda-atkinson-5/?fbclid=IwY2xjawJnXVFleHRuA2FlbQIxMQABHppdPkfYij5BjcH1znCIL3XSIVOsGF4jigTp6TphrcmBxk_0XhX-C-3eVWaH_aem_qMWEC4ZwPp8nL5a5S0miig#!/TributeWall](https://www.goldfinchfuneralhome.com/obituaries/linda-atkinson-5/?fbclid=IwY2xjawJnXVFleHRuA2FlbQIxMQABHppdPkfYij5BjcH1znCIL3XSIVOsGF4jigTp6TphrcmBxk_0XhX-C-3eVWaH_aem_qMWEC4ZwPp8nL5a5S0miig#!/TributeWall)

![image](https://waccamaw.micro.blog/uploads/2025/355dfbdbd6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/355dfbdbd6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/195ff4c9ca.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/195ff4c9ca.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/8b88c510d6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/8b88c510d6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/40ed60c9a4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/40ed60c9a4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/6f5cc281ed.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/6f5cc281ed.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/0597c5f5c5.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/0597c5f5c5.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d81eb709fb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d81eb709fb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b64400682c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b64400682c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/178108bf4d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/178108bf4d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f4b54abda1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f4b54abda1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/46fe91067d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/46fe91067d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fd9abf230f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fd9abf230f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2fc4934887.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2fc4934887.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/36054d63b4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/36054d63b4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/473ef2e22b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/473ef2e22b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9eda22c3bb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9eda22c3bb.jpg)
