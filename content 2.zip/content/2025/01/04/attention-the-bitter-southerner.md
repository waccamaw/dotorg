---
layout: post
title: "Attention: The Bitter Southerner"
microblog: false
guid: http://waccamaw.micro.blog/2025/01/05/attention-the-bitter-southerner.html
post_id: 5649933
custom_summary: false
summary: ""
date: 2025-01-04T19:00:00-0500
lastmod: 2025-11-22T19:06:38-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/a9bc53dd8b.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/a9bc53dd8b.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/a9bc53dd8b.jpg
url: /2025/01/04/attention-the-bitter-southerner.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 9, 2024
- 1 min read

![ree](https://waccamaw.micro.blog/uploads/2025/a9bc53dd8b.jpg)

I'm a journalist writing a story about the South's clam culture for the [Bitter Southerner](https://bittersoutherner.com/). I'm road tripping from the Chesapeake down the east coast and stopping in communities along the way. I would love to include perspectives from the Waccamaw people and meet someone from your tribe, if possible, on April 19 (as I drive between Wilmington and Charleston). In particular, I'd like to understand how your ancestors interacted with clams, if and where folks are still harvesting wild clams, and if there are any traditional clam dishes from your community.

Caroline Hatchett

writer and editor

[[email protected]](/cdn-cgi/l/email-protection#bbd8dac9d4d7d2d5de95d3dacfd8d3decfcffbdcd6dad2d795d8d4d6) | 706.296.6291 | [@hatchetteats](https://www.instagram.com/hatchetteats/) | [carolinehatchett.com](http://carolinehatchett.com)

Facebook: [https://www.facebook.com/bittersoutherner](https://www.facebook.com/bittersoutherner)

Youtube: [https://www.youtube.com/channel/UCUs1a9xrGBBtMgkicW_0qXA](https://www.youtube.com/channel/UCUs1a9xrGBBtMgkicW_0qXA)

X: [https://twitter.com/BitterSouth](https://twitter.com/BitterSouth)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [Native](https://www.waccamaw.org/updates/tags/native)
- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
