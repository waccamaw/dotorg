---
layout: post
title: "Educational Opportunities"
microblog: false
guid: http://waccamaw.micro.blog/2025/01/05/educational-opportunities.html
post_id: 5649966
custom_summary: false
summary: ""
date: 2025-01-04T19:00:00-0500
lastmod: 2025-01-04T19:00:00-0500
type: post
url: /2025/01/04/educational-opportunities.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 4, 2021
- 1 min read

**WACCAMAW INDIAN PEOPLE EDUCATIONAL OPPORTUNITIES**

We have been working with several organizations, Truman Parmele/Military Officers association and Marsha Griffin/Consultant HGTC, to provide educational opportunities for the Waccamaw Indian People and/or veterans.

These services could be of value to members, family or veterans wishing to complete high school, obtain a GED,  or pursue a career through a Technical or Community college degree programs.

If currently applying for jobs, there is assistance with resume writing and interview preparation.

There would be financial assistance to cover the costs in the form of scholarships and grants, plus rides to the education center, and other benefits.

If you or your family would like to discuss or pursue any of these opportunities please contact me

Contact     John D. Turner
                  2nd Chief Internal
                  Waccamaw Indian People
                  843-655-5774
 [[email protected]](/cdn-cgi/l/email-protection#f79d838285999285c1c1b796839a94d9999283)

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [education](https://www.waccamaw.org/updates/tags/education)
