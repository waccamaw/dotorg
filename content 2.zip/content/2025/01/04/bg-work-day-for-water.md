---
layout: post
title: "B&G Work Day for Water Leak"
microblog: false
guid: http://waccamaw.micro.blog/2025/01/05/bg-work-day-for-water.html
post_id: 5649944
custom_summary: false
summary: ""
date: 2025-01-04T19:00:00-0500
lastmod: 2025-01-04T19:00:00-0500
type: post
url: /2025/01/04/bg-work-day-for-water.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Oct 9, 2023
- 1 min read

We have a water leak feeding the dance circle and campsites.

Chris said he try sometime this week to go out and dig up at the valve connections, so we will know what fittings we may need.

I'm calling for utility locations and line-up rental on a trencher.

The plan is to work sat and or sun to get the pipe in. If we get enough help maybe the gate too.

Tools that you may need are a shovel, hard toothrake, and post-hole diggers.

All help is appreciated.

Thanks in advance for your help.

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [event](https://www.waccamaw.org/updates/tags/event)
- [community](https://www.waccamaw.org/updates/tags/community)
- [waccamaw](https://www.waccamaw.org/updates/tags/waccamaw)
- [B&G](https://www.waccamaw.org/updates/tags/b-g)
