---
layout: post
title: "Autumn Equinox"
microblog: false
guid: http://waccamaw.micro.blog/2025/01/05/autumn-equinox.html
post_id: 5649934
custom_summary: false
summary: ""
date: 2025-01-04T19:00:00-0500
lastmod: 2025-01-04T19:00:00-0500
type: post
url: /2025/01/04/autumn-equinox.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 18, 2020
- 1 min read

The fire ceremony scheduled for this weekend has been postponed until Sunday, the 27th beginning at 7:09am.

The storm plus other issues is causing the postponement.

Walk easy

Tags:

- [event](https://www.waccamaw.org/updates/tags/event)
- [equinox](https://www.waccamaw.org/updates/tags/equinox)
