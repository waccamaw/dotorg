---
layout: post
title: "SC Center of Excellence in Addiction: Narcan Training"
microblog: false
guid: http://waccamaw.micro.blog/2025/06/24/sc-center-of-excellence-in.html
post_id: 5650026
custom_summary: false
summary: ""
date: 2025-06-23T22:43:46-0500
lastmod: 2025-11-22T19:53:02-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
- https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
- https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b939b9729c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b5fb03ae39.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a3af019b6f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/9092d2f446.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/96cf322739.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb4e985f1e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/96fc9ff0e2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d11c30d269.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4909a7905a.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be18665bc2.jpg
url: /2025/06/23/sc-center-of-excellence-in.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# SC Center of Excellence in Addiction: Narcan Training

-

Michelle Hatcher
- Jun 23
- 1 min read

Updated: Jul 10

We extend our heartfelt thanks to Amber Frazier of the Indigenous Women's Alliance of South Carolina, in collaboration with the SC Indian Affairs Commission and the SC Center of Excellence in Addiction. The Center provides expert consultation and technical assistance to help communities implement effective, evidence-based strategies for addiction treatment and prevention.

Amber also introduced us to her impactful work with The Courage Center, a Recovery Community Organization providing essential peer support and a safe, recovery-focused space for individuals and families affected by substance use.

She enlightened us about the journey of recovery, reminding us it’s non-linear and unique to each person. Amber educated us on the life-saving use of Narcan, the importance of respectful, person-first language (like “Substance Use Disorder” instead of “Substance Abuse”), and the life-saving impact of harm reduction.

In addition, she generously provided a wealth of resources related to behavioral health, housing, employment, and clothing, further supporting our communities on the path to healing and recovery.

Special thanks to the SC Indian Affairs Commission, now serving as Community Naloxone Distributors, for equipping each of the state’s tribes with Naloxone to help prevent overdoses and save lives. Community members can pick up Narcan at the Waccamaw Indian People tribal office located at 591 Bluewater Rd, Aynor, SC 29511. Please call ahead at  843-358-6877 to arrange for pickup.

**If you or someone you know needs Naloxone, please contact us—we’ll be glad to provide it.**

![image](https://waccamaw.micro.blog/uploads/2025/b939b9729c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b939b9729c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b5fb03ae39.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b5fb03ae39.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a3af019b6f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a3af019b6f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9092d2f446.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/9092d2f446.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/96cf322739.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/96cf322739.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb4e985f1e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb4e985f1e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/96fc9ff0e2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/96fc9ff0e2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d11c30d269.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d11c30d269.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4909a7905a.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4909a7905a.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/be18665bc2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/be18665bc2.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#CommunityOutreach](https://www.waccamaw.org/updates/tags/communityoutreach)
- [#SCCEA](https://www.waccamaw.org/updates/tags/sccea)
