---
layout: post
title: "RIP: Carson Hatcher"
microblog: false
guid: http://waccamaw.micro.blog/2025/07/14/rip-carson-hatcher.html
post_id: 5650014
custom_summary: false
summary: ""
date: 2025-07-13T22:07:29-0500
lastmod: 2025-11-22T19:35:26-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
- https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
- https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/014d9598c4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/58b3e21452.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/34871cfbca.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb99406eaa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fc0a8aa4cc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ad7920f8a2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7c85080b02.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fd67d232d4.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2c855aa261.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6e8a6c41c9.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5beb201180.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c045a51c68.jpg
url: /2025/07/13/rip-carson-hatcher.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# RIP: Carson Hatcher

-

Michelle Hatcher
- Jul 13
- 2 min read

He was a true warrior, not just in spirit, but in the way he navigated his life. We watched him grow and face every challenge with quiet courage and an unwavering resilience. He was always learning, always striving, and his journey was a testament to the power of a strong heart.

That same strength and spirit flowed into his art. He was a gifted grass dancer whose every movement told a story. When the bells on his regalia moved, it was more than just a dance; it was a living prayer, a song of the earth and his people. He was also a talented musician, and through his music, he shared his soul. His melodies spoke to us all, carrying both the weight of history and the hope of the future.

This was all rooted in a deep and abiding love for his culture. He didn't just appreciate his heritage; he lived it and embodied it. He was a keeper of traditions and a teacher for a new generation. Through his performances, he not only entertained but also connected us all to something bigger than ourselves.

Many of us were lucky enough to witness his gifts at school events and tribal gatherings. He brought a sense of immense pride and joy to every performance. We will forever remember the sight of him dancing, the sound of his music, and the beautiful spirit he shared with the world.

While we mourn his loss, let us also celebrate the powerful life he led and the beautiful legacy he leaves behind. The rhythm of his dance will forever echo in our hearts, and he will be missed by everyone who had the honor of watching him perform.

![image](https://waccamaw.micro.blog/uploads/2025/014d9598c4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/014d9598c4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/58b3e21452.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/58b3e21452.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/34871cfbca.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/34871cfbca.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb99406eaa.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb99406eaa.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fc0a8aa4cc.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fc0a8aa4cc.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ad7920f8a2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ad7920f8a2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7c85080b02.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7c85080b02.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fd67d232d4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fd67d232d4.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2c855aa261.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2c855aa261.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/6e8a6c41c9.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/6e8a6c41c9.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5beb201180.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5beb201180.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/c045a51c68.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/c045a51c68.jpg)

Attendees of the visitation and funeral are invited to wear regalia if they wish.

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [RIP](https://www.waccamaw.org/updates/tags/rip)
