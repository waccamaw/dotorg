---
layout: post
title: "Native Heritage Interpretive Trail Grand Opening: 4/16/2024"
microblog: false
guid: http://waccamaw.micro.blog/2025/07/22/native-heritage-interpretive-trail-grand.html
post_id: 5650000
custom_summary: false
summary: ""
date: 2025-07-21T19:00:00-0500
lastmod: 2025-11-22T19:26:03-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/cc114675c2.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/cc114675c2.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/cc114675c2.jpg
url: /2025/07/21/native-heritage-interpretive-trail-grand.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Feb 20, 2024
- 0 min read

![ree](https://waccamaw.micro.blog/uploads/2025/cc114675c2.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [event](https://www.waccamaw.org/updates/tags/event)
