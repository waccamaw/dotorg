---
layout: post
title: "July 2025 Open Meeting"
microblog: false
guid: http://waccamaw.micro.blog/2025/07/12/july-open-meeting.html
post_id: 5649728
custom_summary: false
summary: ""
date: 2025-07-11T19:00:00-0500
lastmod: 2025-07-11T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2025/07/11/july-open-meeting.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 7/11/2025  held at the tribal office and via Zoom

1. CM’s Rebecca, Robert, Glenn, Emily, and CoC Susan were present. 2C Alan served as a proxy for Marion. Elders Glenn T, Larry J, and Scott B were present. Acting Chief Cail and Chief Hatcher were present.

2. Members Randi C, Randy W, Sara M, John T, Aaron F, Dr. Dillian, Christine W, Clayton G, Dr. Tracey, Lindsey S, Constance L, Lisa L, Dr. Sara, Kevin D, and Austin S were present. Guests Isabella D, Jamie G, and Alex B were present.

3. CoC Susan suggested limiting everyone to 5 minutes per topic

4. Financial Report (as of 7/10/2025 at 1:55 pm)

   1. General Fund: $42,478.10

      1. Purchases for B&G from Amazon need to be transferred back here: $591.09 as of 6/6/2025

         1. Michelle & Randi need receipts for purchases

   2. Building Fund: $51,104.85

   3. Cemetery Fund: $447.00

   4. Grant Fund: $34,787.43

5. Old Business

   1. Online Votes

      1. 6/16 Authorize Chief Hatcher at least $1200 to have a Thank You Dinner at Golden Corral

         1. Rebecca-yes, Robert-yes, Glenn-yes, Emily-yes, 2C Alan (Marion)-yes, CoC Susan-yes

      2. 7/7 Storage for the WIP tribal Google account

         1. Rebecca-yes, Robert-yes, Glenn-yes Emily-yes, 2C Alan (Marion)-yes, CoC Susan-yes

   2. Bathhouse Project

      1. Chief Hatcher: I got 1 bid for a 10x20 & 10x24 for $84k

         1. That includes labor, materials, permitting

         2. No water meter or pump, but it gives 100 ft of pipe

      2. Meeting dates: Acting Chief Cheryl: tentatively set for next week, then monthly

         1. At 6pm?

         2. On the Wednesday following the PW Committee meeting?

         3. CoC Susan: do it in person for those in town to be able to look at the space

         1. Acting Chief Cheryl: there will be some on-site visits

   3. Talking Circle on 6/21 with 8 people

      1. CoC Susan: it was a great experience

      2. Acting Chief Cheryl: I spoke wit hKaya and he wants to build on our relationship

         1. He wants to do this once per month; it’s currently done during our events

   4. Cemetery

      1. Chief Hatcher” I talked to Patricia Sellers about transferring the cemetery to them

         1. She wants to hold a meeting with the trustees

         2. We have the option to hearing them before a decision is made

         1. We maintain the cemetery

         2. CM Rebecca: can I get a copy of the bylaws?

         3. Michelle: I’ve asked for years, but I’ve never seen them

         4. Sara M: Patricia said she could get the bylaws and meeting with the trustees

         5. To read the bylaws

         6. She wanted me to be a board member

         7. She doesn’t understand where the concerns are

         8. She has been working on it

         9. She wants to get a meeting link

10. Michelle: send me or have her send me her information

11. Chief Hatcher: they can

12. It’s a significant property and we need to work through this

13. We could invite them into a talking circle

14. Trustees want to maintain their positions, but Hilda is the lynchpin

15. Acting Chief Cheryl: that may not change; she gets 1 vote as a trustee

16. It was 2 acres from Mary Dimery to build that

17. It’s worth holding on to

18. Elwood A said many preached there

19. Chief Hatcher: and if they don’t show?

20. Sara M: Patricia is paying for landscaping

21. I don’t understand their attitude

22. This meeting should be mandatory

23. CoC Susan: they never give a report each month

24. Elder Larry: yes

25. CM Rebecca: why couldn’t the Elders and board talk?

26. Chief Hatcher: they can

27. It’s a significant property and we need to work through this

28. We could invite them into a talking circle

29. Trustees want to maintain their positions, but Hilda is the lynchpin

30. Acting Chief Cheryl: that may not change; she gets 1 vote as a trustee

31. It was 2 acres from Mary Dimery to build that

32. It’s worth holding on to

33. Elwood A said many preached there

34. Chief Hatcher: and if they don’t show?

35. Sara M: Patricia is paying for landscaping

36. I don’t understand their attitude

37. This meeting should be mandatory

38. CoC Susan: they never give a report each month

39. Elder Larry: yes

40. Acting Chief Cheryl: Quit Claim: it would be left in despair

41. It’s a significant property and we need to work through this

42. We could invite them into a talking circle

43. Trustees want to maintain their positions, but Hilda is the lynchpin

44. Acting Chief Cheryl: that may not change; she gets 1 vote as a trustee

45. It was 2 acres from Mary Dimery to build that

46. It’s worth holding on to

47. Elwood A said many preached there

48. Chief Hatcher: and if they don’t show?

49. Sara M: Patricia is paying for landscaping

50. I don’t understand their attitude

51. This meeting should be mandatory

52. CoC Susan: they never give a report each month

53. Elder Larry: yes

54. Chief Hatcher: a lot of people were promised spots and no one knows who goes where

55. John T: it would benefit the tribe for recognition

56. Trustees want to maintain their positions, but Hilda is the lynchpin

57. Acting Chief Cheryl: that may not change; she gets 1 vote as a trustee

58. It was 2 acres from Mary Dimery to build that

59. It’s worth holding on to

60. Elwood A said many preached there

61. Chief Hatcher: and if they don’t show?

62. Sara M: Patricia is paying for landscaping

63. I don’t understand their attitude

64. This meeting should be mandatory

65. CoC Susan: they never give a report each month

66. Elder Larry: yes

67. CoC Susan/ Acting Chief Cail: call for a meeting for the trustees with Tribal Council

68. Chief Hatcher: and if they don’t show?

69. Sara M: Patricia is paying for landscaping

70. I don’t understand their attitude

71. This meeting should be mandatory

72. CoC Susan: they never give a report each month

73. Elder Larry: yes

   5. TN Land Insurance

      1. CoC Susan: dropping the subject from the agenda

      2. No insurance company will insure it because of the life estate

      3. There are “No Trespassing” signs out there

6. New Business

   1. Receipts

      1. Reimburse Michelle for SCIAC trip: $14.08

         1. Rebecca-yes, Glenn-yes, Emily-yes, 2C Alan (Marion)-yes, Robert-abstain, CoC Susan-yes

         2. Check 892 General Fund

   2. Committee Reports

      1. Buildings & Grounds

         1. CM Glenn: nothing new

      2. Arts & Crafts

         1. 2C Alan: did Julie Watts get her arts certificate?

      3. Grants

         1. Applied for $50k; should hear something next week

         2. Justice Outside: $20k; paperwork submitted

      4. Newsletter

         1. Dr. Sara: Zoey hasn’t responded

      5. Pauwau

         1. Elders: are you going to do the gate this year?

         1. Michelle: that includes counting the money and wristbands each morning and evening

         2. Elder Larry: yes

         2. Tony said 2 hot dogs for volunteer/ dancer meals

         3. T-shirts were ordered today

         4. Lindsey: Ads, pictures, and stories are due by 8/1

         1. Acting Chief Cheryl: acknowledge the Knight Foundation, Justice Outside, etc…

      6. Drum

         1. CM Glenn: nothing new

         2. Chief Hatcher: Mr. Locklear said he’d come and teach at no cost

         3. 2C Alan: we need a younger group of guys

      7. Archiving Project

         1. CM Rebecca: We need digital copies, paper copies of everything to tell a full WIP story

      8. Files

         1. No meeting this month

      9. Longhouse

         1. Acting Chief Cheryl: David thinks we can begin in September

         2. CM Marion is locating ash trees and getting them brough here

         3. Second weekend of September to finish the roof

         4. Plans to engage with Dr. Dillian’s class for a few volunteers

         5. Then work on the interior

10. Woccon Language

         1. CM Rebecca: meeting is being scheduled; Dr. Roberts is traveling

         1. We could add a list of words to the program book

         2. Austin S: follow-up a few times and not heard back on my grant

         1. Asking Google and Microsoft for grants

   3. Reminder: Autumn Equinox is 9/20

      1. Santee PW: 9/20

      2. PAIA PW: 9/27

7. CoC Susan: recommend renewing membership wit hMB Area Chamber of Commerce

   1. We get a discounted cost for PW stuff, display at their office in November

   2. Motion to renew at $195/yr; 2C Alan (Marion)seconded

      1. Rebecca-yes, Robert-yes, Emily-yes, Glenn-yes, 2C Alan (Marion)-yes, CoC Susan-yes

      2. Check 891 for $195 from the General Fund

8. CoC Susan: one member didn’t get the opportunity for the Second Chance on membership fees

   1. I propose we give her full membership back with the Second Chance $200 fee; Rebecca seconded
      1. Rebecca-yes, Robert-yes, Emily-yes, Glenn-yes, 2C Alan (Marion)-yes, CoC Susan-yes

9. CoC Susan: there is a resolution of items that total’s $2k or more

   1. DH-04-06-2018-001 (if you need a copy, let Michelle know)

   2. 2C Alan: I thought it was just volunteer time

   3. John T: should you put a dollar amount on each item?

      1. Mcihelle: you would need to do at in-take

      2. Acting Chief Cheryl: its value at the time it was donated

   4. CoC Susan: based on current amounts she has donated, I feel good about it

      1. Lawn mowers, art supplies, hot dog machine, cotton candy machine

      2. 2C Alan: need it documented for next individuals

   5. CoC Susan: I motion we give her lifetime membership based on her donations; Rebecca seconded

      1. Rebecca-yes, Robert-yes, Emily-yes, Glenn-abstain, 2C Alan (Marion)-yes, CoC Susan-yes

         1. CM Glenn: I want the list

   6. CoC Susan shared Constance L’s photo

   7. CoC Susan: I’m going to check with the Chambe for auto-renewal

      1. 2C Alan: how hard is it to get out of it?

         1. CoC Susan: not hard

      2. 2C Alan: concern is that the rate goes up

10. Acting Chief Cheryl: Money market or interest-bearing accounts

   1. It would be good to have a sit-down meeting with a banker

   2. We can take grant funds and put them into a money markey account

   3. Randi is doing the 990

   4. We need the best place for our money

   5. John T: change banks; we have a responsibility to the tribe to do this

      1. Michelle: I wouldn’t do anything until the 990 is done

   6. Acting Chief Cheryl: Mike M said we could start seeing larger grants

      1. He would be glad to set up a financial portfolio

         1. CoC Susan: let’s do that in August

11. Acting Chief Cheryl: Attorney General meeting

   1. In February, the TASCN treaty was signed

      1. A nonprofit was set up: Indigenous Nations Development of South Carolina, Inc.

         1. It can get a large grant and subgrant to other tribes

   2. I talked to Harold Goodson the other day and they want us to make their land into campground/ partner with them

   3. I met a lady with IRC that coordinates with the Scouts

12. Chief Hatcher

   1. I remember paying for newsletters

   2. I’ve asked and applied for an appreciation meeting; a thank you after tourist season

   3. AG Wilson: I was impressed with him

      1. His office offers so much for victims: Tribal Council needs to know who to contact

         1. I will prepare a document and send it to Tribal Council

   4. I Have an issue with a letter that was sent to the CMA with our name on it though we hadn’t signed it

13. Acting Chief Cheryl: Business Cards

   1. Propose getting business cards for Council, all Governing Body, and administrators

      1. Motion that business cards be made for the Governing Body, Secretary, and Bookkeeper; CoC Susan seconded

         1. Rebecca-yes, Robert-yes, Emily-yes, Glenn-yes, 2C Alan (Marion)-yes, CoC Susan-yes

   2. Membership for grandchildren and minors

      1. They can’t apply until they’re 18

         1. Look at the structure of minor members with parent authorization who may nor be want to join a tribe (like divorced parents)

         1. Our young people would step in to be part of the community

   3. Technical Advisory Panel: letter of support to WRA: 2C Alan (Marion): yes

   4. Gaylord & Dorothy Donnelley Foundation: mapping project

   5. Lowcountry Land Trust: meeting on conservation and Land Back

   6. Conference: Spring 2026 for leaders and other tribal leaders

   7. Domestic violence and women: Indigenous Women’s Alliance has the ability to provide shelter for Indigenous women

14. Elder Larry: can Elders attend trustees and Council meeting?

   1. Acting Chief Cheryl, CoC Susan, CM Rebecca-yes

15. CM Rebecca: consider abuse and starting an emergency fund for medication and housing

   1. Chief Hatcher: write a proposal

      1. CM Rebecca: ok

         1. Michelle will help

   2. CoC Susan: also look to outside businesses for donations and support

16. Alex B: near Waccamaw High School they are changing the logos and PTO name

17. Austin S: need to connect someone to the Google grant

18. Acting Chief Cheryl: Donnie requests we do something about his unlivable trailer

19. Isabella: I need help with regalia making and be taught to dance and am using my babysitting funds to do it

20. Dr. Dillian: semester is starting up so we will have volunteers

2C Alan (Marion) motioned to close the meeting; Rebecca seconded.

Rebecca-yes, Robert-yes, Emily-yes, Glenn-yes, 2C Alan (Marion)-yes, CoC Susan-yes

The meeting adjourned at 8:50 pm.

Respectfully submitted by Michelle Hatcher on 7/14/2025 at 1:52 pm.
