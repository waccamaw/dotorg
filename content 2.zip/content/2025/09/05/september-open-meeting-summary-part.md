---
layout: post
title: "September 2025 Open Meeting Summary: Part 1"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/06/september-open-meeting-summary-part.html
post_id: 5649730
custom_summary: false
summary: ""
date: 2025-09-05T19:00:00-0500
lastmod: 2025-09-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2025/09/05/september-open-meeting-summary-part.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

September's meeting summary will be broken into different consecutive pages, This is a large file and the website cannot handle posting it as a single post, Below is pages 1- mostly 5.

Tribal Open Meeting Summary 9/5/2025  held at the tribal office and via Zoom

1. CM’s Rebecca, Glenn, Emily, and CoC Susan were present. CM Robert joined the meeting at 8:45 pm. 2C Alan served as a proxy for Marion. Elders Phil, Larry, Charles, and Scott were present. 2C Alan and Chief Hatcher were present.

2. Members Randy W, David B, Carolyn D, Jennifer R, Christine W, Andrew R, Josh W, Randi C, Tim H, Austin S, Kevin D, Seth W, Sara M, Clayton G, and Nancy J were present. Guests Alex B, Callie C, and Pretina D were present.

3. Approve June, July, August meeting minutes

   1. Need to figure out when there was a proxy and when Glenn was absent

   2. Tabled until October

      1. Secretary’s Note: 9/6: Attendance & Proxy voters was sent to TC

4. Financial Report (as of 9/2/2025 at 6:02 pm)

   1. General Fund: $40,066.59

      1. Purchases for B&G from Amazon need to be transferred back here: $3296.30 as of 9/8/2025

   2. Building Fund: $50,935.73

      1. $50,000 needs to be transferred to the grants account for the bathhouse project

   3. Cemetery Fund: $447.00

   4. Grant Fund: $101,504.58

      1. Purchase needs to be transferred back to the General Fund: $53.95

   5. Interest-bearing accounts

      1. Chief Hatcher: Council, have you thought any more on this? We’re going to have to have a team on this

      2. CM Glenn: I’m for

      3. CM Rebecca: I’m in favor; I thought we’d agreed to look into it

      4. Chief Hatcher: someone has to transfer the money from one account to another

         1. If we put the majority of our money into this, We'll make right about $4k- $6k a year.

         2. Operational account that we use at CNB will need to be paid

         3. We've got to be able to drag money out of that and put it in to pay the bills

         4. Maybe we’ll have someone dedicated to that

      5. 2C Alan: how many withdrawals can you make before you’re charged?

         1. Chief Hatcher: 10

         2. CM Glenn: 10 a month, but that's not stopping you how much you're drawing out

         3. Chief Hatcher: We can keep the minimum in the CNB accounts to keep them open

         4. CoC Susan: keep all of the other accounts open?

         1. Chief Hatcher: yes, but I want to get the interest

         2. To Randi C, are you willing to transfer the money when needed?

         3. Randi C: The only thing I would hazard, uh, or warn against is if the grant letter says the funds are completely restricted, I'd be very careful about swapping it between accounts.

         4. That could get us in trouble

         5. Michelle: on utilities, it’s around $6k

         6. Randi should be able to run a report or I can go through the file folder

         7. Need to keep a buffer in there

         8. They’re supposed to, but don’t seem to do it

         9. Who owns the land, who's been doing this, who's been checking in, and actually doing the work as the Board of Trustees, or what have you.

10. And just keeping regular monthly or bi-monthly track of everything

11. Mark in documents, maybe even notarize them, this person's going to be buried here, this person's going to be buried here, this person is already buried here.

12. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

13. I know it inside and out, but I think that with Hilda especially, she's sick again.

14. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

15. I can talk to some of them

16. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

17. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

18. People shouldn’t find out last minute that their loved one can’t be buried there

19. Jennifer R: I can get it for you and work with Rebecca

20. Larry J: what you do, get it written in stone

21. It falls in that archives and history committee, and we can at least get the ball rolling.

22. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

23. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

24. Chief Hatcher: should we see who is buried there now?

25. Chief Hatcher: people are balking because there is limited space

26. Dr. Dillian: GPR should tell you that

27. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

28. The other case was a man with a building on our land

29. Rebecca: it seems pointless; they’re burying people without telling us

30. Phil: Who's been buried there that we don’t know about?

31. Chief Hatcher: no one

32. The problem is they don’t do things the way we ask

33. There isn't really a display place here to put them out that would keep them secure

34. Callie is asking your permission to scan these belongings

35. There are no human remains, and I have never found human remains on this site; a shell midden site

36. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

37. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

38. Glenn: I love science. I've got some stuff I might need to be scanned.

39. Rebecca: I have a question about this because I write grants where I work

40. Chief Hatcher: what happens if the college approves the grant?

41. Rebecca: I don’t think we can vote on it yet and I have concerns

42. Callie: the grant is due in a month or two; I want to alleviate concerns first

43. My other question is, is this stuff being dated?

44. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

45. Callie: the goal is to fund someone who knows the materials too

46. Dr. Dillian: we could  create a digital exhibit

47. Anything I do through college and materials used become partially, if not wholly owned by the college

48. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

49. Dr. Dillian: there’s a strong argument for intellectual property

50. Callie: storage on Morphosource; other tribes are on there

51. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

52. Hard drive for WIP, hard drive for me to avoid losing data

53. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

54. Jennifer R is also concerned

55. Elder Phil: very seldom that someone comes to us beforehand

         5. 2C Alan: keep a minimum of $4k in the account

         1. Glenn: not sure which would know more, Michelle or Randi, about how much we spend each month

         2. Michelle: on utilities, it’s around $6k

         3. Randi should be able to run a report or I can go through the file folder

         4. Need to keep a buffer in there

         5. They’re supposed to, but don’t seem to do it

         6. Who owns the land, who's been doing this, who's been checking in, and actually doing the work as the Board of Trustees, or what have you.

         7. And just keeping regular monthly or bi-monthly track of everything

         8. Mark in documents, maybe even notarize them, this person's going to be buried here, this person's going to be buried here, this person is already buried here.

         9. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

10. I know it inside and out, but I think that with Hilda especially, she's sick again.

11. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

12. I can talk to some of them

13. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

14. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

15. People shouldn’t find out last minute that their loved one can’t be buried there

16. Jennifer R: I can get it for you and work with Rebecca

17. Larry J: what you do, get it written in stone

18. It falls in that archives and history committee, and we can at least get the ball rolling.

19. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

20. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

21. Chief Hatcher: should we see who is buried there now?

22. Chief Hatcher: people are balking because there is limited space

23. Dr. Dillian: GPR should tell you that

24. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

25. The other case was a man with a building on our land

26. Rebecca: it seems pointless; they’re burying people without telling us

27. Phil: Who's been buried there that we don’t know about?

28. Chief Hatcher: no one

29. The problem is they don’t do things the way we ask

30. There isn't really a display place here to put them out that would keep them secure

31. Callie is asking your permission to scan these belongings

32. There are no human remains, and I have never found human remains on this site; a shell midden site

33. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

34. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

35. Glenn: I love science. I've got some stuff I might need to be scanned.

36. Rebecca: I have a question about this because I write grants where I work

37. Chief Hatcher: what happens if the college approves the grant?

38. Rebecca: I don’t think we can vote on it yet and I have concerns

39. Callie: the grant is due in a month or two; I want to alleviate concerns first

40. My other question is, is this stuff being dated?

41. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

42. Callie: the goal is to fund someone who knows the materials too

43. Dr. Dillian: we could  create a digital exhibit

44. Anything I do through college and materials used become partially, if not wholly owned by the college

45. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

46. Dr. Dillian: there’s a strong argument for intellectual property

47. Callie: storage on Morphosource; other tribes are on there

48. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

49. Hard drive for WIP, hard drive for me to avoid losing data

50. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

51. Jennifer R is also concerned

52. Elder Phil: very seldom that someone comes to us beforehand

53. CoC Susan: you have to realize that when someone uses the credit card, that money won’t be there

54. Need to keep a buffer in there

55. They’re supposed to, but don’t seem to do it

56. Who owns the land, who's been doing this, who's been checking in, and actually doing the work as the Board of Trustees, or what have you.

57. And just keeping regular monthly or bi-monthly track of everything

58. Mark in documents, maybe even notarize them, this person's going to be buried here, this person's going to be buried here, this person is already buried here.

59. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

60. I know it inside and out, but I think that with Hilda especially, she's sick again.

61. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

62. I can talk to some of them

63. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

64. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

65. People shouldn’t find out last minute that their loved one can’t be buried there

66. Jennifer R: I can get it for you and work with Rebecca

67. Larry J: what you do, get it written in stone

68. It falls in that archives and history committee, and we can at least get the ball rolling.

69. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

70. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

71. Chief Hatcher: should we see who is buried there now?

72. Chief Hatcher: people are balking because there is limited space

73. Dr. Dillian: GPR should tell you that

74. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

75. The other case was a man with a building on our land

76. Rebecca: it seems pointless; they’re burying people without telling us

77. Phil: Who's been buried there that we don’t know about?

78. Chief Hatcher: no one

79. The problem is they don’t do things the way we ask

80. There isn't really a display place here to put them out that would keep them secure

81. Callie is asking your permission to scan these belongings

82. There are no human remains, and I have never found human remains on this site; a shell midden site

83. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

84. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

85. Glenn: I love science. I've got some stuff I might need to be scanned.

86. Rebecca: I have a question about this because I write grants where I work

87. Chief Hatcher: what happens if the college approves the grant?

88. Rebecca: I don’t think we can vote on it yet and I have concerns

89. Callie: the grant is due in a month or two; I want to alleviate concerns first

90. My other question is, is this stuff being dated?

91. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

92. Callie: the goal is to fund someone who knows the materials too

93. Dr. Dillian: we could  create a digital exhibit

94. Anything I do through college and materials used become partially, if not wholly owned by the college

95. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

96. Dr. Dillian: there’s a strong argument for intellectual property

97. Callie: storage on Morphosource; other tribes are on there

98. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

99. Hard drive for WIP, hard drive for me to avoid losing data

100. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

101. Jennifer R is also concerned

102. Elder Phil: very seldom that someone comes to us beforehand

      6. CoC Susan: I’d wait till the first of the year because we’re about to have pauwau expenses

      7. CM Rebecca: How about we authorize. Randy, if that's who we're gonna have due… the transferring, look into how much we should move, because I'm not familiar enough with the grants and different pots of money.

         1. Randi C: I’m ok with that

         1. CM Glenn: do the research

      8. Chief Hatcher: we need to sit down and go over operating expenses first

5. Old Business

   1. Online Votes

      1. 8/4: Allow Austin Serio to use the 501(c)(3) status to apply for server credits through Microsoft Azure

         1. Glenn-yes, Rebecca-yes, Emily-yes, 2C Alan (Marion)-yes, Susan-yes

   2. Bathhouse Project Updated

      1. Create an RFP

         1. Michelle: in contact with Romtec and Freddie Richardson

      2. Survey completed 9/3

         1. CoC Susan: he had to use several surveys because of the way the road changed the map over time

         1. Dr. Dillian saw the stakes out there

   3. Tribal Cemetery

      1. Chief Hatcher: you need to decide if you’re going to abide by these bylaws

         1. I haven’t heard anything from Colonel Sellers

      2. Rebecca: I’m opposed to letting them have it

         1. Chief Hatcher: it belongs to us, but there are a faction of locals that aren't a part of the tribe

         1. We maintain it; they’re supposed to

         2. We’ve got to set up a board of trustees

         3. They’re supposed to, but don’t seem to do it

         4. Who owns the land, who's been doing this, who's been checking in, and actually doing the work as the Board of Trustees, or what have you.

         5. And just keeping regular monthly or bi-monthly track of everything

         6. Mark in documents, maybe even notarize them, this person's going to be buried here, this person's going to be buried here, this person is already buried here.

         7. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

         8. I know it inside and out, but I think that with Hilda especially, she's sick again.

         9. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

10. I can talk to some of them

11. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

12. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

13. People shouldn’t find out last minute that their loved one can’t be buried there

14. Jennifer R: I can get it for you and work with Rebecca

15. Larry J: what you do, get it written in stone

16. It falls in that archives and history committee, and we can at least get the ball rolling.

17. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

18. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

19. Chief Hatcher: should we see who is buried there now?

20. Chief Hatcher: people are balking because there is limited space

21. Dr. Dillian: GPR should tell you that

22. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

23. The other case was a man with a building on our land

24. Rebecca: it seems pointless; they’re burying people without telling us

25. Phil: Who's been buried there that we don’t know about?

26. Chief Hatcher: no one

27. The problem is they don’t do things the way we ask

28. There isn't really a display place here to put them out that would keep them secure

29. Callie is asking your permission to scan these belongings

30. There are no human remains, and I have never found human remains on this site; a shell midden site

31. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

32. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

33. Glenn: I love science. I've got some stuff I might need to be scanned.

34. Rebecca: I have a question about this because I write grants where I work

35. Chief Hatcher: what happens if the college approves the grant?

36. Rebecca: I don’t think we can vote on it yet and I have concerns

37. Callie: the grant is due in a month or two; I want to alleviate concerns first

38. My other question is, is this stuff being dated?

39. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

40. Callie: the goal is to fund someone who knows the materials too

41. Dr. Dillian: we could  create a digital exhibit

42. Anything I do through college and materials used become partially, if not wholly owned by the college

43. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

44. Dr. Dillian: there’s a strong argument for intellectual property

45. Callie: storage on Morphosource; other tribes are on there

46. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

47. Hard drive for WIP, hard drive for me to avoid losing data

48. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

49. Jennifer R is also concerned

50. Elder Phil: very seldom that someone comes to us beforehand

51. The Elders say they could alienate the tribe if given the cemetery

      3. Rebecca: it could also hurt our recognition chances; it’s our historic land & since there’s  a court case that gives us that land

      4. Elder Larry: I’m opposed to it; trustees are not doing what they’re supposed to do

      5. Elder Charles: keep it all; don’t give up any dirt

      6. Elder Larry: trustees want to take total control

      7. Rebecca: wasn’t there a court case or arbitration; what do the documents say?

      8. Chief Hatcher: actually, we had a person who put a house trailer on our land out there, which is part of a cemetery.

         1. And the court told them to give us an equal amount of property back and let them keep the house trailer

         2. So, we've got the same amount of land as we did have.

      9. Chief Hatcher: they keep some people from being buried there

         1. We’ll have to set this up

         1. A log on who’s going to be buried there

         2. We need to do a survey on who is buried in what spots now

         3. We’d have to determine who goes in which spot & keep a master copy of the list here

10. Rebecca: if we own the land, they have a right to access for people buried there

         1. Chief Hatcher: it isn’t about that court case

         1. The land does belong to us. They know that, but as people that's buried out there, not all of them are members of the tribe.

         2. Some of those folks are relatives of folks that are buried there.

         2. Rebecca: it’s a government/ legal issue if they’re not allowing people to be buried there

         3. Jennifer R: I'm a direct descendant of John Dimery, my ancestors are all buried there, my daughter is buried there.

         1. I have a great many ties, tribal and otherwise, to the cemetery.

         2. This also falls under a lot of work that I do professionally.

         3. I think that some of this might fall under what Rebecca and I are doing as part of the history and archival committee, putting together some of this stuff

         4. I have a lot of historic  newspaper articles about the court cases

         5. And I'm obviously related to everybody on the Board of Trustees, and

         6. I know all of the ins and outs of the issues

         7. And so I think that the best modus operandi for this would be to do research, set up folders for everything we need to know, proof that.

         8. Who owns the land, who's been doing this, who's been checking in, and actually doing the work as the Board of Trustees, or what have you.

         9. And just keeping regular monthly or bi-monthly track of everything

10. Mark in documents, maybe even notarize them, this person's going to be buried here, this person's going to be buried here, this person is already buried here.

11. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

12. I know it inside and out, but I think that with Hilda especially, she's sick again.

13. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

14. I can talk to some of them

15. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

16. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

17. People shouldn’t find out last minute that their loved one can’t be buried there

18. Jennifer R: I can get it for you and work with Rebecca

19. Larry J: what you do, get it written in stone

20. It falls in that archives and history committee, and we can at least get the ball rolling.

21. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

22. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

23. Chief Hatcher: should we see who is buried there now?

24. Chief Hatcher: people are balking because there is limited space

25. Dr. Dillian: GPR should tell you that

26. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

27. The other case was a man with a building on our land

28. Rebecca: it seems pointless; they’re burying people without telling us

29. Phil: Who's been buried there that we don’t know about?

30. Chief Hatcher: no one

31. The problem is they don’t do things the way we ask

32. There isn't really a display place here to put them out that would keep them secure

33. Callie is asking your permission to scan these belongings

34. There are no human remains, and I have never found human remains on this site; a shell midden site

35. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

36. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

37. Glenn: I love science. I've got some stuff I might need to be scanned.

38. Rebecca: I have a question about this because I write grants where I work

39. Chief Hatcher: what happens if the college approves the grant?

40. Rebecca: I don’t think we can vote on it yet and I have concerns

41. Callie: the grant is due in a month or two; I want to alleviate concerns first

42. My other question is, is this stuff being dated?

43. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

44. Callie: the goal is to fund someone who knows the materials too

45. Dr. Dillian: we could  create a digital exhibit

46. Anything I do through college and materials used become partially, if not wholly owned by the college

47. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

48. Dr. Dillian: there’s a strong argument for intellectual property

49. Callie: storage on Morphosource; other tribes are on there

50. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

51. Hard drive for WIP, hard drive for me to avoid losing data

52. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

53. Jennifer R is also concerned

54. Elder Phil: very seldom that someone comes to us beforehand

55. Unfortunately, some of the issue is personality-related

         4. Chief Hatcher: let’s say I agree with you and want to keep the board of trustees the way it is, but I want them to adopt the bylaws

         5. Did you get a copy of the bylaws? I think Colonel Sellers sent a copy out to everybody, didn't she?

         1. Jennifer R: I don't have it, I haven't seen it, um, I can definitely get a copy of it, though

         6. Chief Hatcher: Okay, 2-3 months ago, I talked with Colonel Sellers and I told her that I wanted to do something with the cemetery;  I want it finalized

         1. Because when somebody passes away, laying out a corpse in the ground, it is not a good time to try to settle these issues.

         2. We need to get this stuff settled and really, so that everybody knows who's in charge, who goes where and all that sort of stuff.

         3. I know it inside and out, but I think that with Hilda especially, she's sick again.

         4. Jennifer R: I just spoke to her a couple weeks ago; it is time-sensitive

         5. I can talk to some of them

         6. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

         7. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

         8. People shouldn’t find out last minute that their loved one can’t be buried there

         9. Jennifer R: I can get it for you and work with Rebecca

10. Larry J: what you do, get it written in stone

11. It falls in that archives and history committee, and we can at least get the ball rolling.

12. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

13. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

14. Chief Hatcher: should we see who is buried there now?

15. Chief Hatcher: people are balking because there is limited space

16. Dr. Dillian: GPR should tell you that

17. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

18. The other case was a man with a building on our land

19. Rebecca: it seems pointless; they’re burying people without telling us

20. Phil: Who's been buried there that we don’t know about?

21. Chief Hatcher: no one

22. The problem is they don’t do things the way we ask

23. There isn't really a display place here to put them out that would keep them secure

24. Callie is asking your permission to scan these belongings

25. There are no human remains, and I have never found human remains on this site; a shell midden site

26. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

27. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

28. Glenn: I love science. I've got some stuff I might need to be scanned.

29. Rebecca: I have a question about this because I write grants where I work

30. Chief Hatcher: what happens if the college approves the grant?

31. Rebecca: I don’t think we can vote on it yet and I have concerns

32. Callie: the grant is due in a month or two; I want to alleviate concerns first

33. My other question is, is this stuff being dated?

34. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

35. Callie: the goal is to fund someone who knows the materials too

36. Dr. Dillian: we could  create a digital exhibit

37. Anything I do through college and materials used become partially, if not wholly owned by the college

38. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

39. Dr. Dillian: there’s a strong argument for intellectual property

40. Callie: storage on Morphosource; other tribes are on there

41. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

42. Hard drive for WIP, hard drive for me to avoid losing data

43. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

44. Jennifer R is also concerned

45. Elder Phil: very seldom that someone comes to us beforehand

46. Chief Hatcher: for several years, Linda thought that she was supposed to have a certain spot out there on that cemetery for her body to be placed, but there was nothing that said it, except Linda

47. I'm okay with it staying the way it is, but I do think that we're gonna have to insist that the Board of Trustees come up with some sort of a plan.

48. I suggested that with the bylaws that I provided everybody, but I  can't get them to say they abide with that.

49. People shouldn’t find out last minute that their loved one can’t be buried there

50. Jennifer R: I can get it for you and work with Rebecca

51. Larry J: what you do, get it written in stone

52. It falls in that archives and history committee, and we can at least get the ball rolling.

53. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

54. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

55. Chief Hatcher: should we see who is buried there now?

56. Chief Hatcher: people are balking because there is limited space

57. Dr. Dillian: GPR should tell you that

58. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

59. The other case was a man with a building on our land

60. Rebecca: it seems pointless; they’re burying people without telling us

61. Phil: Who's been buried there that we don’t know about?

62. Chief Hatcher: no one

63. The problem is they don’t do things the way we ask

64. There isn't really a display place here to put them out that would keep them secure

65. Callie is asking your permission to scan these belongings

66. There are no human remains, and I have never found human remains on this site; a shell midden site

67. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

68. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

69. Glenn: I love science. I've got some stuff I might need to be scanned.

70. Rebecca: I have a question about this because I write grants where I work

71. Chief Hatcher: what happens if the college approves the grant?

72. Rebecca: I don’t think we can vote on it yet and I have concerns

73. Callie: the grant is due in a month or two; I want to alleviate concerns first

74. My other question is, is this stuff being dated?

75. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

76. Callie: the goal is to fund someone who knows the materials too

77. Dr. Dillian: we could  create a digital exhibit

78. Anything I do through college and materials used become partially, if not wholly owned by the college

79. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

80. Dr. Dillian: there’s a strong argument for intellectual property

81. Callie: storage on Morphosource; other tribes are on there

82. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

83. Hard drive for WIP, hard drive for me to avoid losing data

84. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

85. Jennifer R is also concerned

86. Elder Phil: very seldom that someone comes to us beforehand

87. Chief Hatcher: As far as I know, we don’t have a list of the trustees

88. Jennifer R: I can get it for you and work with Rebecca

89. Larry J: what you do, get it written in stone

90. It falls in that archives and history committee, and we can at least get the ball rolling.

91. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

92. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

93. Chief Hatcher: should we see who is buried there now?

94. Chief Hatcher: people are balking because there is limited space

95. Dr. Dillian: GPR should tell you that

96. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

97. The other case was a man with a building on our land

98. Rebecca: it seems pointless; they’re burying people without telling us

99. Phil: Who's been buried there that we don’t know about?

100. Chief Hatcher: no one

101. The problem is they don’t do things the way we ask

102. There isn't really a display place here to put them out that would keep them secure

103. Callie is asking your permission to scan these belongings

104. There are no human remains, and I have never found human remains on this site; a shell midden site

105. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

106. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

107. Glenn: I love science. I've got some stuff I might need to be scanned.

108. Rebecca: I have a question about this because I write grants where I work

109. Chief Hatcher: what happens if the college approves the grant?

110. Rebecca: I don’t think we can vote on it yet and I have concerns

111. Callie: the grant is due in a month or two; I want to alleviate concerns first

112. My other question is, is this stuff being dated?

113. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

114. Callie: the goal is to fund someone who knows the materials too

115. Dr. Dillian: we could  create a digital exhibit

116. Anything I do through college and materials used become partially, if not wholly owned by the college

117. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

118. Dr. Dillian: there’s a strong argument for intellectual property

119. Callie: storage on Morphosource; other tribes are on there

120. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

121. Hard drive for WIP, hard drive for me to avoid losing data

122. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

123. Jennifer R is also concerned

124. Elder Phil: very seldom that someone comes to us beforehand

         7. Dr. Dillian: I do have one thing to say that's related to what Chief is saying about having a map.

         1. If we could strongly suggest doing a GPR, ground penetrating radar survey of that cemetery; there may be unmarked graves in there.

         2. CoC Susan: It's already been done; Adam Emerick did it a couple of years ago

         3. Dr. Dillian: I will pull that map to see who is/ isn’t mapped

         4. Chief Hatcher: should we see who is buried there now?

         5. Chief Hatcher: people are balking because there is limited space

         6. Dr. Dillian: GPR should tell you that

         7. If a member of the tribe passes away, that person should have the right to have his spouse buried nearby

         8. The other case was a man with a building on our land

         9. Rebecca: it seems pointless; they’re burying people without telling us

10. Phil: Who's been buried there that we don’t know about?

11. Chief Hatcher: no one

12. The problem is they don’t do things the way we ask

13. There isn't really a display place here to put them out that would keep them secure

14. Callie is asking your permission to scan these belongings

15. There are no human remains, and I have never found human remains on this site; a shell midden site

16. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

17. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

18. Glenn: I love science. I've got some stuff I might need to be scanned.

19. Rebecca: I have a question about this because I write grants where I work

20. Chief Hatcher: what happens if the college approves the grant?

21. Rebecca: I don’t think we can vote on it yet and I have concerns

22. Callie: the grant is due in a month or two; I want to alleviate concerns first

23. My other question is, is this stuff being dated?

24. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

25. Callie: the goal is to fund someone who knows the materials too

26. Dr. Dillian: we could  create a digital exhibit

27. Anything I do through college and materials used become partially, if not wholly owned by the college

28. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

29. Dr. Dillian: there’s a strong argument for intellectual property

30. Callie: storage on Morphosource; other tribes are on there

31. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

32. Hard drive for WIP, hard drive for me to avoid losing data

33. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

34. Jennifer R is also concerned

35. Elder Phil: very seldom that someone comes to us beforehand

36. Chief Hatcher: the deed transferred from Rosie to WIP; Hilda sued & the case was dismissed

37. The other case was a man with a building on our land

38. Rebecca: it seems pointless; they’re burying people without telling us

39. Phil: Who's been buried there that we don’t know about?

40. Chief Hatcher: no one

41. The problem is they don’t do things the way we ask

42. There isn't really a display place here to put them out that would keep them secure

43. Callie is asking your permission to scan these belongings

44. There are no human remains, and I have never found human remains on this site; a shell midden site

45. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

46. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

47. Glenn: I love science. I've got some stuff I might need to be scanned.

48. Rebecca: I have a question about this because I write grants where I work

49. Chief Hatcher: what happens if the college approves the grant?

50. Rebecca: I don’t think we can vote on it yet and I have concerns

51. Callie: the grant is due in a month or two; I want to alleviate concerns first

52. My other question is, is this stuff being dated?

53. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

54. Callie: the goal is to fund someone who knows the materials too

55. Dr. Dillian: we could  create a digital exhibit

56. Anything I do through college and materials used become partially, if not wholly owned by the college

57. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

58. Dr. Dillian: there’s a strong argument for intellectual property

59. Callie: storage on Morphosource; other tribes are on there

60. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

61. Hard drive for WIP, hard drive for me to avoid losing data

62. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

63. Jennifer R is also concerned

64. Elder Phil: very seldom that someone comes to us beforehand

   4. Callie Crawford (CCU faculty member)

      1. Using a sustainability grant to teach about collections and a cultural side; printing is optional

         1. Making the digital models and making them kind of available to be shared; mainly working with the materials that are owned by the tribe

      2. Dr. DIllian: there are some collections at CCU (WIP-owned)

         1. Callie & I have been talking about this is you all know I have been excavating off and on for many years on the Little River Neck near Waties Island

         1. AC Cail has come out to the site and excavated with me

         2. I've talked with all of you about these. These are yours. When you want them, I will transfer them

         3. There isn't really a display place here to put them out that would keep them secure

         4. Callie is asking your permission to scan these belongings

         5. There are no human remains, and I have never found human remains on this site; a shell midden site

         6. Ancestors would have gone to harvest shellfish and there's the belongings that we have are basically pottery, a lot of shell, oyster and clamshells, there's some stone tools, and there's some animals and fish

         7. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

         8. Glenn: I love science. I've got some stuff I might need to be scanned.

         9. Rebecca: I have a question about this because I write grants where I work

10. Chief Hatcher: what happens if the college approves the grant?

11. Rebecca: I don’t think we can vote on it yet and I have concerns

12. Callie: the grant is due in a month or two; I want to alleviate concerns first

13. My other question is, is this stuff being dated?

14. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

15. Callie: the goal is to fund someone who knows the materials too

16. Dr. Dillian: we could  create a digital exhibit

17. Anything I do through college and materials used become partially, if not wholly owned by the college

18. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

19. Dr. Dillian: there’s a strong argument for intellectual property

20. Callie: storage on Morphosource; other tribes are on there

21. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

22. Hard drive for WIP, hard drive for me to avoid losing data

23. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

24. Jennifer R is also concerned

25. Elder Phil: very seldom that someone comes to us beforehand

      3. Callie: the goal is to get cameras and send a photo 3D model

         1. You can upload them to [Morphosource](https://www.morphosource.org/) to share

         1. Phil: are you printing it out so you can hold them?

         2. Callie: it’s an option; most of it's on screen that you can really share it well, especially if there were other people in other locations that wanted to do research on the stuff

         3. Glenn: I love science. I've got some stuff I might need to be scanned.

         4. Rebecca: I have a question about this because I write grants where I work

         5. Chief Hatcher: what happens if the college approves the grant?

         6. Rebecca: I don’t think we can vote on it yet and I have concerns

         7. Callie: the grant is due in a month or two; I want to alleviate concerns first

         8. My other question is, is this stuff being dated?

         9. Dr. Dillian: the belongings that we have are as recent as 1,000 years ago and all the way up to some stone pools that are over 6,000 years old.

10. Callie: the goal is to fund someone who knows the materials too

11. Dr. Dillian: we could  create a digital exhibit

12. Anything I do through college and materials used become partially, if not wholly owned by the college

13. Callie: it can be written into the grant and let CCU decide on it if the university rejects it as it is written

14. Dr. Dillian: there’s a strong argument for intellectual property

15. Callie: storage on Morphosource; other tribes are on there

16. Chief Hatcher: under normal circumstances, when a college finds an artifact, who gets the item?

17. Hard drive for WIP, hard drive for me to avoid losing data

18. Dr. Dillian: usually the landowner, but my proposal said WIP would get their artifacts

19. Jennifer R is also concerned

20. Elder Phil: very seldom that someone comes to us beforehand
