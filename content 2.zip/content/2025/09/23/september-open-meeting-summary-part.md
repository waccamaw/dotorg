---
layout: post
title: "September 2025 Open Meeting Summary: Part 2"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/24/september-open-meeting-summary-part.html
post_id: 5649731
custom_summary: false
summary: ""
date: 2025-09-23T19:00:00-0500
lastmod: 2025-09-23T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2025/09/23/september-open-meeting-summary-part.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---
September's meeting summary will be broken into different consecutive pages, This is a large file and the website cannot handle posting it as a single post, Below is pages end of page 5 through page 10.

1. Driveway

   1. Marion: we need a machine to aerate the driveway; dig up gravel

      1. 2C Alan: cost $1-1.5k for one, based off Austin

      2. Glenn” I disagree with this; it’s been stretched out and you’ll get into mud

         1. Elder Phil: UofSC uses it on their lots and it levels it out

   2. Tabled for now; let him (Austin) explain it

2. Rebecca’s proposal on needs assistance

   1. TC was sent a copy on 9/2

   2. Proposed a one-time loan with caveats

   3. Unsure of where the money would come from just yet

      1. $250 for members in good standing

   4. We keep talking of bringing people back

      1. We’ve got pregnant members and members with a lot of other health issues

   5. It’s a helping hand to be  paid back to let them get on their feet first

   6. It goes along with an Outreach Committee

   7. CoC Susan: we do have a policy of not loaning people money

      1. It would have to be donations

   8. 2C Alan: we would need a separate thing to keep track of it

   9. CoC Susan: we didn’t receive this until a couple of days ago; TC look it over

   10. Tabled until October

3. New Business

   1. Receipts

      1. Fuel: $64.39

         1. Check 895 General Fund due to low B&G fund total

   2. Committee Reports

      1. Buildings & Grounds

         1. Glenn: ditch is being filled in; 2 loads of 5 cubic yards each

         1. Chief: I sent an email about filling it in

         2. TC authorized up to $2k for the ditch; that leaves $1500

         3. If we give another $1k with it, we get all of the first we want

         4. I don’t want to authorize more money if it’s $500 for 10 cubic yards

         5. CoC Susan: Building the ground, I mean, we're gonna have to transfer money to…Have a general fund to cover, correct?

         6. Rebecca-yes, Glenn-yes, Emily-yes, CoC Susan-yes

         7. Elder Phil: I thought me being there with them and showing the arts & crafts; I hadn’t planned on buying anything for them to do arts or crafts

         8. CoC Susan: you’re not? Okay, because I’m not going to worry about it then. Just go through your demonstration

         9. I wouldn’t do a demonstration; I wasn’t asked to do anything

10. You said we’d get together and figure out something

11. Elder Phil: okay, I’ll bring some

12. Secretary’s update: Confluence Grant

13. Secretary’s note: discovered that sharing the link on Facebook doesn’t work; you have to use their Facebook button

14. Part of the learning curve

15. Or Facebook requires it

16. CoC Susan: Chell

17. Michelle: yes; just let Rebecca know

18. It’s never been presented that way

19. We want the words to be the right words & done the right way

20. Dr. Roberts is definitely the right person to do this

21. He’s holding a panel next week on recovering languages and asked me to be on it

22. I did have a grant that I applied for. I have heard nothing back from them.

23. He is giving us his time graciously for free

24. I'm going to work on another grant to see if I can get some funding for him.

25. We're getting close to being able to start recovering language, but right now we're working on the linguistic side of it

26. Where emphasis lies; trying to figure out how you recover words and what's appropriate to recover

27. There's not a lot right now that I would say people would be very excited by, unless you just really love the nerdy side of language.

28. But that’s okay because we'll get it right, and it'll be what our ancestors actually spoke, rather than trying to recover something that is not necessarily what we actually spoke.

29. Chief Hatcher: I got a question about that. What information are you getting; well, you know that it isn't Catawba?

30. Chief Hatcher: Catawba has the Cultural Center run by a lady named Haire; they already have…

31. Chief Hatcher: I believe we called it Waccamaw; it was close to Catawba

32. Rebecca: I mean, if you want us to stop, because I've already talked to Dr. Roberts when I saw the email chain because I did see that it looked like we were reaching out to other groups

33. I did look up Mr.Thigpen and I know he does do linguistics, but not Siouan languages

34. Chief Hatcher: you and Doctor Roberts all to sit down and talk

35. Chief Hatcher: Alright, well, let's see Doctor, whatever his name is, sit down and call, because y'all will have someone to convince me of some of that, because I don't believe

36. Rebecca: Okay, well, I'm gonna have to be done because I'm getting really upset here, because I have been working really hard with Dr. Roberts to work on this. If you would like Dr. Roberts to leave and not do this, and you just want to go with Catawba, that's fine. Because I've given hundreds of dollars towards this, and have not asked for anything.

37. Chief Hatcher: I don't care what y'all do, that's up to you. What best way to heal. Now, I'm happy to be with you.But I'm not gonna jump off on things that I believe are wrong, just because.

38. Rebecca: it's a proto-Siouan, so it is within the Catawba language family. We are most closely related to Catawba

39. Languages break down into like a little pyramid or tree. As it comes down and you fall into different areas

40. Where we sit is in the Catawban area. But as of right now, there's only one word that we have identified that truly does share directly with Catawba

41. They’re pretty hard to reconcile together, but they are in the same family of languages

42. Rebecca: I saw the email chain that had been sent out; it was forwarded to me

43. The problem is we had already spoken with the Catawba because we knew that Woccon was in the same language family

44. They had kind of made it tentatively clear to me that they did not want us encroaching on that

45. The way I read that email chain is they do not want us involved.

46. The problem is we did probably speak a form of Catawba at some point, because we did confederate with them at different times

47. Rebecca: but that wasn’t our actual language

48. Chief Hatcher: Where do you get their language? You’ll have to show me that; It’s Woccon?

49. Chief Hatcher: Where's this information coming from?

50. Rebecca: it is a different language; it is in the same family, but it isn’t Catawba

51. Rebecca: It's coming from historical documents and from linguists who are far smarter than me at this

52. We have a Drive of information

53. I'm constantly mining the resources that I can find and speaking with people

54. The Waccamaw of North Carolina are working on Woccon as well; we are not working with them

55. The Tuscarora or the Cape Fear Tuscarora that group together are also working on this

56. Their language is completely different; they spoke Tuscarora; Cape Fear spoke Woccon

57. We fled to the Catawba for safety. And so, obviously, we had to learn their language

58. Chief Hatcher: When we spoke their language, we wouldn't have went there for that safety

59. Rebecca: No, we spoke a similar language, and we learned how to speak their language

60. Like English and American English

61. They're in the same family, but they are absolutely not the same at all

62. Dr. Roberts does; it’s his entire field

63. Rebecca: I do sit down with him often.

64. If we are claiming to be the historical Waccamaw. This is the language we spoke

65. Chief Hatcher: Say that again? See, we want to call it what could we? We would have called it Waccamaw

66. Rebecca: Woccon is the Waccamaw language

67. Names change over time. The Waccamaw name is not the original name, because if you look in the historical records, it's been Woccon

68. Rebecca: I can give you tons of documentation. If you want. I can send you tons of historical documents that talk about the history of our tribe, as well as the history of North Carolina; this is what I do

69. This is literally my job. I teach history. My area is on pre-contact and contact-era Native Americans. Contact era in particular, just because, obviously, I'm a historian, I'm not an anthropologist.

70. Certain expert on the language, and a few doctor here. So I can go out of this. This is where we fit.

71. Dr. Roberts is a linguist who got his degree

72. Chief Hatcher: Well, Dr. Roberts is gonna have to convince me of that, because I've just learned it different ways than what you're telling.

73. Rebecca: Do you want the historical documents? I will send them to you.

74. Chief Hatcher: Ask the good doctor to give me a call.

75. Chief Hatcher: No, I don't want historical documents. I've got those myself.

76. Rebecca: Then I can't prove anything to you if you won't look at the documents. And I can't prove anything to you if you look at the linguistic documents.

77. Chief Hatcher: Alright, we'll put a hold on what you're doing there, because we're gonna stop that. I'm gonna get to the bottom of it. And we'll go from there.

78. Rebecca: We voted on this, though. I don't understand why you want me to put a hold on it, I'll just tell Corey we're done.

79. Chief Hatcher: Report, that's what you do. You can do that, or tell him to call me.

80. Rebecca: We literally voted in council on this. To pursue this project. Austin is working on an AI to help with this project. Kevin is on this project. Cheryl is on this project. Chell is on this project.

81. Rebecca: I'll ask him if he's got time, but he works with multiple tribes

82. Chief Hatcher: Well, if you don't have time, then try to not worry about it, because we're not going to jump off on a train until I know what it's from.

83. Glenn: That’s a lot of money for 10 cubic yards

84. I don’t want to authorize more money if it’s $500 for 10 cubic yards

85. CoC Susan: Building the ground, I mean, we're gonna have to transfer money to…Have a general fund to cover, correct?

86. Rebecca-yes, Glenn-yes, Emily-yes, CoC Susan-yes

87. Elder Phil: I thought me being there with them and showing the arts & crafts; I hadn’t planned on buying anything for them to do arts or crafts

88. CoC Susan: you’re not? Okay, because I’m not going to worry about it then. Just go through your demonstration

89. I wouldn’t do a demonstration; I wasn’t asked to do anything

90. You said we’d get together and figure out something

91. Elder Phil: okay, I’ll bring some

92. Secretary’s update: Confluence Grant

93. Secretary’s note: discovered that sharing the link on Facebook doesn’t work; you have to use their Facebook button

94. Part of the learning curve

95. Or Facebook requires it

96. CoC Susan: Chell

97. Michelle: yes; just let Rebecca know

98. It’s never been presented that way

99. We want the words to be the right words & done the right way

100. Dr. Roberts is definitely the right person to do this

101. He’s holding a panel next week on recovering languages and asked me to be on it

102. I did have a grant that I applied for. I have heard nothing back from them.

103. He is giving us his time graciously for free

104. I'm going to work on another grant to see if I can get some funding for him.

105. We're getting close to being able to start recovering language, but right now we're working on the linguistic side of it

106. Where emphasis lies; trying to figure out how you recover words and what's appropriate to recover

107. There's not a lot right now that I would say people would be very excited by, unless you just really love the nerdy side of language.

108. But that’s okay because we'll get it right, and it'll be what our ancestors actually spoke, rather than trying to recover something that is not necessarily what we actually spoke.

109. 
