---
layout: post
title: "Native American Heritage Month Proclamations"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/23/native-american-heritage-month-proclamations.html
post_id: 5649998
custom_summary: false
summary: ""
date: 2025-09-22T19:00:00-0500
lastmod: 2025-11-22T19:26:01-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/3738047bfc.jpg
- https://cdn.uploads.micro.blog/272201/2025/f9b62a4e28.jpg
- https://cdn.uploads.micro.blog/272201/2025/13f6d5866e.jpg
- https://cdn.uploads.micro.blog/272201/2025/6776eb7ed6.jpg
- https://cdn.uploads.micro.blog/272201/2025/760dd6d584.jpg
- https://cdn.uploads.micro.blog/272201/2025/303b746b74.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c8d9d877a.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/3738047bfc.jpg
- https://cdn.uploads.micro.blog/272201/2025/f9b62a4e28.jpg
- https://cdn.uploads.micro.blog/272201/2025/13f6d5866e.jpg
- https://cdn.uploads.micro.blog/272201/2025/6776eb7ed6.jpg
- https://cdn.uploads.micro.blog/272201/2025/760dd6d584.jpg
- https://cdn.uploads.micro.blog/272201/2025/303b746b74.jpg
- https://cdn.uploads.micro.blog/272201/2025/2c8d9d877a.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/3738047bfc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f9b62a4e28.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/13f6d5866e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6776eb7ed6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/760dd6d584.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/303b746b74.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2c8d9d877a.jpg
url: /2025/09/22/native-american-heritage-month-proclamations.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Nov 13, 2024
- 1 min read

We thank the City of Conway and Mayor Barbara Blain, the City of Georgetown and Mayor Carol Jayroe, the City of Myrtle Beach and Mayor Brenda Bethune, the County of Georgetown and Councilman Louis Mourant, and SC Governor Henry McMaster for recognizing tribes in SC. We encourage the state legislature and SC residents to visit our tribal grounds.

![ree](https://waccamaw.micro.blog/uploads/2025/3738047bfc.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/f9b62a4e28.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/13f6d5866e.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/6776eb7ed6.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/760dd6d584.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/303b746b74.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/2c8d9d877a.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [#NativeAmericanHeritageMonth](https://www.waccamaw.org/updates/tags/nativeamericanheritagemonth)
