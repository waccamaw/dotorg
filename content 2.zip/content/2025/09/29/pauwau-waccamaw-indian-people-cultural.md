---
layout: post
title: "Pauwau 2025: Waccamaw Indian People Cultural Arts Festival"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/29/pauwau-waccamaw-indian-people-cultural.html
post_id: 5650007
custom_summary: false
summary: ""
date: 2025-09-29T09:16:05-0500
lastmod: 2025-11-22T19:32:41-0500
type: post
thumbnail: https://s3.amazonaws.com/micro.blog/thumbnails/2025/11/23/waccamaw.micro.blog/6c8e6a0740b8aacd8321d92214c8afe4.png
opengraph:
  title: "Waccamaw.org - Pauwau 2025: Waccamaw Indian People Cultural Arts Festival"
  image: https://s3.amazonaws.com/micro.blog/opengraph/2025/11/23/5650007.png
images:
- https://cdn.uploads.micro.blog/272201/2025/d785f27e94.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/d785f27e94.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/d785f27e94.jpg
url: /2025/09/29/pauwau-waccamaw-indian-people-cultural.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# Pauwau 2025: Waccamaw Indian People Cultural Arts Festival

-

Michelle Hatcher
- Sep 29
- 1 min read

Updated: Oct 27

Come join the Waccamaw Indian People for the 33rd Annual Cultural Arts Festival & Pauwau 2025! This is a weekend filled with education, fun, and cultural celebration.

### Highlights of the Weekend Include:

-

**Cultural Demonstrations:** Experience traditional skills and educational showcases.

-

**Survival Skills:** Learn about traditional survival techniques.

-

**Dance & Raffle:** Participate in the **"Luck of the Draw" Dance Raffle** for cash prizes of $100-$500!

  -

Dancers: You only need to have tribal affiliation. You don't need to show your ID or tribal affiliation.

-

**Vendors:** Explore a wide variety of **food and craft vendors**.

-

**Longhouse Project:** See the incredible progress being made on the **Waccamaw Longhouse Project** and learn about this important cultural revitalization effort through our Interpretative Trail

This event is a wonderful opportunity to learn, celebrate, and support the ongoing cultural and community work of the Waccamaw Indian People. We look forward to seeing you there!

We will be having a Friday night social at 7 or 7:30 pm after the school days event, setup, etc... Depending on the weather, it may be held indoors.

![ree](https://waccamaw.micro.blog/uploads/2025/d785f27e94.jpg)

Tags:

- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [#Events](https://www.waccamaw.org/updates/tags/events)
- [#Announcement](https://www.waccamaw.org/updates/tags/announcement-1)
- [#Education](https://www.waccamaw.org/updates/tags/education-1)
- [#Pauwau2025](https://www.waccamaw.org/updates/tags/pauwau2025)
