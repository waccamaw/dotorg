---
layout: post
title: "Invasive Species Removal & Plant Rescue"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/28/invasive-species-removal-plant-rescue.html
post_id: 5649984
custom_summary: false
summary: ""
date: 2025-09-28T11:41:10-0500
lastmod: 2025-11-22T19:32:46-0500
type: post
thumbnail: https://s3.amazonaws.com/micro.blog/thumbnails/2025/11/23/waccamaw.micro.blog/772a11c841ca1ae7d5ccafb3b448a216.png
images:
- https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1f268751b7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b4a4d7f22b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/41833eb75f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1cf82af893.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1d8013ec6d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/cccf5a6d34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/85ce022d8d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/be11e8e53c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a30d0c7631.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f1f9d99e5f.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/8f2ead57fb.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f8da41ac7c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fbe35ed2f0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1d1fe68d10.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ad2d3209ac.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/41ae2bac34.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ba5f88c8e2.jpg
url: /2025/09/28/invasive-species-removal-plant-rescue.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# Invasive Species Removal & Plant Rescue

-

Michelle Hatcher
- Sep 28
- 1 min read

On September 13, 2025, we partnered with the Grand Strand Chapter of the @scnativeplantsociety for a day focused on invasive species removal, plant rescues, and plant identification. Together, we successfully cut back numerous invasive species, relocated rescued plants to an area where they can begin to thrive, identified several native species, and even had a critter or two stop by! We extend our deepest gratitude to the Grand Strand Chapter of the @scnativeplantsociety; this project would have been significantly delayed without their help.

![image](https://waccamaw.micro.blog/uploads/2025/1f268751b7.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1f268751b7.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b4a4d7f22b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b4a4d7f22b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/41833eb75f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/41833eb75f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1cf82af893.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1cf82af893.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1d8013ec6d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1d8013ec6d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/cccf5a6d34.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/cccf5a6d34.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/85ce022d8d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/85ce022d8d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/be11e8e53c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/be11e8e53c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a30d0c7631.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a30d0c7631.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f1f9d99e5f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f1f9d99e5f.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/8f2ead57fb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/8f2ead57fb.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f8da41ac7c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/f8da41ac7c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fbe35ed2f0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fbe35ed2f0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1d1fe68d10.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1d1fe68d10.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ad2d3209ac.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ad2d3209ac.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/41ae2bac34.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/41ae2bac34.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ba5f88c8e2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ba5f88c8e2.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Events](https://www.waccamaw.org/updates/tags/events)
- [#Announcement](https://www.waccamaw.org/updates/tags/announcement-1)
- [#SCNPS](https://www.waccamaw.org/updates/tags/scnps)
