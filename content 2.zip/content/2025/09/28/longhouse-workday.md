---
layout: post
title: "Longhouse Workday"
microblog: false
guid: http://waccamaw.micro.blog/2025/09/28/longhouse-workday.html
post_id: 5649994
custom_summary: false
summary: ""
date: 2025-09-28T11:17:10-0500
lastmod: 2025-11-22T19:24:38-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
- https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/3fec8bd485.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/5bf6e374a6.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1dc9c2fd99.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/64fca12390.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7b48f34934.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a080b12459.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/95ff2a0c60.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e527f90e98.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/58dff689e7.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/20b8e275d1.jpg
url: /2025/09/28/longhouse-workday.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# Longhouse Workday

-

Michelle Hatcher
- Sep 28
- 1 min read

On September 13, 2025, we completed a productive longhouse workday.

We debarked logs and added them to the longhouse after leveling the existing standing logs. The structure is now ready for matting on the sides and a roof on top. Currently, the remaining debarked logs are soaking in the pond to make them pliable.

We extend our sincere gratitude to Dr. Carolyn Dillian and the CCU Chanticleers students, Waccamaw Tribal Constable Greg Morgan, and all dedicated volunteers for their invaluable assistance.

We also give a special thank you to all Waccamaw tribal members who came out to help, especially Council Member Marion Craddock, whose commitment to all our projects is invaluable.

![image](https://waccamaw.micro.blog/uploads/2025/3fec8bd485.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/3fec8bd485.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5bf6e374a6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/5bf6e374a6.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1dc9c2fd99.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1dc9c2fd99.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/64fca12390.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/64fca12390.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7b48f34934.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7b48f34934.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a080b12459.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/a080b12459.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/95ff2a0c60.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/95ff2a0c60.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/e527f90e98.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/e527f90e98.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/58dff689e7.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/58dff689e7.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/20b8e275d1.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/20b8e275d1.jpg)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [#Events](https://www.waccamaw.org/updates/tags/events)
- [#Announcement](https://www.waccamaw.org/updates/tags/announcement-1)
- [#LonghouseWorkday](https://www.waccamaw.org/updates/tags/longhouseworkday)
