---
layout: post
title: "New Sharing Link Ability"
microblog: false
guid: http://waccamaw.micro.blog/2025/05/04/new-sharing-link-ability.html
post_id: 5650001
custom_summary: false
summary: ""
date: 2025-05-03T19:00:00-0500
lastmod: 2025-11-22T19:26:11-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/cdadb89d14.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/cdadb89d14.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/cdadb89d14.jpg
url: /2025/05/03/new-sharing-link-ability.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- May 4
- 1 min read

With Linkpod, connecting with us online is a breeze! You'll find links to all our websites and social media. Plus, sharing is simple: tap the "Share" icon in the top right for a handy QR code your friends can use.

![ree](https://waccamaw.micro.blog/uploads/2025/cdadb89d14.jpg)

Tags:

- [Announcement](https://www.waccamaw.org/updates/tags/announcement)
- [community](https://www.waccamaw.org/updates/tags/community)
- [#SocialMedia](https://www.waccamaw.org/updates/tags/socialmedia)
