---
layout: post
title: "Pauwau 2024 Fliers"
microblog: false
guid: http://waccamaw.micro.blog/2025/04/01/pauwau-fliers.html
post_id: 5650003
custom_summary: false
summary: ""
date: 2025-03-31T19:00:00-0500
lastmod: 2025-11-22T19:26:29-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/610d7efc1c.jpg
- https://cdn.uploads.micro.blog/272201/2025/3a43099105.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/610d7efc1c.jpg
- https://cdn.uploads.micro.blog/272201/2025/3a43099105.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/610d7efc1c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/3a43099105.jpg
url: /2025/03/31/pauwau-fliers.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Sep 21, 2024
- 1 min read

Updated: Oct 1, 2024

Here are the fliers for our Pauwau for 2024. Update 10/1/2024: As of today, we will only have dancers list their tribal affiliation. Our pauwau is to showcase Indigenous art and the people who may win in the dance raffle will be Indigenous. Anyone may dance in the intertribal dances. Every dancer will be given a copy of the disclaimer and rules at the time of registration.

![ree](https://waccamaw.micro.blog/uploads/2025/610d7efc1c.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/3a43099105.jpg)
