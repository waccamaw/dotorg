---
layout: post
title: "Longhouse Workday 10/4/2025"
microblog: false
guid: http://waccamaw.micro.blog/2025/10/05/longhouse-workday.html
post_id: 5649738
custom_summary: false
summary: ""
date: 2025-10-05T10:10:00-0500
lastmod: 2025-11-22T19:33:39-0500
type: post
categories:
- "updates"
- "community"
- "events"
thumbnail: https://s3.amazonaws.com/micro.blog/thumbnails/2025/11/22/waccamaw.micro.blog/e82a8bcc50c33246efdabdb93de88c99.png
opengraph:
  title: "Waccamaw.org - Longhouse Workday 10/4/2025"
  image: https://s3.amazonaws.com/micro.blog/opengraph/2025/11/22/5649738.png
images:
- https://cdn.uploads.micro.blog/272201/2025/402a1ed0db.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b4478fee0.jpg
- https://cdn.uploads.micro.blog/272201/2025/e848827fb2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ddaa997dfd.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f54cec733.jpg
- https://cdn.uploads.micro.blog/272201/2025/a5a7efc679.jpg
- https://cdn.uploads.micro.blog/272201/2025/c24fe19465.jpg
- https://cdn.uploads.micro.blog/272201/2025/716ed021fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/f597372b32.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/402a1ed0db.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b4478fee0.jpg
- https://cdn.uploads.micro.blog/272201/2025/e848827fb2.jpg
- https://cdn.uploads.micro.blog/272201/2025/ddaa997dfd.jpg
- https://cdn.uploads.micro.blog/272201/2025/6f54cec733.jpg
- https://cdn.uploads.micro.blog/272201/2025/a5a7efc679.jpg
- https://cdn.uploads.micro.blog/272201/2025/c24fe19465.jpg
- https://cdn.uploads.micro.blog/272201/2025/716ed021fc.jpg
- https://cdn.uploads.micro.blog/272201/2025/f597372b32.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/402a1ed0db.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7b4478fee0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/e848827fb2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ddaa997dfd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/6f54cec733.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/a5a7efc679.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/c24fe19465.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/716ed021fc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/f597372b32.jpg
url: /2025/10/05/longhouse-workday.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Progress Report! We had an amazing longhouse workday yesterday, complete with perfect weather! We successfully pulled the remaining logs from the pond. After a bit of trial and error (classic construction!), we figured out the best technique for setting the roof arc: forming the arc before hoisting the logs to the top. Now, to keep them safe, we'll be watering them down to prevent drying and splitting.

![Logs being lifted](https://waccamaw.micro.blog/uploads/2025/402a1ed0db.jpg)

![Construction progress](https://waccamaw.micro.blog/uploads/2025/7b4478fee0.jpg)

![Roof arc assembly](https://waccamaw.micro.blog/uploads/2025/e848827fb2.jpg)

![Team working on structure](https://waccamaw.micro.blog/uploads/2025/ddaa997dfd.jpg)

A huge THANK YOU to Nancy, Clayton, Marion, Cheryl, Sara, Liz, Sydney, and Carolyn for all your muscle and dedication. This project is really taking shape! Want to join the fun? Keep an eye on our Facebook page (and other social media) for the date of our next workday!

![Volunteers at work](https://waccamaw.micro.blog/uploads/2025/6f54cec733.jpg)

![Progress shot](https://waccamaw.micro.blog/uploads/2025/a5a7efc679.jpg)

![Completed roof arc](https://waccamaw.micro.blog/uploads/2025/c24fe19465.jpg)

![Team photo](https://waccamaw.micro.blog/uploads/2025/716ed021fc.jpg)

![Final structure view](https://waccamaw.micro.blog/uploads/2025/f597372b32.jpg)
