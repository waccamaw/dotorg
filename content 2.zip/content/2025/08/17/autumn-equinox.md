---
layout: post
title: "Autumn Equinox 2025"
microblog: false
guid: http://waccamaw.micro.blog/2025/08/17/autumn-equinox.html
post_id: 5649936
custom_summary: false
summary: ""
date: 2025-08-17T10:14:55-0500
lastmod: 2025-11-22T19:06:48-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/29125d911c.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b4d31139e.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/29125d911c.jpg
- https://cdn.uploads.micro.blog/272201/2025/7b4d31139e.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/29125d911c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7b4d31139e.jpg
url: /2025/08/17/autumn-equinox.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

# Autumn Equinox 2025

-

Michelle Hatcher
- Aug 17
- 1 min read

Updated: Aug 31

The autumn equinox is almost here! We invite you to join our celebration on September 20th with events scheduled for 7:04 a.m., Noon, 4:00 p.m., and 6:30 p.m. Let's welcome the new season together.

![ree](https://waccamaw.micro.blog/uploads/2025/29125d911c.jpg)

![ree](https://waccamaw.micro.blog/uploads/2025/7b4d31139e.jpg)

Tags:

- [Native](https://www.waccamaw.org/updates/tags/native)
- [Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-2)
- [#SaveTheDate](https://www.waccamaw.org/updates/tags/savethedate)
- [AutumnEquinox](https://www.waccamaw.org/updates/tags/autumnequinox)
