---
layout: post
title: "Pauwau 2023 Income & Expenses"
microblog: false
guid: http://waccamaw.micro.blog/2025/08/13/pauwau-income-expenses.html
post_id: 5650004
custom_summary: false
summary: ""
date: 2025-08-12T19:00:00-0500
lastmod: 2025-08-12T19:00:00-0500
type: post
url: /2025/08/12/pauwau-income-expenses.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Feb 27, 2024
- 1 min read

This spreadhseet contains all income and expenses made during the 2023 pauwau.

PW2023Public.xlsx

Download XLSX • 55KB

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [#Native](https://www.waccamaw.org/updates/tags/native-2)
- [#PW2023](https://www.waccamaw.org/updates/tags/pw2023)
