---
layout: post
title: "May Open Meeting"
microblog: false
guid: http://waccamaw.micro.blog/2017/05/06/may-open-meeting.html
post_id: 5649696
custom_summary: false
summary: ""
date: 2017-05-05T19:00:00-0500
lastmod: 2017-05-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2017/05/05/may-open-meeting.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 5/5/2017 held at the Tribal Office in Aynor, SC

1. CM’s John, Susan, Robert, Mark, Dalton, and CoC Rick present. Summary prepared from audio file of May meeting.

2. April summary read

3. Dalton motioned to accept; Susan seconded

4. Homer-yes, John-yes, Susan-yes, Robert-yes, Mark-abstain, Dalton-yes, Rick-yes

5. Financial Report

6. General Fund: $8893.34

7. Building Fund: $1532.29

8. Cemetery Fund: $531.26

9. Online Votes

10. 4/12 Purchase Laptop for Office/ Filekeeper Use: $499

11. Robert-y, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

12. 4/19 Pay tractor Mowing Deck Repair Bill: $412

13. Robert-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

14. Old Business

15. Cemetery Encroachment

16. Chief Hatcher: Spoke to Mr. Beverly, who is supposed to schedule a meeting with the opposing attorney

17. 2nd Chief Cheryl: best way to reach Mr. Beverly is by email

18. Roof case Update

19. Chief Hatcher: Mr. Sampson will not answer door to receive papers

20. John: what if you never physically hand it to him?

21. Chief: He doesn’t have to physically handle it; you just need an unbiased person there to show he saw it

22. John: Will judge just say enough of this and force it to court?

23. Chief: no, he won’t go to court until he has been served

24. New Business

25. Open Forum

26. CoC Rick

27. To Doug & Jewell for their efforts on the Fishing Day, Chief made handmade arrows, I will put them on a plaque for you

28. Thank you to everyone who worked on the Fishing Day. It turned out well, even better than previous year

29. Chief: also wrote a letter to the couple who helped on the yard sale, want everyone to sign it, and then I’ll mail it to them

30. Susan: propose that minutes come out earlier so we can do the things we said we would do (example: email discussions)

31. Dalton: don’t necessarily need minutes to do that; we could have sent each other an email that night, but understand what you’re saying & we’ve talked about it before

32. Rick: want to schedule a work day coming up

33. Mark: Council work day

34. Rick: Ray donated the golf cart

35. Mark: for B&G & Donnie to use

36. Rick: it needs 6-6V batteries ($80-100 each)

37. John: the Mayor- doesn’t he run a golf cart place?

38. Several: yes, ex-mayor

39. John: perhaps he could help us out

40. Alan: CMA is looking for someone to do an internship. It’s in Columbia, but you can do it through the internet

41. Small Business grants from CMA, usually requires you to come up with 10% of it

42. They will conduct a 13-week workshop & $75 for whole course

43. Chief Hatcher:

44. I filed IRS & State paperwork for the tribe

45. I’ll be submitting an ANA grant for us, but first I have to write the proposal to Council, & Council has to pass it. I’d like for it to be on language.

46. Chief asked for a show of hands in people interested in being taught native language

47. Statue of Chief Norris being made in Greenville

48. Earl Manyskins: I would like to give him $200; he’s been sick

49. Dalton motioned to give Earl $400; Mark seconded

50. Robert-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

51. Backhoe for sale in Greenville; will look at it while I’m there

52. Committee Reports

53. Buildings & Grounds: Rick

54. We figured out the electrical problem at the circle and it’s not going to be as expensive to fix as we thought

55. Arts & Crafts: Susan

56. Had our class with 3 people present

57. Have to think of another idea for another month (probably June)

58. Mark: do you need turkey feathers for membership feathers?

59. Susan: we don’t use the big feathers; we use the smaller ones

60. Mark: pin feathers and 2 sets of wing feathers

61. 2nd Chief Phil: why don’t we do a feather wrap as a class?

62. Susan: we can do that

63. 2nd Chief Cheryl: or dreamcatchers

64. Susan: would like to see more tribal involvement in the classes

65. I have a small display cabinet to start setting our own A&C museum

66. 2nd Chief Cheryl: is there a possibility that Iris would be interested in teaching what she does?

67. Susan: you can ask her

68. Grants: Michelle

69. SCAC should start reviewing grants soon & we should hear back soon

70. Pauwau: Michelle

71. Next meeting: Thursday 5/13 @ 6pm

72. Still a handful of tickets to the Hog Heaven fundraiser on 6/13; tickets are $20

73. Susan: we would like to see more tribal members there instead of just the 8 or so usual people

74. Chris Judge from USC will be the speaker

75. Michelle: half of the ticket cost comes back to the tribe

76. Susan: money is used for billboards & flyers

77. Dalton: our budget should be ready to submit at the next meeting

78. 2nd Chief Cheryl: we still have some things to work out, like hay

79. Rick: have you looked at bleachers recently?

80. Mark: will again soon

81. Susan: we like the idea of the benches at the front circle

82. 2nd Chief Phil: remember to get pressure treated wood to use every year

83. Rick: we could look at the composite (more expensive but no maintenance)

84. Buildings & Grounds: Rick

85. Electric

86. Electrical problem at circle is due to one circuit (at 4,5,6 vendor plugs & lights going into grand entry)- it’s bleeding over

87. Plan is to come from campground boxes & add on

88. Mark: also talking about moving lights at grand entry up to about 20ft in the air

89. Rick: without knowing the cost of the pole, thinking probably a $300 budget

90. Susan: make it $500 since that’s what we received from the church

91. Dalton: budget it for $500 just in case

92. Mark motioned to budget $500 to fix the electrical; Susan seconded

93. Robert-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

94. 2nd Chief Phil: PA system: how hard would it be to wire 2 speakers in around the circle as we’re doing this?

95. Rick: we can run 2 circuits while we’re doing this

96. 2nd Chief Phil: we’d have speakers all around the circle, then we will have a sound system like you wouldn’t believe

97. Rick: this should take care of electrical for the year, but we may need money for rest of the circle or in case it fails

98. Susan: we should also put a padlock on the breaker box

99. Roof: still need to do siding & metal on the boxing, but it is weathertight now

100. John: faucet closest to circle needs to be repaired

101. Mark: we need to put a hydrant there

102. Mark: cemetery needs to have a work day sometime soon

103. Susan: who’s in charge of B&G

104. Mark: Neal’s got it

105. Rick: Neal’s took it over, but he’s not here

106. Drum: Rick

107. Nothing new to report

108. 2nd Chief Phil: have been working on the old drum

109. Parking Lot & Shuttle: John

110. Haven’t received any responses to emails & brochures I sent out

111. Dalton: you probably want to have someone out here just in case

112. No inquiry calls or reservations

113. Dalton: a lot of people show up bike weekends without a reservation

114. Fuel Receipts: $27.20 Check 575

115. Special Needs Fishing Day: Rick

116. Thank you to everyone who participated, donated, come out & help

117. Will put arrows on plaque for Doug & Jewell

118. We received a lot of positive feedback

119. Tony & Dawn Collins: Bass Pro Shops professional crappy fisherpersons

120. Take a Child Fishing program

121. They would like to come back

122. Mark: only complaint was from game warden because it was Easter weekend

123. Elder Doug: I would leave it at the same time each year; people will come to expect it that way

124. Michelle: Jeri Hunter sent me pictures from the Fishing Day & they are now on the tribal website

125. Mark: I need to send you some too; I took a bunch

126. Rick: I will get Jessie to send some to you

127. Rick: Did anyone see the archery station set up by Greg Lee?

128. It was for the kids in wheelchairs

129. Elder Doug: Chief Locklear has a large stainless sink; we could get it for here

130. John: we need a new American flag

131. Michelle: and state

132. Rick motioned to let Susan buy the flags; Mark seconded

133. Robert-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

134. Someone donated an American flag while in meeting

135. Elder Doug: would you be interested in opening our Pauwau with the national anthem?

136. Michelle, Susan, others: we can discuss it at the next Pauwau meeting

137. 2nd Chiefs

138. Phil: Trail of Tears ride, 200-mile ride through AL in September

139. Cheryl: Salesforce grant went through

140. Will have a Council Work Day to get this off the ground

141. Potentially have it up and running in 30-60 days, depending on Doug’s schedule

Mark motioned to close the meeting; Dalton seconded.

Meeting adjourned 9:08 pm.

Respectfully submitted by Michelle Hatcher on 5/24/17 at 12:28 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
