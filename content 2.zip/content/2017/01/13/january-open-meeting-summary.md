---
layout: post
title: "January 2017 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2017/01/14/january-open-meeting-summary.html
post_id: 5649692
custom_summary: false
summary: ""
date: 2017-01-13T19:00:00-0500
lastmod: 2017-01-13T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2017/01/13/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 1/13/2017 held at the Tribal Office in Aynor, SC

1. CM’s Mark, John, and Robert present. 2nd Chief Cheryl served as a proxy for Susan and Rick; CM Dalton served as ACoC

2. Condolences to Hank & Phil on passing of Kathy

3. Oct Minutes read

4. Mark motioned to accept; Robert seconded

5. Mark-yes, John-yes, Robert-yes, 2nd Chief Cheryl (Susan)-yes, 2nd Chief Cheryl (Rick)-yes, Dalton-yes

6. Dec Minutes Read

7. Online vote with 2 changes

8. 5(a)(i) should be Circuit instead of magistrate

9. 5(b)(xii) should be beneficiaries instead of beneficial

10. [Susan]-yes, 2nd Chief Cheryl [Rick]-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes

11. Online Votes

12. Roof: Update: Sampson to finish it by Monday

13. [Susan]-yes, [Rick]-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes

14. Reimburse Chief Hatcher $500 for Bingo money he put in

15. John-yes, Robert-yes, Mark-abstain, Dalton-yes

16. Old Business

17. Cemetery Encroachment Update: 2nd Chief Cheryl

18. Motion quashed because they argued the tribe was a corporation

19. Notice to creditors has to be done within 8 months of first publication, but statute also says within 1 year of death

20. Not sure the tribe qualifies as a creditor

21. Quiet Title Action: judge thought this might be solution

22. File in Circuit Court with attorney (not self or trustees)

23. Have until 1/23 to file recording in register of deeds

24. Elder Doug: do we have a cost from Terry Beverly?

25. 2nd Chief Cheryl: $10k retainer because of litigation

26. Elder Doug: What about arbitration?

27. 2nd Chief Cheryl: Mediation to resolve it; could lead to adverse possession in 10 years if we do nothing

28. John: could we give them 0.25 acre & set boundary line with them

29. 2nd Chief Cheryl: I’d suggest that too, but 0.25 acres isn’t worth $10k

30. Ray: Can attorney put a stop on it & bring it to mediation to get them to abide by mediator’s ruling?

31. Mark: if we filed, would it put pressure on the boys to work it out?

32. John: would the lawyer be willing to take payments?

33. 2nd Chief Cheryl: he would take $2k to start, but he wanted to hold off and ask other attorneys

34. Richard: Mr. James has the same deed as we do, not survey, according to what was said in court

35. Elder Dan: will the BIA or SCIAC not help?

36. 2nd Chief Cheryl: we’re not under the same protection as federal tribes; state preservation offices maybe?

37. John: goal is to define the lines; can we hire Beverly to talk to his lawyer?

38. 2nd Chief Cheryl to get back with Council on Wednesday; Council make decisions Thursday/ Friday if necessary

39. Dalton: we could try the Indian Law Center & our investors

40. Investor Proposal by John

41. Would be a promissory note

42. Dalton: can you do a percentage on a note?

43. 2nd Chief Cheryl: there’s a limit when SEC gets involved; percentages become equal to stocks/ dividends

44. With flat rate, there’s a limit on the amount you can solicit

45. John: is there a difference between tribal vs non-tribal?

46. 2nd Chief Cheryl: we’d have to find out

47. Council to continue discussing this online; tabled to February

48. New Business

49. Committee Reports

50. Grants: Michelle

51. Looking at several USDA grants & contacting Ms. Braught for ideas

52. Pauwau: Michelle

53. Meetings are second Thursday of each month

54. Need collaboration between PW Committee, B&G, Council before changes to circle are made

55. 2017 Chair: Michelle

56. Buildings & Grounds

57. Meeting 1/14 at 12pm

58. Parking Lot & Shuttle: John

59. Put blurb on FB pages

60. Ray talked to people in Mooresville to check for interest

61. Also looked for interest in camping spots

62. Mark: would need security on grounds if camping

63. 2nd Chief Cheryl

64. Did a Sample Segmentation from Saturday

65. Shows breakdown of ages

66. Need to revise to add Sunday numbers

67. Need to revise the demographics form slightly

68. Need to have Veteran’s Ceremony every year

69. Address at Pauwau meeting

70. Sometimes we run out of feathers; sometimes people don’t know where to go to get them

Mark motioned to close the meeting; Robert seconded.

Meeting adjourned 7:38 pm.

Respectfully submitted by Michelle Hatcher on 1/30/17 at 2:42 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
