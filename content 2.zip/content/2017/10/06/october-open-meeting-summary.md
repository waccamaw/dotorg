---
layout: post
title: "October 2017 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2017/10/07/october-open-meeting-summary.html
post_id: 5649699
custom_summary: false
summary: ""
date: 2017-10-06T19:00:00-0500
lastmod: 2017-10-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2017/10/06/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/06/2017 held at the Tribal Office in Aynor, SC

1. CM’s John, Mark, Dalton, Susan, Robert, Jeania, and CoC Rick  present. Elders Glenn, Dan, Doug, and Ronnie present.

2. Financial Report

3. General Fund: $7434.19  (as of 10/5/2017 on CNB site)

4. Building Fund: $1286.27 (as of 10/5/2017 on CNB site)

5. Cemetery Fund: $531.26

6. Online Votes

7. 9/14 September Minutes

8. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

9. 9/17 Roof repair

10. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

11. 9/20 Sprayer Vote

12. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

13. 10/2 Fix bathroom in tribal office

14. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

15. Thank you to Larry J for his work

16. 10/2 Postpone Council Work Day

17. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

18. Old Business

19. Elder Position

20. Chief Hatcher: Becky S was recommended and I nominate her

21. Becky S to be interviewed by Council at December meeting

22. New Business

23. Solstice: John T

24. Wanted to discuss solstice because it’s being done 2 weeks late

25. Robert: they said a storm was coming

26. John: then don’t have it 2 weeks late, cancel instead

27. Rick: I leave it to the Firekeeper

28. John: should it be his decision?

29. Rick: yes, he runs it

30. Dalton: we have no one else to do it. Question is are we going to forbid him from doing it?

31. John: it’s Council purview; it should be done close to the day of the solstice

32. Robert: a storm was coming

33. John: if we were a true Indian tribe, the Firekeeper would still be doing it

34. Mark: second time it was moved because of a funeral

35. John: 90% of the tribe didn’t go to the funeral; still could have done it

36. Rick: Mr. Williams was glad we moved the date

37. Mark: going forward, it needs to be done close to the date

38. Robert: a storm was coming

39. Mark: I understand this one

40. John: Council should decide on postponement

41. Rick: Robert, what do you think? Should it be a Council or Firekeeper call?

42. Robert: it should be the Firekeeper’s call

43. Dalton: could you call about postponements before postponing?

44. Robert: yes

45. Dalton: it’s a religious thing; I, personally, don’t want Council involved

46. Dalton: to me, it’s letting the Firekeeper use the tribal land and when Council will allow him to use it

47. John: the fire is part of heritage/ tradition

48. Dalton: I care about heritage, but don’t want to endorse religion

49. Chief Hatcher: In ancient times, Firekeeper kept fires going and it wasn’t religious

50. It should be done on the day it’s supposed to be done

51. John: a 2-week postponement doesn’t make sense

52. Rick: you argue we make the day inconvenient and that it’s not always the day of the solstice

53. Chief Hatcher: Robert could do the religious part at his house on the day of the solstice; a public ceremony can be done later

54. Elder Doug: it’s a spiritual ceremony, not religious

55. Jeania: it was understandable for that time; it should be done the day of even it’s just at your home and cancel altogether if it’s going to be late

56. John: should postponing be a Council decision?

57. Dalton: I asked that earlier; Robert said yes

58. Rick: if you aren’t going to be here, you don’t need to vote

59. John: no, it’s a Council decision; that means all of us

60. Dalton: John’s right

61. Dalton: I asked Robert if he would be ok if we postpone, not the same as telling him to not tend fire. There’s nothing on these grounds Council shouldn’t be included in

62. Chief Hatcher: Solstice/ Equinox ceremonies are dictated by Manyskins and done on the days it’s supposed to be done; Council makes decision on public ceremony date

63. Rick: it’s a spiritual ceremony to me

64. Chief Hatcher: during Pauwau, it’s a uniting ceremony

65. Fuel Receipts: $88.20 Check 590

66. Fundraiser: John

67. We need to do a fundraiser & need ideas so we can discuss them all

68. 10/14 Trail Ride: Larry J

69. $10 includes dinner

70. Becky: no firearms on the grounds

71. Rick: we’d have to talk

72. Elder Doug: yard sale the first week of April for Special Needs Fishing Day

73. Jeania: why can’t BINGO be done here? Start out small

74. Chief Hatcher: it’s highly regulated; you have to buy equipment

75. Jeania: use cards, offer coffee/ snacks

76. Chief Hatcher: you can’t offer money that way, only prizes

77. John: are churches/ clubs regulated?

78. Chief Hatcher: it’s done under license and regulated

79. John: we could do a yard sale every weekend

80. Mark: and offer concessions

81. Rick: Mark & John to look into flea market; Larry into trailer ride

82. Committee Reports

83. Arts & Crafts: Susan

84. Nothing to report

85. Pauwau: Michelle

86. Program is ready for Council approval

87. Mark motioned to accept the program book & send to printer; John seconded

88. Jeania-yes, Susan-yes, John-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

89. Mark: are you buying t-shirts this year?

90. Michelle: we checked into prices; range $3-6/ shirt

91. Susan: Glenn C sent prices too

92. Glenn: 300 shirts would be about $1500

93. Benches being built 10/7

94. Susan

95. All RV spots taken

96. Vendors: 10 confirmed, 2 non-native

97. John: are we selling things during School Day?

98. Susan: problem is that vendors can’t open until the program is over; we can’t either

99. John: my thought was can we sell things or donated items?

100. John showed his woodburning crafts

101. Susan: you need to get certified

102. Susan: we should do it next year

103. Chief Hatcher: we have the county’s exemption for fees

104. Drum: Rick

105. Still planning on playing during School Day

106. 2nd Chiefs

107. Chief Hatcher: 2c Sievers has applied for another job which may keep her out of the state, but we need to get ID cards to people

108. Jeania: think she may have a problem with the laptop

109. Dalton: it could be a Windows 10 issue; John’s donated laptop was Win7

110. Chief Hatcher: 2c White apologized for not being here; he will be here a week ahead for pauwau

111. Chief

112. Chief Harris (Catawba); they wait on us to do things before they do it

113. Asked for their support on hunting & fishing licenses

114. Bills

115. To stop further group recognition: to keep 900 white people & 2 Native Americans from forming a group, allowing them to register as a minority company, compete for educational funds, etc…

116. Federally: considering taking it out of BIA & giving it to Congress

117. Criteria hasn’t changed & we want it too

118. Would have to show ancestry back to 1689 & doubt anyone of any race could

119. If anyone knows the Indians in their state, it should be the state & the federal government should listen to them

120. Congress only needs a majority vote

121. Work Day 10/7

122. All-Star BINGO in Garden City

123. Introduced Chief Thompkins of Chicora

124. Cemetery: stake 10ft from fence and 15ft from gate on trailer side

125. It looks like they’re taking land, not giving

126. Mark: they can’t settle the estate without signing off

127. Chief Hatcher: we could sit on it

128. Update on Tap-E-Ya Bernie

129. He can’t walk, but he can talk; paralyzed on the right side

130. Elder Doug: can we go get him for Pauwau?

131. He’s in Augusta

Mark motioned to close the meeting; John seconded.

Meeting adjourned 8:06 pm.

Respectfully submitted by Michelle Hatcher on 11/16/17 at 5:01 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
