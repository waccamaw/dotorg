---
layout: post
title: "March 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/03/08/march-open-meeting-summary.html
post_id: 5649672
custom_summary: false
summary: ""
date: 2014-03-07T19:00:00-0500
lastmod: 2014-03-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/03/07/march-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 3/7/2014 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM’s Dalton, Homer, Susan, Robert, and John present.

2. Service dedicated in the memory of Norma Jean

3. February minutes read

4. Add duration to 5- should be 2 months for Leave of Absence

5. Dalton motioned to accept; Susan seconded

6. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

7. Financial Report: Alan

8. General Fund

9. Deposits: $710.00 Debits: $1301.72  Balance: $14425.38

10. Building Fund

11. Deposits: $25.00 Debits: $0.00 Balance: $455.00

12. Old Business

13. Inactive Membership List

14. Dalton motioned to remove from ID# 408-467 on Monthly Report Query dated 3/6/14

15. Susan seconded

16. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

17. New Business

18. Committee Reports

19. Grants: Michelle

20. SCAC 3/15

21. Pauwau: 2nd Chief Cheryl

22. Next meeting on 3/12 at Nakato’s at 5pm

23. Additional vendor paperwork to include contest information

24. Working on budget

25. Lamar Advertising- posters/ signs around Conway/ Aynor

26. $280/ sign for 28 days leading up to Pauwau

27. Homer: will they take a tax letter instead of money?

28. 2nd Chief Cheryl: will ask

29. John: how much time do you need to give them?

30. 2nd Chief Cheryl: 10/6, pay by September

31. Susan: Could ask them for the vinyl signs once time is up

32. Arts & Crafts

33. CoC Scott: letter was sent to Carol Ann; no response

34. 2nd Chief Phil

35. Showed rank of feathers

36. Propose firekeeper, secretary, other offices currently without a feather are given a color code

37. Hand-carved items- bead on carved piece

38. Susan motioned to allow him to continue his work on feathers

39. Homer seconded

40. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

41. Gifted feathers to the tribe

42. Talking stick: challenge all CM’s to put their mark on it

43. Special Projects

44. Bathroom: Mark A

45. Still need to talk to man at GSW&S

46. Buildings & Grounds: John

47. Met 2/21: surveyed leveling the building

48. 5 people to level; looks like 3/4in. board removed could level building

49. New roof project: wait till after building is level

50. Price lists- 1 to build trusses, 1 with pre-built trusses

51. Mid-April project; still pricing

52. String trimmer: recommended to buy steel- $329

53. $28-32 for blades

54. Donnie’s fuel receipt: $16.10 Check 1565

55. Homer motioned; Susan seconded

56. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

57. Chief Hatcher

58. Prioritized projects to be in newsletter

59. Buildings & Grounds projects to be in newsletter

60. Either day before or day after solstice

61. Bank Account: Dalton

62. Propose moving account away from BB&T to CNB

63. Susan seconded

64. Alan: suggest not moving full account at once because of auto-drafts

65. Johnnie F: Suggest looking at other banks

66. CoC Scott to Dalton: look into other banks

67. Susan motioned to Table for now; Robert seconded

68. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

69. Alan: BB&T had a lot of service charges; ATM fees

70. 2nd Chief Cheryl: suggest against BoA

71. 2nd Chiefs

72. 2nd Chief Cheryl: new grandson

73. 2nd Chief Phil: ETV show with Chief Hatcher on 3/14 at 10am

74. Chief Hatcher

75. Earl Carter- ill lately

76. Tribal donation or individual

77. Skin on drum included in donations

78. Meteorites given to CM’s to put in their medicine bag

79. Letters to investors were sent to tribal council

80. Lawsuit- need money to file; roughly $150

81. Dalton motioned; Homer seconded

82. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

83. 2nd Chief Cheryl: have to file in district court because their business is outside SC

84. Res: J-HH-03-07-2014-001: Appointment of Council of Elders as Tribe’s Election Officials: 1st reading

85. Good parliamentarian: Steve O

86. Title search for TN land done: 2nd Chief Cheryl to look it over

87. Need to make it tax-exempt

88. CT land pending

89. Psychological Counselor for Veterans Administration would like to have a ceremony for PTSD veterans

90. Suggested fire circle ceremony

91. Susan motioned; Homer seconded

92. Homer-yes, John-yes, Susan-yes, Dalton-yes, Robert-yes, Scott-yes

93. Would like our veterans to take part

94. John: can Rolling Thunder come?

95. Chief Hatcher: yes, but can’t have too many because circle isn’t that big

96. Set up a special day for veterans

97. Elder Dan: could let Tim know & have local veterans attend

98. Homer: refreshments?

99. Chief Hatcher: sure

100. Mr. Turbeville- Socastee Heritage Festival: 2nd Chief Cheryl to get more information

101. Mr. Henry’s items in storage- he’s asked for 30 days

102. Council said yes without a formal vote

103. Articles for newsletter- send to Susan

104. Ronnie Floyd can get us free vinyl to put cover around circle

105. Pauwau 3/8 in Hardeeville

106. Build suk covered in bark- material at a place just outside Hardeeville

107. ETV adding Pauwau footage

108. John

109. When is the Tribal Roll Book open again? If applications were submitted before it was closed, are they still eligible?

110. Chief Hatcher: whenever you have applications, you can open it

111. Michelle: All applications have been voted on except a couple that came after the book closed

112. Are horses allowed on the tribal grounds?

113. Chief Hatcher: up to Council

114. Council: Basically, yes, provided it’s a trot

115. Volunteers and services being declined

116. Don’t decline services, you don’t know when you might need them again

117. Dalton: empty Council folders of 2013 material

Susan motioned to close the meeting; Homer seconded.

Meeting adjourned 8:07 pm.

Respectfully submitted by Michelle Hatcher on 3/11/14 at 7:35 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
