---
layout: post
title: "February 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/02/08/february-open-meeting-summary.html
post_id: 5649671
custom_summary: false
summary: ""
date: 2014-02-07T19:00:00-0500
lastmod: 2014-02-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/02/07/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/7/2014 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM’s Dalton, Homer, Susan, Robert, and John present.

2. January minutes read

3. 6(a)(iii)(3) should be Assistant, not co-chair

4. 6(a)(iii)(18) should be Assistant, not co-chair

5. Secretary’s Note- 2/15: 6(c)(vi) should be $190 down, not $890, confirmed with Mark A

6. Dalton motioned to accept; Homer seconded

7. Homer-yes, 2nd Chief Iris-yes, Robert-yes, John-yes, Dalton-yes, Scott-yes

8. Financial Report: Alan

9. General Fund

10. Deposits: $556.00 Debits: $440.90 Balance: $15017.10

11. Building Fund

12. Deposits: $280.00 Debits: $0.00 Balance: $430.00

13. Raffle Box- place Waccamaw Bucks in them for drawing on 2/15

14. CM Richia is taking a Leave of Absence

15. Old Business

16. Inactive Membership List

17. 6 called to update their information

18. Ray Hatcher had several extensions, wants another

19. Dalton motioned against giving another extension; Susan seconded

20. Dalton motioned to remove from ID# 247-438 on Monthly Report Query dated 2/6/14 excluding updated files

21. Homer seconded

22. Homer-yes, Susan-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes

23. New Business

24. Committee Reports

25. Grants: Michelle

26. SCAC 3/15

27. Genesis Foundation sent us $500

28. United Methodist Church

29. Buildings & Grounds: John

30. Flashing at window still leaking

31. Toilet has not leaked for two weeks

32. Inventory storage building to overbuying

33. Chief Hatcher suggested 4 days / year have work day/ tribal lunch

34. 2nd Chief Iris suggested adding Waccamaw Bucks to it

35. John suggested getting a list of people’s skillsets & capabilities

36. Chief Hatcher suggested putting it in the newsletter

37. Elder Doug: Donnie needs pitchfork, yard rake, weed eater for cemetery

38. John motioned limit of $75 for pitchfork & rake, price weed eater; Homer seconded

39. Homer-yes, Susan-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes

40. Working on project list

41. Push for April for first good work day

42. Dalton motioned to add Mark A, Glenn T, Rick H, Donnie H, Wayne T to voting members of committee

43. The nominees accepted

44. Homer-yes, Susan-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes

45. Pauwau: 2nd Chief Cheryl

46. Next meeting on 2/12 at Ryan’s

47. Secretary’s Note 2/11: Meeting delayed to 2/19

48. Dalton: Kickstarter (Susan: GoFundMe): Catawba are doing now

49. Do for both School Day & Pau Wau

50. Lindsey will help; better with videos

51. Dalton: Facebook has advertising posts

52. Approx. $30 to mention Pauwau every 2-3 months

53. 2nd Chief Cheryl: checking into non-profit billboard donations

54. 2nd Chief Iris: do as close to Pauwau as possible if they run for a limited time

55. Special Projects

56. Bathroom: Mark A

57. Residential is lower rate & tap in; tie all buildings in

58. Put by 2nd gate

59. Campground to 30amp

60. Waiver for pond

61. Suggest $55/ night to stay

62. Dalton suggested $39/ night

63. Use Pauwau drink money for 3 years to pay off

64. $10-15/ month donations by members will help

65. 2nd Chiefs

66. 2nd Chief Phil

67. New grandson

68. CoC Scott

69. Family Day

70. Pipe Ceremony

71. 12p fire; 1p eat

72. Robert organizing solstice in March

73. Chief Hatcher

74. TN land meeting

75. Title search: $250

76. Susan motioned; Homer seconded

77. Homer-yes, Susan-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes

78. Meeting with Vincent Sheheen & other Chiefs in state on 2/15

79. Drafted a letter; will circulate to Council & Chiefs

80. CMA

81. S611- out of committee; goes to full senate & has to be read 3 times

82. House version, senate version, meet in middle

83. Only stops new group recognition; doesn’t affect existing groups

84. Greg Richardson asked why we recognize groups/ non-Indians

85. Chief Hatcher sent information; CMA sent counter-information

86. Arts & Crafts

87. Spoke with Carol Ann

88. Want to pool artists’ items & purchase one from them to give to investors

89. Chief Hatcher wants certification

90. Susan suggested putting it back into the hands of Council

91. Dalton: going to get the local artist list and create a new committee if interest exists

92. Chief Hatcher: have to dissolve the old one first

93. Chief Hatcher: talker with her about problems with committee; give her an opportunity to fix it

94. Susan: voting members for committee weren’t done in January; conference calls are still be done

95. 2nd Chief Iris: had an in-depth conversation with her about things she should be doing & what was expected of her at Pauwau

96. Susan: new chair not elected in January

97. Chief Hatcher: CoC to contact her

Homer motioned to close the meeting; Susan seconded.

Meeting adjourned 8:28 pm.

Respectfully submitted by Michelle Hatcher on 3/4/14 at 3:27 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
