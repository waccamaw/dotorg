---
layout: post
title: "December 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/12/06/december-open-meeting-summary.html
post_id: 5649680
custom_summary: false
summary: ""
date: 2014-12-05T19:00:00-0500
lastmod: 2014-12-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/12/05/december-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 12/5/2014 held at the Tribal Office in Aynor, SC

1. CM’s Homer, Dalton, Susan present. Dalton chaired the meeting for CoC Scott. 2nd Chief Iris served as proxy for CM Rick and 2nd Chief Cheryl served as a proxy for CoC Scott.

2. October Minutes read

   1. 3.

Change 6h to year; should be more than one pauwau a year, not day

4. 2nd Chief Iris motioned to accept with change; Homer seconded

5. Homer-yes, Susan-abstain, John-yes, Iris (Rick)-yes,  Iris (Susan)-yes, Cheryl (Scott)-yes, Dalton-yes

6. Financial Report: Chief Hatcher

   1. 7.

General Fund

8. 1.

      1. 9.

Deposits: $4639.00  Debits: $1916.48   Balance: $9306.45

10. 1.

11. Building Fund

12. Deposits: $113.00 Debits: $19.90 Balance: $886.75

13. Steve/ Lori O to take over bookkeeping in 2015

14. 2nd Chief Iris: bookkeeping has to meet state/ federal requirements

15. Make sure the chart of accounts is accurate for audit

16. Online votes

   1. 17.

Heater: vote was stopped, but heating was handled

18. Old Business

   1. 19.

Tribal Logo & Trademark

20. On hold due to pauwau

21. New Business

22. Committee Reports

23. Arts & Crafts: Susan

24. Oct Meeting- would like to ask Council for quorum to be a majority to f the people present

25. Committee meets once a quarter; people not showing up or calling

26. Dalton: come back to Council & ask that they be replaced otherwise we run into situation like before

27. Susan: don’t want to beg people to be part of the committee

28. Chief Hatcher: you tie their hands; we need feathers & more done

29. 2nd Chief Cheryl: suggestion: if you have 3 people, call the 4th for a vote to meet quorum

30. Susan: that one person would have to be available though

31. Susan motioned to drop the quorum to a majority of the members present at A&C meetings; Cheryl seconded

32. John: can’t you make decisions and then put then vote out on the internet?

33. Iris: don’t agree with changing procedure to accommodate slack people

34. John: if you drop those 2 people, does quorum drop and do you have people

35. Iris: we do, but maybe not immediately

36. Homer: agree with Iris

37. Cheryl: majority could be 2 or even 1

38. John as a proxy, how do I vote- as he would? What if it’s not not known?

39. Dalton: on known items, as directed; on unknown, unsure

40. Susan: Council has 2nd Chiefs for proxies; committees doesn’t have it

41. 42.

Dalton: use another existing artist

43. 1.

      1. 1.

44. Susan: no chair elected; do in January

45. Susan withdrew current motion

46. John motioned to allow existing certified artists the ability to proxy for each other on the A&C committee; Susan seconded

47. a. Homer-yes, Susan-yes, John-yes, Iris (Rick)-yes,  Iris (Susan)-yes, Cheryl (Scott)-yes, Dalton-yes

48. Grants: Michelle

49. Looking at Duke Endowment Funds

50. Building & Grounds: John

51. Cemetery Fund: $370.05

52. Money spent on RV & electricity: $876.80

53. Still need wiring; each spot, not in series

54. Sold fencing for $114.80; will write check for building fund

55. Fundraiser for pauwau: $233.00- building fund

56. Revamping committee with meeting each month, working committee

57. Need to fix bathroom floor- plywood & tile?

58. Chief Hatcher: give John a limit of $500 to react to emergency situations/ 2nd Chief Iris seconded

59. Homer-yes, Susan-yes, John-yes, Iris (Rick)-yes,  Iris (Susan)-yes, Cheryl (Scott)-yes, Dalton-yes

60. Pauwau: 2nd Chief Cheryl

61. Called early on Saturday because of rain; good day on Sunday

62. Enough money in bank pre-pauwau to  pay for everything

63. Outbrief at Ryan’s 12/6 @ 2pm

64. Setup at gate wasn’t a bad idea

65. Jurying went well; no problem trying to get vendors to move items

66. 2nd Chief Iris: attendance?

67. Michelle: I have some numbers at the house; a better count was kept on Sat than Sun

68. Chief Hatcher: a dancer tossed $20 on the ground saying it wasn’t worth it

69. Michelle: dancers have said they prefer larger dollar amounts

70. 2nd Chief Iris: consensus between dancers/ Rodlyn was larger amounts with fewer number of draws

71. Homer: dancers complained they had to pay to dance

72. Susan: did they not see the sign?

73. 2nd Chief Cheryl: some gave it back; some didn’t it back

74. Homer: we shouldn’t give them any back

75. Chief Hatcher: do that & we won’t have any dancers

76. Homer: it’s a business for them & us

77. 2nd Chief Iris: most dancers we get are not professionals; they follow the drum

78. Sewer Pump Project: Chief Hatcher

79. Not sure how much is in the bank for that

80. Dalton suggested doing 4 Hog Heaven fundraisers

81. Drum: John

82. Rick says it needs to be tightened

83. Constitution: Dalton

84. First 3 articles are done

85. Preferably before Jan meeting, Dalton should have article 4 done & Cheryl should have article 5 done

86. Chief Hatcher: does it go to Council for approval?

87. Dalton: yes

88. Res. DH-12-05-2014-001 Waccamaw Bucks Elimination

89. Withdrawn because it’s date specific and requires 3 readings

90. Res DH12-05-2014-002:  Volunteer & Donor Rewards: 1st Reading

91. John: $20 cash

92. Dalton: $20 cash or in-kind

93. Chief Hatcher: membership fee is not a donation for this purpose

94. Dalton: need to lay it out in this in this resolution

95. John: though volunteer hours counted

96. Dalton: no, this is just gate passes

97. 2nd Chief Cheryl: can we include membership fees in this resolution?

98. Dalton: I’d rather we kept them separate

99. 2nd Chief Iris was wished a happy retirement

100. Chief Hatcher

101. Lower Cherokee recognition meeting probably in 3 weeks

102. CMA Office Seat to be filled by the Governor’s office

103. Thank you presentation & feather given to 2nd Chief Iris

104. Thanks given to John, Mark, & others for pw parking suggestions

105. SC Indian Development Council: nice gesture to make him an honorary member since he was instrumental in helping our kids get into schools

106. John reminded everyone about the solstice ceremony on 12/21

107. Homer took up donations for Donnie and Michelle

Homer motioned to close the meeting; Susan seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 1/7/15 at 11:45 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
