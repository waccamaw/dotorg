---
layout: post
title: "September 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/09/06/september-open-meeting-summary.html
post_id: 5649678
custom_summary: false
summary: ""
date: 2014-09-05T19:00:00-0500
lastmod: 2014-09-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/09/05/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 9/5/2014 held at the Tribal Office in Aynor, SC

1. CM’s Homer, Dalton, Susan, John, Robert, and Rick present. Dalton chaired the meeting for CoC Scott. 2nd Chief Phil served as proxy for CoC Scott

2. August Minutes read

3. Rick motioned to accept; Homer seconded

4. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

5. Financial Report: Alan

6. General Fund

7. Deposits: $1355.60  Debits: $2554.39   Balance: $11,645.86

8. Building Fund

9. Deposits: $65.00 Debits: $0.00 Balance: $1665.00

10. John T: some members would like line-by-line deduction list

11. Michelle: all checks written show up in minutes

12. Chief Hatcher give password for bank accounts to John T

13. Alan F: B&G items should come from the building fund

14. Old Business

15. Spousal Membership Application

16. Larry Jernigan

17. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

18. Tribal logo and trademark

19. Susan: still working on

20. Work Day items from 8/16

21. Robert is staying on Council as well as Firekeeper

22. Council to pre-read minutes before meeting

23. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

24. Committees: stick to topic of report; more items can be added at end of meeting for discussion

25. Agenda: shared with CoC, Dalton, Chief Hatcher, Susan in Drive

26. Others can get it as well, just ask

27. John-yes, Susan-yes, Dalton-yes, Scott-yes

28. Meetings are for Council business; Council controls the meeting

29. John-yes, Susan-yes, Dalton-yes, Scott-yes

30. Old Business List

31. Move resolutions to Drive; pay Michelle $100 to set up account and scan items

32. Chief Hatcher: $100 isn’t enough; pay by sheet

33. Johnnie F: not easy job; tedious; be considerate of time

34. 2nd Chief Phil: as state employee, what is a fair price?

35. Johnnie: unsure now

36. John T: keep track of time spent doing it & pay at end

37. 2nd Chief Phil: come up with a minimum wage

38. Chief Hatcher: $10/hour

39. 2nd Chief Phil motioned $10/hr instead of flat rate

40. Keep track of time; pay at end

41. Rick H: put a cap on it

42. John T motioned $10/hr for 2 days with a max of $160

43. Homer-yes, John-yes, Susan-yes, Robert-yes, Rick-yes, Dalton-abstain, Phil (Scott)-yes

44. Alternator: Pay Rabon’s

45. Dalton-yes, John-yes, Susan-yes, 2nd Chief Phil (Scott)-yes

46. Purchase Cool Seal: $795.15

47. Dalton-yes, John-yes, Susan-yes, 2nd Chief Phil (Scott)-yes

48. Policy Letter Changes: Susan

49. Camping on the Grounds: max 2 weeks, leave a week, return

50. Susan: leave time is based on other camping forms

51. If someone stays too long at once, you may have to evict them

52. Rick H: 7 day leave is too long

53. John-no, Homer-no, Susan-yes, Robert-no, Rick-no

54. Chief Hatcher: what if leave time was changed to 24hours?

55. John T: losing out on money if they are gone a week

56. 2nd Chief Cheryl: compromise to 3 days

57. John T: is it law?

58. Rick motioned to change leave time to 24 hours

59. John T: do they have to move camper out?

60. Rick: some grounds just ask you to change spots

61. Johnnie F: state park rules- beyond 2 week stay, Homestead Act kicks in; have to move all your belongings

62. John T motioned a 2 week stay, out for 24 hours

63. Susan motioned to stay 1 week, out 3 days, return for 1 week

64. Mark A: members’ grounds; suggest stay for 2 weeks, out for 24hours

65. Dalton motioned; Susan seconded to change leave time to 24 hours

66. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

67. Camping on Grounds: change to no non-prescription drugs allowed

68. Dalton motioned; Susan seconded

69. John T: what about people who use prescription drugs for recreational use?

70. Chief Hatcher: no control over

71. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

72. Use of tribal logo: no member is allowed direct control of the logo

73. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

74. New Business

75. Committee Reports

76. Arts & Crafts: Susan (from Neal)

77. Certifications to Phil W, Darlene W, Rick

78. Next meeting: Sunday after Oct. tribal meeting

79. Grants: Michelle

80. Looking at Housing Repair grants

81. Buildings & Grounds: John T

82. Thank you’s to volunteers

83. Working on vendor/ RV spots

84. Roof patched: needs 1-2 more coats of cool seal

85. All blinds, windows, kitchen cleaned

86. Storage shed inventoried by Lori O

87. Need to reseat boards in ceiling

88. Kitchen floor/ countertops to be improved through donations

89. Stain window seals, change windows

90. Need gutters to drain water off walls; cost approx. $371

91. Office trailer: still looking at doing something with it; start with walls

92. Eventually laminate office floor through donations

93. $474.90 in receipts for items tribe needed; would like reimbursement

94. RV spots: budgeted $1000+ $500 donation

95. Cost approx. $600

96. For power: $173/ seat optimum (15, 30, 50 amp)

97. Think 3 for now; add more later

98. $525 with wiring

99. Chief Hatcher: approve money now so it can be done before Pauwau

100. Dalton: first on receipts

101. Rick motioned; Robert seconded

102. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

103. Dalton: pay for electrical changes: $1300

104. 2nd Chief Phil motioned; Robert seconded

105. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

106. Susan: take receipts out of general fund; electrical changes to be taken from building fund; Robert seconded

107. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

108. Receipts: $474.90 Check 605 general fund

109. Electrical Changes: $1300 Check 1042 building fund

110. Cemetery Fund: $450.01

111. Wayne T: need weed killer- $152; $75 covered by Wayne

112. $77 from cemetery fund

113. Fence down from around pond; Wayne T wants posts & scrap wire in exchange for chemicals

114. Work Day 9/6

115. Pauwau: 2nd Chief Cheryl

116. Last meeting 8/13

117. Billboards ready

118. Vendor applications went out 9/1

119. Raffles: 50/50, beaded purse, craft

120. Johnnie F: will donate 2 pound cakes

121. Program Book complete & ready for Council approval

122. Cover done by Lindsey S

123. Ads: $1450

124. Camping during Pauwau, with Policy Letter changes, do we need to make changes to our form?

125. Susan: Policy Letter isn’t for Pauwau time

126. Funds: in-kind contributions- Wal-Mart, Sam’s, Costco, Food Lion

127. Eliminating Genealogy booth this year since the roll book is closed

128. Mark: what about people who need to sign the roll book?

129. Michelle different booth

130. Cheryl: Iris will have the roll book

131. Volunteers: certificates for 8 hours or more; less than that, you receive a letter

132. Meeting prior to Pauwau for heads of each section for better communication

133. River Talk: Susan

134. Cecil Chandler: Cheryl & Ronnie to be on Carolina Co Live

135. Website updated

136. PoP ordered and hotels arranged

137. Food: volunteers to cook

138. See Cheryl to volunteer

139. Sewer pump project: letter sent out

140. Drum: Rick: meeting 9/6

141. Have CD now

142. Do we need to swap them out or can we make copies?

143. Susan: not sure

144. Edisto will help us learn

145. 2nd Chief Phil: ask permission to sit with them & learn

146. Constitution: Dalton

147. Dalton motioned to remove tribal Council restrictions from this committee; Homer seconded

148. Mark: why does it have to be all Council members?

149. Dalton: it doesn’t

150. Voting members: Dalton, Susan, Cheryl, John, Scott, Mark, Michelle

151. Dalton motioned; Homer seconded

152. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

153. Resolution: DH-08-01-2014-001: Waccamaw Bucks Changes: 2nd Reading

154. John T: can non-members get Waccamaw Bucks & use it for application fee?

155. Susan: no

156. Chief Hatcher: cost money for ID cards, newsletters, stamps

157. Rick H: they only get a chance to gamble ($500 raffle)

158. John T: Wayne would have made $60 donation, but didn’t because of gate fees

159. Chief Hatcher: Waccamaw Bucks as a requirement for donation makes it no longer a donation

160. Rick H: seems like we’re more interested in making money off people in the tribe

161. Chief Hatcher: old days, he bought all paper, ink, stamps, etc… it adds up

162. Chief Hatcher: okay with adding a gate pass & doing away with the two free ones

163. Susan: people work that you may never see

164. Susan: they pay for people’s membership fees & new ID cards

165. We don’t have a renewal fee on ID cards

166. Mark A: penalizes people who can’t come out & work

167. Chief Hatcher: membership comes with privileges

168. Receipts

169. Donnie: lawn mower: $70.47 Check 606

170. Fuel: $74.36 Check 607

171. Homer motioned; Rick seconded to pay both

172. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

173. John T: Pauwau: T-shirts- cost $2.50 each to make

174. 2nd Chiefs

175. Cheryl: Life Recovery with sweat lodge in vicinity

176. Pauwau: need display dimensions

177. Chief Hatcher introduced Ed Johnson (former Council member) and Chief Lewis (FL)

178. Chief Lewis

179. Seminoles are Waccamaw; escaped slavery

180. Have family in High Hill, Mt Olive, Holly Hill cemeteries

181. Will volunteer just because we’re family

182. Bring tribes together to help prevent diabetes, help become a self-sustaining entity

183. More people means stronger tribe

184. Veterans Program: Dori A looking into

185. In court since 1974 over Disney being on their land

186. Want to form unity between Chiefs, create food growth system

187. Want to establish bank, hospital, electrical grid

188. Money is easy; coming together is more difficult

189. Chief Hatcher: wrapped up 30-day item on project; timeline sent to Council

190. Sheila H: Ride to Reverse Diabetes with Dennis Banks: 9/23-24

191. 9/20: Gathering of all religions in DC with People of the Earth

192. 9/25: Petersburg Prison Pauwau: requires form

193. Pauwau: Program Book approval: 2nd Chief Phil motioned; Homer seconded

194. Homer-yes, John-yes, Susan-no, Robert-yes, Rick-yes, Dalton-yes, 2nd Chief Phil (Scott)-yes

195. Homer: Will Cemetery fund include both cemeteries?

196. Wayne T: yes

197. Homer: Will program books be sold at the gate?

198. Cheryl: think they should be; discuss at meeting

199. Mark A: at drink booth too

200. Michelle: money must be kept separately for accounting

201. John T: solstice 9/21

202. Rick: formation of Waccamaw Warriors

203. Open to members

204. Temp. Chair: Rick, John T, Mark A; election in 2015

205. Make additions to grounds, fund raisers, education

206. John T: provide encouragement for more people to become active

207. Rick: networking with other tribes

208. John T apologized for sounding short in emails

Homer motioned to close the meeting; Susan seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 9/28/14 at 4:15 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
