---
layout: post
title: "August 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/08/02/august-open-meeting-summary.html
post_id: 5649677
custom_summary: false
summary: ""
date: 2014-08-01T19:00:00-0500
lastmod: 2014-08-01T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/08/01/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 8/1/2014 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM’s Homer, Dalton, Susan, John, and Rick present.

2. July Minutes read

3. Dalton motioned to accept; Homer seconded

4. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

5. Financial Report: Alan

6. General Fund

7. Deposits: $1465.00  Debits: $1652.52   Balance: $12,844.65

8. Error on TN trip math: not $902, was $949.40

9. Building Fund

10. Deposits: $525.00 Debits: $0.00 Balance: $1600.00

11. Online Votes

12. 7/22 Tractor Parts

13. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

14. Old Business

15. Inactive Membership List

16. Dalton motioned to remove ID’s [#040](https://www.waccamaw.org/updates/hashtags/040) on Monthly Report Query dated 7/11/2014

17. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

18. Elder’s Decision on Elections

19. Candidate qualifications:

20. Will they go in effect this year?

21. Dalton: 1st paragraph: need to spell out who decides who makes contributions

22. Chief Hatcher/ Dalton: suggest Council of Elders

23. 2nd Chief Iris: 2nd Paragraph: our resolution holds felons can hold office after 5 years

24. Dalton: who decides pardon?

25. Scott: judge; to put you back in good standing

26. John: need to define offense

27. John: 3rd Paragraph: should person be appointed if not member for 2 years?

28. Chief Hatcher: no

29. Dalton: However, Elders can’t infringe on Chief’s appointment powers

30. Should paragraph be eliminated?

31. Someone who just turned 18 not really active until 18, so couldn’t run

32. Eliminate

33. John: 4th Paragraph: could we grandfather current members?

34. If the people want a member back in office, they’ll vote that way

35. Scott: Eliminate paragraph

36. Official Ballot

37. Chief: completely revamp

38. Revisit over pre-stamped envelopes

39. Intention of Candidacy

40. Eliminates letter of intent

41. Susan/ Scott: only basic information

42. Not for newsletter use (those are optional)

43. Dalton: 5th paragraph: need to specify that it be a designated representative of Election Committee

44. Susan: Should all Elders have to agree that a person can run?

45. Designated representative will also sign letter of intention

46. Susan: how will this affect this year’s election?

47. Dalton: shouldn’t affect this year

48. Susan: Clarify: this won’t happen until next election

49. Scott/ Dalton: yes

50. John: is Aug 15 enough time?

51. Chief Hatcher: yes

52. Election Commission

53. Dalton: section: Who Can Run For Office- needs to be same as candidacy page

54. Chief Hatcher: also need to add “in good standing”

55. Elder Doug: section: Who serves on election commission

56. Should also say “women”

57. Chief Hatcher/ Scott: strike that line completely

58. Dalton: Section: What About a tie breaker

59. Change to “Parliamentarian breaks all ties”

60. John suggested striking section completely

61. Dalton: Section: Are there disqualifications?

62. Change committed to convicted

63. Add: pardon by judge

64. Dalton: Section: Who can vote

65. Strike “core”

66. Rick: what if someone resigns or has a leave of absence?

67. Scott: LoA not same thing

68. Rick: what if I need to be gone 6 months; should I resign?

69. Scott: between you and your oath of office

70. Chief: add to end: as long as they comply to rules contained herein

71. Section: How To Vote

72. Strike “voting booth”- too late to do after Pauwau

73. Dalton: or change to: “ballot box in office”

74. Section: When do ballots need to be received

75. Change date of counting or postmark date

76. Susan: which Elders are going to run booth at Pauwau

77. 2nd Chief Iris: don’t think it should be in conjunction with Pauwau

78. Alan: let them bring ballot to Pauwau

79. John motioned to keep it as a mail ballot & eliminate Pauwau ballot; Susan seconded

80. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

81. Chief to rework this area

82. Send ballots to Parliamentarian?

83. Trademark

84. Susan: still working on it

85. New Business

86. Committee Reports

87. Arts & Crafts: Neal

88. Elected officers; Neal to chair, Susan to co-chair, Sonya as secretary

89. Rick Hudnall: approved certification

90. Meetings are quarterly & open

91. Little late for tribal booth at Pauwau this year

92. Would like for committee to have booth next year

93. 2nd Chief Iris donated gourd for museum

94. Would like tribal art to have tribal logo tag

95. Need to work on nature trail

96. Will start art classes after Pauwau

97. Susan will hold feather classes

98. Certifications: Darlene, 2nd Chief Phil, Chief Hatcher, Rick (pending completed application- needs to attach pictures)

99. Chief Hatcher: would like pool of tribal items to buy from for dignitaries

100. Lots of people without feathers; needs to be done

101. Neal: would like each artist to do 2-3

102. 2 museums to display our art

103. Grants: Michelle

104. Still looking into Housing Repair grants

105. Buildings & Grounds: John

106. Cemetery fund: $410

107. Lawnmower too wide; looking at small one

108. Crucial projects: office

109. Cool seal: $716.32 to Glen Turner check 598

110. John motioned; Rick seconded

111. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

112. RV project: Chris Hatcher to bring backhoe to remove trees

113. Idea of Purchasing a new building: $45k

114. Idea to make money: sell food at Pauwau

115. Have cooks & servers if Pauwau committee approves

116. Suggest Council Work Day 3rd Sat. of month; Susan seconded

117. Need 4CM’s there

118. Put proposals online within 5 days

119. Homer-yes, John-yes, Susan-yes, Rick-yes, Dalton-yes, Scott-yes

120. First one: 8/16/2014 from 2-6pm

121. Need a complaint forum: embrace criticism

122. Scott: let me know if you want to be on agenda

123. Pauwau: Susan

124. Drafts back on billboards

125. On schedule with timeline

126. Flyers here; tri-folds next

127. Last day for ads and articles for program book: 8/15/2014

128. Chief Hatcher: why cutoff date of 8/15?

129. Susan/ Michelle: to get it in book, to/ from printer, to Council for approval

130. Doing a couple River Talk interviews

131. Johnnie F: send letter to Public Affairs company for non-profits

132. Pump Project: Chief Hatcher

133. Commitment letters to go out with newsletter

134. Can’t sign letter with GSW&S: lien on land is against the law

135. $4630: have to pay upfront or scrap project

136. Drum: Rick

137. Tried to get in touch with Andy to purchase cd’s

138. 8/23: McKissick Museum: 10a-4pm

139. Interested in learning, let him know

140. Living Village with tipis

141. Store to sell items

142. Community group to help with recognition/ help from others

143. CoC Scott: problem with Dalton’s seat: ran in wrong year

144. Elders suggested Dalton resign, Council accept him coming back & reinstate

145. Parl. Steve’s email read by Chief Hatcher

146. Executive Order: reappointed Dalton to seat

147. Resolution: DH-08-01-2014-001: Waccamaw Bucks Changes: 1st Reading

148. Chief Hatcher: example: committee heads have to turn list in

149. Michelle: not necessarily; it can be done individually, but still has to be signed off on by committee heads

150. Fuel Receipt: $106.26 Check 599

151. 2nd Chief Iris

152. 316 voting members: 86 Noncore; 230 Core; 72.5%

153. Chief Hatcher

154. NAAC Meeting: 7/18

155. Was informed by Chief Chavis that a closed door meeting was held at CMA

156. All groups now have until certain date to become recognized or fade out

157. Not the way it was originally submitted; want grandfather clause

158. Pauwau: Santee: 9/20

159. BIA Lower Nations: 9/27

160. Youth Group: Hayes: play games that help children learn culture

161. Membership Agreement for Associate Members rewritten

162. To email Council

163. TN Trip math error: $50.60 received

164. Name given to Johnnie F: Sister of the Big Waters

165. CoC Scott: Jessica wants to get married on grounds in private ceremony

Susan motioned to close the meeting; Dalton seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 8/27/14 at 2:30 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
