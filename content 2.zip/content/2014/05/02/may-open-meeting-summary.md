---
layout: post
title: "May 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/05/03/may-open-meeting-summary.html
post_id: 5649674
custom_summary: false
summary: ""
date: 2014-05-02T19:00:00-0500
lastmod: 2014-05-02T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/05/02/may-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 5/2/2014 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM’s Dalton, Homer, and John present.

2. CoC Scott read email from CM Richia stating her resignation; nominated Rick Hudnall to spot

3. Rick accepted nomination and was sworn-in by CoC Scott

4. April Minutes read.

5. Dalton motioned to accept; Homer seconded

6. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

7. Financial Report: Michelle (from Alan’s email)

8. General Fund

9. Deposits: $0.00 Debits: $1778.37  Balance: $12,440.76

10. Building Fund

11. Deposits: $545.00 Debits: $0.00 Balance: $1025.00

12. HCSB

13. Deposits: $1075.00 Debits: $209.60 Balance: $865.40

14. Money still being moved from BB&T to HCSB

15. Online Votes

16. Filing Fee for Lawsuit

17. Homer-yes, Dalton-yes, John-yes, Scott-yes

18. Old Business

19. Arts & Crafts

20. Letter sent to Carol Ann read in meeting thanking her for her service

21. No response

22. Dalton talked to Susan; wanted Council to certify Chief Hatcher

23. Homer: did her go through motions once?

24. Dalton: he did in past

25. John seconded

26. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

27. Has anyone else in the meeting lost certification (done paperwork before, etc…)?

28. Dalton motioned to reinstate Neal’s certification

29. Homer & Rick seconded

30. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

31. Neal will still need to get with A&C to get paperwork done

32. Inactive Membership List

33. Dalton motioned to remove from ID [#172](https://www.waccamaw.org/updates/hashtags/172)- 260 on Monthly Report Query dated 4/30/14

34. Homer seconded

35. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

36. John motioned to give applications from last month (Ammons & Turner) 1 month extension

37. Rick seconded

38. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

39. New Business

40. Committee Reports

41. Grants: Michelle

42. Still waiting on report from SCAC

43. Buildings & Grounds: John

44. Upcoming projects: drain pipe

45. Need wheelbarrows, shovels

46. Mark A: call YouLoco & have them mark for lines

47. Spring trimmer purchased; credit rest towards John’s Waccamaw Bucks ($33)

48. Richard Turner: trailer receipt: $132.59 Check 1032

49. Dalton motioned; Rick seconded

50. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

51. Cemetery: Sons of Confederate Veterans could help take care of it

52. Elder Doug: tombstones need to be acid washed

53. Proposal: Murray mower $750: $350 by Richard Turner; donations for rest

54. Keep at Richard’s place since it would be just for cemetery

55. John put $150 towards it

56. Propose giving Richard 8 years membership fees towards it

57. Other pending

58. Roofing

59. Other building: siding coming off- take off or do something with it

60. Needs power

61. Tractor tire: Donnie said used one is good

62. Need correct size

63. Electrical outlets around dance circle: move out 5 feet

64. Pauwau: Michelle

65. John: ad sold

66. Asked Council to confirm Lindsey as a voting member (Iris stepped down)

67. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

68. Membership types explained to John

69. John motioned to open TRB to give Larry Jernigan a spousal application & Sandra Hatcher (Wayne Turner’s wife) & Mark Ammon’s wife

70. Dalton seconded

71. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

72. Send to tribal PO Box or to Michelle by email

73. Fuel Receipt: $66.17 Check 1033

74. Homer motioned; John seconded

75. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

76. Glasses Repair receipt $123.00 Check 1034

77. John motioned; Homer seconded

78. Glasses broke while bush hogging with tractor

79. Res J-HH-03-07-1014-001: Appointment of Council of Elders as Tribe’s Election Officials: 3rd Reading

80. Will replace SB-10-01-2010-001

81. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

82. Secretary Budget Approval

83. Homer motioned; John seconded

84. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

85. Membership Updates

86. Dalton motioned to give them 1 month; John seconded

87. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

88. John A: what about his son’s application?

89. Michelle: I haven’t seen it

90. We’ll look into it

91. Elder Doug: we need to look into getting a PR person

92. Heritage Festival went well; lots of talent

93. Need more people to hear about it

94. John A: Prison Program: great meeting with group at Allendale

95. Need better facilitation at Bennettsville

96. If you want to help, let him know- will train you

97. John T: if they made A&C, could we sell them?

98. John A: will have to ask

99. John T: Events other than Pauwau

100. Have been trying to find people to do classes

101. Quarterly; a few hours on a Saturday

102. Dalton suggested Nancy Basket

103. Mark suggested Bill & Suzie Gingris

104. John A: crafts

105. Mark A: Cherokee are willing to help us get set up like they are

John motioned to close the meeting; Rick seconded.

Meeting adjourned 9:00 pm.

Respectfully submitted by Michelle Hatcher on 5/20/14 at 12:59 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
