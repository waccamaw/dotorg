---
layout: post
title: "January 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/01/11/january-open-meeting-summary.html
post_id: 5649670
custom_summary: false
summary: ""
date: 2014-01-10T19:00:00-0500
lastmod: 2014-01-10T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/01/10/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 1/10/2014 held at the Tribal Office in Aynor, SC*

1. CoC Scott, CM’s Dalton, Homer, Robert, and John present. 2nd Chief Iris served as proxy for CM Susan.

2. December minutes read

3. Dalton motioned to accept; Homer seconded

4. John-yes, 2nd Chief Iris-yes, Homer-yes, Dalton-yes, Robert-yes, Scott-yes

5. Financial Report: Alan

6. General Fund

7. Deposits: $1470.21 Debits: $1205.28 Balance: $14892.00

8. Building Fund

9. Deposits: $150.00 Debits: $1145.87 Balance: $150.00

10. Pauwau

11. Expenses: $12729.05 Income: $21655.17

12. Chief Hatcher: still due $7000 from ad sale

13. 2nd Chief Iris: best year we have had; kudos to PW Committee & all who participated

14. Online Votes

15. Heaters for John Cox

16. Homer-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes; Susan voted yes online

17. Prison Program Fund

18. Homer-yes, John-yes, Robert-yes, Dalton-yes, Scott-yes; Susan voted yes online

19. Old Business

20. Inactive Membership List

21. Dalton & 2nd Chief Iris: 11 people updated their file

22. John: what does “extended” mean?

23. 2nd Chief Iris: number of months membership was  extended

24. RTNS column shows number of times mail has come back

25. 2nd Chief Cheryl: can I speak on behalf of someone on the list?

26. He’s in the Jail Diversion Program & hasn’t had opportunity to do a whole lot with receiving mail unless sent to prison

27. 2nd Chief Iris: didn’t have that address

28. Dalton: we’re not voting on him tonight anyway

29. Scott: his doesn’t expire until 2016

30. Chief Hatcher explained federal recognition requires being able to contact all our members

31. Dalton motioned to remove 385- 020 on Monthly Report Query dated 1/10/14

32. Homer seconded

33. John-yes, 2nd Chief Iris-yes, Homer-yes, Dalton-yes, Robert-yes, Scott-yes

34. New Business

35. Committee Reports

36. Buildings & Grounds: John

37. Would like to plan on what to do for work days & make list

38. Post on our sites for people’s interest

39. Grants: Dalton (for Michelle)

40. Looking into Grants.Gov site

41. Jeania working on Hospitality Grant

42. Pauwau: 2nd Chief Cheryl

43. Met Wednesday (1/8)

44. 2nd Chief Cheryl nominated as Chairperson

45. CM Susan nominated as co-Chair

46. Reviewed policy letter & couple things to add in to assist with problems we’ve had vendors having numerous unidentified helpers

47. Send emails to other vendors that may be interested in vending at this year’s Pauwau to increase variety & quality

48. 2nd Chief Iris: where are these vendors going to come from?

49. Found all she knows to find

50. 2nd Chief Cheryl: trying to come up with ways

51. Could use more people

52. John: I go to other festivals; need something we can give vendors about our Pauwau

53. 2nd Chief Cheryl: need to make sure they are Native American vendors

54. Hoping this will help lead to better quality & be as true to culture as possible

55. Vendors

56. Developing policy & procedures to jury vendor booths

57. Set up process in advance

58. Will have to work with security

59. Need other committees involved & before Pauwau for communication

60. Best Vendor Contest

61. Debbie said she would get a blue ribbon from the craft store

62. Susan suggested Lindsey take pictures to help us jury

63. Hope is to motivate vendors

64. Reworking letter in vendor application

65. Communication between different areas of Pauwau (gate, grounds, camping, etc)

66. Pre-PW meeting with heads to get everyone on same page

67. Gate: Lori O

68. Explain process on why we do wristbands the way we do: Grants

69. Making signs at fire circle more visible

70. Add gate cost to camping fee to eliminate problem of campers not paying gate fee

71. 4 color wristbands; stickers for little boys & girls

72. 2nd Chief Iris: this year (2013) , we didn’t get an attendance count & we really need it

73. How will it help this year?

74. 2nd Chief Cheryl: imperative they are given out correctly for count

75. Wristbands: adults, students, veterans, seniors

76. Subtract number remaining from initial count

77. Can see where most money is coming from & identify target market

78. Start working on budget

79. Start selling ads

80. John: how many coloring books did we put out there- 200 or 300?

81. 2nd Chief Cheryl & Dalton: 300

82. Question to Alan: how many program books were sold?

83. Alan take cost on sheet/ 5

84. Dalton: books & videos were combines though

85. Dalton: how many were printed?

86. 2nd Chief Cheryl: 400

87. John: any way we can make a sign showing the places who support us?

88. John: sold 1 ad; think could sell more if business know their name will be seen twice

89. 2nd Chief Cheryl: put Sponsor Board at back fence

90. 2nd Chief Cheryl: would you charge more for that?

91. John: no

92. Johnnie F: could entice more advertisers

93. Mark A: T-shirts with ads on them

94. Put logo on front; advertisers on back

95. Usually 16 business card size & 1 large ad

96. Steve: willing to help with that

97. Chief Hatcher: problem with shirts is people want a date on them

98. If you don’t sell them all, you’re stuck with them

99. Could buy printing machine and do them on the spot

100. Confirm 2014 Pauwau Committee voting members: 2nd Chief Cheryl, Susan, Michelle, Debbie, CoC Scott, Georgia, 2nd Chief Iris

101. Dalton motioned; Homer seconded

102. John-yes, 2nd Chief Iris-yes, Homer-yes, Dalton-yes, Robert-yes, Scott-yes

103. Confirm 2nd Cheryl & Susan as Chair and co-Chair, respectively

104. Dalton motioned; Homer seconded

105. John-yes, 2nd Chief Iris-yes, Homer-yes, Dalton-yes, Robert-yes, Scott-yes

106. CoC Scott: asked Council to come up with 3 ideas to improve tribal grounds so they can be prioritized (list next month)

107. CoC Scott’s ideas

108. With Susan: Adjust vendor spaces to 1 size

109. Chief Hatcher: move spaces back 10 ft

110. CoC Scott: we took out 1 spot at circle entrance

111. Chief Hatcher: don’t need to move them then; just line them up

112. Chief Hatcher: water & electric would have to be moved too; cheaper just to line them up

113. Old office: would like to get water & electric to it so we can use it when we need it

114. New office: better roof- not just patch

115. John’s ideas

116. Beautification: flowers, bushes, trees

117. Outdoor shed: rebuild storage building

118. Old office: electric, inspect for structural damage

119. If rot underneath, may not be worth salvaging

120. Dalton’s ideas

121. More RV spots with electric & water

122. Mark A: could put 15 around pond side

123. John: curious, can we cut down trees to make space?

124. Answer: yes

125. Benches around circle

126. Improve electric so they aren’t constantly blowing out

127. Door off-kilter

128. Chief Hatcher: building needs to be leveled

129. Homer’s ideas

130. At Pauwau meeting, suggestion was made for a gate building

131. How much would it cost to put a fence around the pond or cover it?

132. Scott: last time, a fence was donated

133. 2nd Chief Cheryl: fence could entice climbing

134. Mark A: Bathroom Project update

135. Chris Hatcher company supplying toilets, sinks, showers

136. We have to come up with building; suggest 12x24

137. Met with GSW&S today; sewer tap is across the road

138. Trying to get pump & pump box

139. Run campground & bathhouse into that

140. Funding & donations: don’t meet grant qualifications

141. Pay for tap: $3630: $890 down, $29/month x 20 years

142. Chief Hatcher: do they charge interest?

143. Mark A: yes

144. Suggestion: donate drink profits x 3 years to it

145. Chief Hatcher: will they finance in tribe’s name or just individual?

146. Mark A: tribe

147. All labor donated

148. Chief Hatcher: could old office be turned into bathhouse?

149. Mark A: yes, but would like to put siding on it

150. Chief Hatcher: could be cheaper

151. Found a building in Clover for $200, but it was 12x20

152. Johnnie F: been to different fairs/ festivals that have buildings

153. Why not ask them to donate one & tell them we’ll leave their name on it (free advertising)?

154. Mark A: suggestion on size

155. 3 toilets on each side with handicap access

156. 2 showers on each side

157. 3 sinks on each side

158. Plumbing to tie in

159. CoC Scott: Waccamaw Family Day: 2/15

160. Need to people to cook: Johnnie & Alan F; Monica & Paul

161. Alan: shrimp is $6/lb if bought now- Low Country Boil & Hushpuppies

162. Scott: designated for $200

163. People are to bring paper products & drinks

164. Georgia: Can make cornbread; volunteer to help

165. Johnnie F: Someone needs to make cakes

166. Jeania: how many cakes? Volunteer

167. Homer: what time?

168. Scott: not sure; will work on it

169. 2nd Chief Iris: usually fire ceremony at 12; food at 1

170. Johnnie F: any way to get a head count this year?

171. Scott: hard to RSVP

172. Johnnie F: put on sites for interest

173. Bring games for kids

174. Scott & Homer thanked people for volunteering

175. 2nd Chief Cheryl

176. Horry Independent article on Jail Diversion Program

177. Title: New Jail Program Offers Young Men Second Chance

178. Program created in 2010 & has seen 2-3% drop in inmate population

179. Accepted, excited, honored to work there (J Reuben Long)

180. Read an excerpt from the article

181. Chief Hatcher

182. Calls

183. Call from Libby Mitchell to ask for donations to help with Elder John Mitchell’s medications

184. Former CM Jeanie Wright’s mother is in hospital in Florence; Jeanie needs assistance with gas money

185. Propose donations are split between the two families

186. Raffle Box: Waccamaw Bucks to enter

187. Write your name & phone number on back

188. Drawing on Family Day; winner gets $500

189. People put initials on tape on box so others know it hasn’t been opened

190. Bamboo container with wax top with ashes from Pauwau sacred fire

191. Gave one to: Chief of Chicora (participated in ceremony), Council, 2nd Chiefs, 2013 PW Chairperson

192. Can make more

193. Problem with it: Public Law 101.644 (able to call art Indian)

194. We break it down further so people can call it Waccamaw

195. Chief Hatcher needs art certification for arrows & beaver tail knives

196. Chief Hatcher: who is on the Arts & Crafts committee?

197. Scott & Dalton: Susan

198. Chief Hatcher: I see we dropped Arts & Crafts from monthly agenda

199. Scott: they meet quarterly

200. Chief Hatcher: we need to tighten things up

201. Every member is supposed to get a feather

202. Every Council member is supposed to wear a Council feather

203. Feathers come from Arts & Crafts committee

204. Homer: and names

205. Ralph Oxendine in bad health; tribe is newly recognized

206. Emergency Elder meeting recently concerning investors

207. Read letter from Elders to Chief Hatcher

208. Meeting in NY: would like Council to assist with funds

209. Dalton motioned to allow up to $1300 for meeting expenses; Homer seconded

210. John-yes, 2nd Chief Iris-yes, Homer-yes, Dalton-yes, Robert-yes, Scott-yes

211. Trip to TN: land still pending, would like to make tax-exempt

212. Suggest: put RV park on there

213. 65 acres of land donated in CT

214. Chicora

215. Thanked us for allowing them to come

216. Chief Hatcher: sure Pauwau Committee would let you come to those meetings

217. 2nd Chief Cheryl: meet 1st Wed of month at Ryan’s or Shoney’s

218. Dalton: 2nd Wed; Shoney’s isn’t open past 4

Homer motioned to close the meeting; Robert seconded.

Meeting adjourned 8:35 pm.

*Minutes pulled from audio file.

Respectfully submitted by Michelle Hatcher on 2/9/13 at 2:22 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
