---
layout: post
title: "October 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/10/04/october-open-meeting-summary.html
post_id: 5649679
custom_summary: false
summary: ""
date: 2014-10-03T19:00:00-0500
lastmod: 2014-10-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/10/03/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/3/2014 held at the Tribal Office in Aynor, SC

1. CM’s John, Rick, Dalton, and Scott present. 2nd Chief Iris served as proxy for Susan.

2. Sept Minutes read

3. Rick motioned to accept; John seconded

4. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott- abstain

5. Financial Report: not available due to pc/ password problems

6. Online Votes

7. 9/10 Use previous elections’ ballot format

8. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

9. 9/17 Accept Neal Richard’s resignation as A&C Chair

10. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

11. Old Business

12. Tribal Logo & Trademark Status

13. 2nd Chief Iris: Susan says it’s still being worked on

14. New Business

15. Committee Reports

16. Arts & Crafts

17. Meeting here 10/5 @ 2pm to elect new chairperson

18. Looking for a place to sell in MS

19. Personal sales- not fundraising

20. Neal found a museum in MB

21. Grants: Michelle

22. Starting to look at endowment funds

23. Building & Grounds: John

24. Thank you to volunteers

25. Work day 9/22 on RV spots

26. Work Day 10/4 on RV spots- inspection upcoming; cleanup

27. Roof cool sealed x4; old office coated

28. Selling pond scrap metal to pay for chemicals to treat the pond

29. Old office on hold until after Pauwau

30. Cemetery fund: $370.02

31. Wayne T taking care of all cemeteries

32. Still looking for donations to keep minimum balance of $350

33. Propose additional work day- 3rd Sat. of month- for cemetery upkeep; will coincide with Council work day

34. People aren’t thanked enough; presented Rick with a necklace

35. Rick: Is there a flood zone on the circle?

36. John: majority of property is in flood zone

37. Rick: What is the tribe’s liability on personal property bought for tribal business?

38. If it broke, does the tribe fix it?

39. 2nd Chief Iris: It depends on how it broke & what it was

40. John: We’re not to code at the circle

41. 2nd Chief Iris: we’ve brought loads of dirt in

42. Pauwau: 2nd Chief Cheryl

43. Vendors: 10 now

44. Payouts for Pauwau in advance in case of rain

45. Insurance, pest control, drum, dance raffle, Head man/ lady. Demonstrators, hay, hotel, program books, dumpsters, port-o-potties

46. Scott: bank account frozen until after Pauwau

47. Chief Anthony Davidson- RV Spot, cooking for volunteers

48. Chief Locklear- RV spot

49. Doug: What is the amps on vendor spots?

50. Scott/ Chery: same as last year; 15

51. Dance Raffle: 10/8 draws Sat/ Sun respectively; $300 last draw both days

52. Setup: GoldenEagle to help; 10/29 9am

53. Need hardwood for fire

54. Need volunteers

55. John: Research on cooking- permit required?

56. 2nd Chief Iris: already negotiated between Chief Hatcher & DHEC

57. Mark’s friend can cook

58. 2nd Chief Iris: Waccamaw Warriors are not an official tribal entity; pay for their spot

59. Then donate or keep their funds

60. John: tribe is getting the money; you want the Pauwau committee to look good

61. 2nd Chief Iris: If he donates all the money, he gets a free spot. Donate just a % to an outside entity, pay for a spot, donate to warriors, pay the fee. If warriors are going to donate, that’s fine.

62. John: If he donates to the tribe to the building fund

63. 2nd Chief Cheryl: Warriors doing fundraiser for B&G with no fee

64. John: Can we sell peanuts & popcorn?

65. 2nd Chief Cheryl: yes

66. 2nd Chief Iris: Native American food

67. Mark: frybread

68. John: T-shirts: are we doing them or not? (because he can)

69. 2nd Chief Cheryl: you’re bringing up committee items during a Tribal Council meeting

70. Billboards were paid for by the Hog Heaven fundraiser

71. Dalton motioned to freeze the bank account with exception of regular monthly bills until after the Pauwau; Scott seconded

72. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

73. Homer: Who’s going to be Firekeeper?

74. Scott: Earl, Robert, John C

75. 2nd Chief Cheryl: Amy Dixon is looking to book rooms; wants to sell ads in newsletter

76. Sewer Pump Project: Mark

77. Waiting on money

78. Drum: Rick

79. Nothing new

80. Constitution: Dalton

81. Dalton was elected chair

82. We decided to have quarterly face-to-face meetings & do the rest online

83. Meeting 10/22 at Ryan’s @ 6pm; open to all

84. Want to be completely done by end of 2015

85. Resolution: DH-08-01-2014-001: Waccamaw Bucks Changes

86. Dalton: withdrawing it

87. Seriously considering making Waccamaw Bucks go away altogether

88. Will let Scott handle rewriting volunteer work for free gate passes

89. Fuel Receipts: $65.25 Check 611

90. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

91. Tractor: $40 Check 612

92. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

93. 2nd Chief Iris

94. Retiring 12/31/2014

95. Asking Council permission to mentor Jeania and turn the database over to her upon retirement

96. Database built by Iris personally

97. Dalton: It can be recreated from ASCII file

98. Motioned to accept Jeania as the new filekeeper

99. Rick: does she want it?

100. Jeania: yes

101. John: does her running for Council affect it?

102. 2nd Chief Iris: you have to approve her because of privacy

103. John-yes, 2nd Chief Iris (Susan)-yes, Rick-yes, Dalton-yes, Scott-yes

104. 2nd Chief Cheryl: Is there anything she needs to sign because of privacy?

105. 2nd Chief Iris: think it’s a good idea; not done before because it was mine.

106. 2nd Chief Cheryl to write the policy

107. Length of Stay on the Grounds

108. Permission for Mark to move his RV to spot for 1 month

109. No problem with 2 week storage: John; Dalton

110. John: motion to waive RV policy for duration of work through Pauwau

111. John-yes, Rick-yes, Dalton-yes, Scott-yes, 2nd Chief Iris (Susan)-abstain

112. Rick: Special Needs Fun Day

113. Work with Horry County Disabilities

114. Bring children out for games, horseback rides

115. Waccamaw Warriors to adopt a child for a day

116. John, Rick going; let him know if you can too

117. John: think there needs to be a fundraising committee to gather ideas; more than one Pauwau a day

118. Upcoming election: where are they stored/ who has access?

119. Michelle: My house; me. Can put things in, cannot take things out without breaking the box

120. Meetings- members’ meeting?

121. Michelle: Council, open to the members

122. John: an annual members’ meeting?

123. 2nd Chief Iris: Articles of Incorporated- 1 per month

124. Members are allowed input

125. Solstice: 6-8 people (according to Donnie)?

126. Dan: why can’t the demonstrators get their own room?

127. Michelle: If we didn’t pay for the room, the asking price would be dramatically higher than the cost of the room

128. Rick: do we shop around? (it always seems to be the same people)

129. 2nd Chief Iris: best price; some give money back

130. Charles Hughes: come to pauwaus; meetings twice a year, would like to turn in my application

131. 2nd Chief Iris: you can turn it in now; however the roll book is closed

132. Donnie: ants  still here; need to treat again

133. Frank: Why is a commercial man treating vs a tribal man?

134. 2nd Chief Iris/ Scott: there were lower bids

135. Frank: If we weren’t going to give consideration to Wayne, we should pay him for all his volunteer hours

136. 2nd Chief Iris: as members of a legislative body, we said we’d look after all members; not just 1. Bids= tribal public’s money

137. Frank: giving my views; not to be challenged by CM’s

138. 2nd Chief Iris: he’s always given 1st choice; his work is good. We signed a commitment to represent all equally & fairly

139. Rick: do we have to take the lowest bid? Look at history of the company, references

140. Mark: agree with Rick; with that price, probably only coming once

141. Hank: always amiable with 2nd Chief Iris for 20 years

142. Rick: revisit: revisit vendor fees/ donations next month

143. 2nd Chief Cheryl: Pesticides should be part of B&G, not Pauwau

144. 2nd Chief Iris: Wayne had a contract to keep grounds up

145. Donnie: he didn’t get paid one year

146. Scott: Council is in charge of everything internal

147. People get a say at meetings instead of whispers in groups or outside our meetings

John motioned to close the meeting; Dalton seconded.

Meeting adjourned 8:45pm.

Respectfully submitted by Michelle Hatcher on 11/24/14 at 3:15 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
