---
layout: post
title: "July 2014 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2014/07/12/july-open-meeting-summary.html
post_id: 5649676
custom_summary: false
summary: ""
date: 2014-07-11T19:00:00-0500
lastmod: 2014-07-11T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2014/07/11/july-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 7/11/2014 held at the Tribal Office in Aynor, SC

1. CoC Scott, CM’s Dalton, Susan, John, Robert, and Rick present.

2. June Minutes read

3. Dalton: 5(b)(i)(2)(a) should not include Rick as a voting member yet

4. Dalton motioned to accept with change; Rick seconded

5. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

6. Financial Report: Alan

7. General Fund

8. Deposits: $1347.77 Debits: $1549.55  Balance: $13,032.17

9. Chief Hatcher: a deposit & withdrawal for $1000 for TN trip included; $98 left, receipts included

10. Building Fund

11. Deposits: $25.00 Debits: $0.00 Balance: $1075.00

12. Online Votes

13. 6/14 Purchase tractor parts

14. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

15. 6/14 Purchase & install 2 tractor tires

16. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

17. 6/19 Make trip to TN (not used)

18. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

19. 6/30 $500 to pay taxes on TN land (turned out to be $232, look over receipts)

20. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

21. Old Business

22. Membership Files

23. Dorinda Ammons

24. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

25. Justin Ammons

26. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

27. Jessica Hudnall

28. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

29. Harley Smith

30. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

31. Jonathan Hudnall

32. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

33. Inactive Membership List

34. Dalton motioned to remove ID’s [#448](https://www.waccamaw.org/updates/hashtags/448)-452 on Monthly Report Query dated 7/11/2014

35. 2nd Chief Iris

36. Question about spousal/ associate members being required to use tribal court, but can’t constitutionally

37. Dalton & Chief Hatcher: need to revise membership agreement

38. John: If associate members came to tribal court, wouldn’t that make Chief part of judicial system?

39. Chief Hatcher: If someone doesn’t conduct themselves properly, we should ask them to leave; not part of judicial system

40. 2nd Chief Iris: Council needs to create a resolution

41. 2nd Chief Cheryl: why wouldn’t they go before 2nd Chief Judicial?

42. Dalton: that’s how Chief wants to handle it

43. Chief Hatcher: that will work

44. 2nd Chief Cheryl: Or Council as jury, 2nd Chief Judicial to hear case

45. Chief Hatcher: that will work

46. Children: we have to do something for them; get them involved

47. Can’t B&G do something with trailer for the kids?

48. Chief Hatcher: what good does it do if they are playing games over there and a meeting is going on here from a cultural aspect?

49. 2nd Chief Iris: groom them; games, camping trips

50. Darlene W: have to have a mix of fun & cultural

51. Jeania K: would love to bring kids here, not sure younger ones would sit still long enough though

52. 2nd Chief Iris: two people (Jessica & Hayes) willing to take over youth group

53. Rick: let them watch a video about culture during the meeting

54. Chief Hatcher: put electric, air, bathroom there now

55. John: still don’t think we need toys

56. John to work on it  with Rick & present costs to Council

57. John: need someone with carpentry skills

58. Committee Reports

59. Arts & Crafts: Susan

60. Dalton motioned; Robert seconded for Chief Hatcher to be on committee

61. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-abstain, Scott-yes

62. Applications

63. Darlene White

64. Robert-yes, Chief Hatcher-yes, Susan-yes, 2nd Chief Iris-yes

65. 2nd Chief Phil White

66. Robert-yes, Chief Hatcher-yes, Susan-yes, 2nd Chief Iris-yes

67. Neal Richard

68. Robert-yes, Chief Hatcher-yes, Susan-yes, 2nd Chief Iris-yes

69. Congratulations to new artists

70. Chief Hatcher resigned from committee

71. 2nd Chief Iris asked to schedule a meeting

72. Chief Hatcher suggested nominating voting members/ Robert seconded

73. 2nd Chief Phil, Neal nominated as voting members

74. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

75. Now 6 members as voting members

76. Grants: Michelle

77. Section 184 Grant for Home Repairs

78. Housing Trust Fund 10/1

79. Through state; have to meet criteria

80. No interim draws, only final payment

81. Rebuilding Together for cosmetic home repairs

82. Buildings & Grounds: John

83. Thank you to Donnie, Richard T, Wayne T, Rick

84. Cemetery Fund: $410

85. Solstice: discussed making it more vendor-friendly as far as spacing

86. Get away from spending money on all electrical outlets

87. Move them behind tents to avoid tripping

88. 5-6 RV spots for food court at front of grounds

89. 200 amp box; 30 amp per site & water

90. Spread them out, more than 22ft requested

91. No RV’s in that area

92. Susan: you’re still going to have a problem with congestion (and described spacing between dance circle and vendor circle)

93. Chief Hatcher: too late to do this year; land has to heal

94. Susan: Can food vendors see Pauwau from spot you want to put them?

95. Dalton: separate the two issues out

96. 2nd Chief Cheryl: power, space

97. John: aside, if want to do a living village, dance circle is in wrong place

98. John motioned to allot money for 6 RV spots; Dalton seconded

99. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

100. Spring Trimmer Receipt: $390.48

101. Neal & Wayne went through nature walk; want to reinstitute it

102. Perhaps scouts could help

103. Working on leveling & cool seal

104. Pond fence: take down or revamp

105. 2nd Chief Cheryl: teenage boys would like to go fishing

106. Scott: before Pauwau?

107. John: after

108. Rick motioned to take down the fence, cut trees, revamp area after Pauwau; Susan seconded

109. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

110. Pauwau: Susan

111. Had meeting on 7/9/2014

112. Hotel price is $53 this year; possibly next as well

113. Hog Heaven fund raiser: $750

114. Money to be used for 2 billboards

115. Billboards: information sent to Lamar

116. Rivertalk: Mon. @ 11:30, also a couple before Pauwau

117. Debbie B brought up curbing Waccamaw Bucks to raffle & dues

118. John: some people do so much work for Waccamaw Bucks, but get so little of them, after awhile they aren’t useful

119. Scott: would rather them pay dues than win a $500 raffle

120. Rick: after someone has volunteered for so much, why does he have to pay a gate fee?

121. Chief Hatcher: we have to make money at Pauwau to pay people (MC’s, lead dancers, drum, etc…)

122. Darlene W: make them non-transferable/ sole-use only

123. Alan F: keep list throughout year of who works

124. Michelle: all volunteer forms are supposed to be turned in to me

125. Susan: Waccamaw Bucks help people who can’t come up with money to pay dues

126. Dalton motioned to restrict Waccamaw Bucks to raffle/ dues; all volunteers to get a personal gate pass

127. Chief Hatcher: not that simple- not everyone knows who volunteers

128. Ahead of timeline

129. Deadline for ads & Program Book articles is 8/15

130. Darlene W asked about an “In Memory” page

131. Susan: cost is $25; anyone can do them

132. Mark A: would like to see different recipes

133. Michelle: send them to us

134. Fuel Receipt: $81.14 Check 593

135. Dalton motioned; Rick seconded

136. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

137. Chief Hatcher’s TN receipts looked over and accepted

138. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

139. Aynor Hoe Down volunteers: John & Rick

140. John motioned to spend $60 on Hoe Down fee; Dalton seconded

141. Rick-yes, Robert-yes, John-yes, Susan-yes, Dalton-yes, Scott-yes

142. Michelle to fill out and send form in

143. Note: Done on 7/14/14

144. 2nd Chiefs

145. Cheryl: safe room: FEMA gives them to the state; still looking into it

146. Possible alternate safe location in event of hurricane

147. Not sure because we aren’t here at office all the time

148. John: would it help as tribe since we have mobile homes; give tribal members a safer location?

149. Darlene W: gone through all FEMA classes; not likely tribe will get it because there is a school a mile away

150. Chief Hatcher

151. To Mark A: good suggestion on program book

152. We have & approved 2 master genealogy charts (James Hatcher, John Dimery)

153. Will be required to have 80% core members when law changes

154. 2nd Chief Iris: will have percentages next month

155. Need to see birth certificates/ census report in all files

156. Rep Rutherford: proposal for SC gaming to everyone

157. Request him to tailor it to only state recognized Indian tribes

158. Add sewer/ septic project to monthly agenda

159. 4/4 vote was to begin with pump

160. Drum briefing by Rick Hudnall

161. 2nd Chief Phil asked about who would teach, where, etc…

162. TN property: 2 thank you letters framed, signed by everyone for them

163. Neal: If I were in TN, can I go hunt, fish, etc… there?

164. Susan: don’t know about hunt, up to Council

165. He’d like $5/ day for electric though

166. Susan: Chief Norris said it would be good spot for retreat, sweat lodge

167. Pauwau 9/20: Santee

Dalton motioned to close the meeting; Susan seconded.

Meeting adjourned 9:25 pm.

Respectfully submitted by Michelle Hatcher on 7/30/14 at 11:51 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
