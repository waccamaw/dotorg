---
layout: post
title: "August 2015 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2015/08/08/august-open-meeting-summary.html
post_id: 5649684
custom_summary: false
summary: ""
date: 2015-08-07T19:00:00-0500
lastmod: 2015-08-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2015/08/07/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 8/7/2015 held at the Tribal Office in Aynor, SC

1. CM’s Homer, John, Rick, Robert, and aCoC Dalton present. 2nd Chief Cheryl served as proxy for CM Susan

2. July minutes read & voted for online:

3. John-yes, Rick-yes, Scott-yes, Dalton-yes, Susan-abstain

4. Financial Report

5. General Fund: $7239.50

6. Building Fund: $5381.13

7. Old Business

8. Resolution JR-HH-06-01-2015-001: Awarding of Tribal Membership: 3rd Reading

9. Cheryl motioned; Robert seconded to accept

10. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

11. New Business

12. SCIAC would like to borrow 15 chairs

13. Cheryl: when will they be returned?

14. Dalton: not sure

15. Rick: how many white ones do we have?

16. Cheryl: need a timeline to avoid them being claimed

17. Rick: also have Pauwau in Nov.

18. Dalton: put them on loan until Nov?

19. Cheryl: it should give them time to get their own

20. John motioned; Cheryl seconded

21. Rick: would rather it be cloth ones; plastic is easier for us to move around

22. John: 15 folding chairs

23. Are we going to have them sign for the chairs?

24. Dalton: up to Chief, but probably

25. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

26. Committee Reports

27. Arts & Crafts: Cheryl

28. Working on guidelines

29. Looking at having a booth at the Pauwau

30. Rick: vinyl brought out, put under storage

31. Grants: Michelle: nothing at this time

32. Buildings & Grounds: John

33. RV walkthrough: every spigot & electric outlet works

34. Extending water line back, need hydrants, spickets, trencher, cost approx. $390

35. Rick motioned; Robert seconded to run water rest of the way back

36. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

37. Bought weed chemicals for around the pond for 3 years ($262.50) and recirculating pump ($40.03)

38. Fire ant treatment- Mark has the sprayer; we do the labor

39. Wayne T has chemicals for $600

40. Cemetery fund: $400.13

41. July cemetery work days 7/17-18- thanks to Jernigans, Glen & Wayne T, Chief Hatcher, and 2nd Chief Cheryl

42. Work Day 8/22 9am at the Cemetery

43. Mower deck fixed

44. Dirt delivered

45. State took care of beaver problem

46. Pauwau: Michelle

47. Meeting 8/13 at Ryan’s

48. Timeline currently up-to-date

49. Rick: a golf cart was donated

50. Who donated the golf cart?

51. Jeff T

52. It still needs a battery

53. We may be able to get a cart donation from Graham’s this year

54. Sewer Pump Project: Mark

55. Cost about $5620 to get everything we want done

56. Drum: Rick: nothing

57. Constitution: Dalton

58. Article V: nearly complete

59. Meetings are the day before each open meeting at 6:30pm at the tribal office

60. Article X ballots in the newsletter; need 104 back

61. Elder Doug: they aren’t secret ballots

62. Dalton: they can be folded so that the label part can be cut away from the ballot

63. Michelle: the only person who will see the label is the person checking the mail; the people who check the mail aren’t the Elders

64. Fuel Receipts

65. Fuel: $63.07 Check 636

66. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

67. Feed state guys who delivered dirt: $36.34 check 637

68. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

69. Hoe Down

70. John said yes if he could get 4 people to help; application due this month

71. Dalton: did you get 4?

72. John: no

73. Jeania

74. Membership fees presentation & how to strengthen the tribe’s financial position

75. 2nd Chief Cheryl (for Chief Hatcher)

76. SCIAC Bingo 8/9 @ 1pm in Garden City is opening

77. 3 applications for promoter for WIP Bingo- need a decision ASAP

78. John: how can Susan be the promoter at both if at a site 90% of time?

79. Dalton: believe you can promote up to 3; it’s like  general manager position- you can have assistants

80. Reminder to Elders & Council: ballots are out; count after 9/1

81. John: interview date for promoter?

82. Dalton: Tues? have them all here on the same day

83. Rick: are we going to do more than one?

84. Jeania: having surgery Mon

85. John- Friday night 6:30

86. Homer-yes, John-yes, Robert-yes, Cheryl-yes, Rick-yes, Dalton-yes

87. Rick: how about Sun? for those who work Friday?

88. Rick: we don’t know how much we’re going to pay them or anything. I’d be skeptical to apply to a place that can’t tell me about their business

89. Michelle: Chief Hatcher proposed $500-600/ week

90. Dalton: need to discuss it with him by email since he knows more about it

91. Procedures for signing the tribal roll book while living out-of-state (across country)

92. Form letter stating they signed TRB in absentia

93. Give a deadline to send it back

94. Mark: letting them sign in absentia defeats the purpose of getting more people involved

95. John: can we get a statement from the member explaining why they can’t come sign the roll book?

Homer motioned to close the meeting; Dalton seconded.

Meeting adjourned 3:45 am.

Respectfully submitted by Michelle Hatcher on 8/31/15 at 3:45 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
