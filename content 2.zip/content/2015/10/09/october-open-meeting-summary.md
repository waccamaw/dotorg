---
layout: post
title: "October Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2015/10/10/october-open-meeting-summary.html
post_id: 5649631
custom_summary: false
summary: ""
date: 2015-10-09T19:00:00-0500
lastmod: 2025-11-22T19:02:11-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2015/10/09/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/09/2015 held at the Tribal Office in Aynor, SC

1. CM’s Homer, Susan, Robert, Mark, Rick, Dalton, & CoC John present.

2. September minutes read.

3. Dalton motioned to approve; Homer seconded

4. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

5. Financial Report

6. Unavailable; will update in December

7. Online Votes

8. 9/23 ID Card Dye Roll

9. Homer-absent, Susan-yes, Robert-yes, Mark-yes, Rick-absent, Dalton-yes, John-yes

10. Old Business

11. Membership Files

12. Justin Ammons

13. Susan motioned to approve; it was emailed, just not printed

14. Files before 9/4/2015

15. Charles Ray Hughes

16. Kenneth Logan Stone

17. Jannette Ammons Chatham

18. Deanna Michelle Chatham

19. Bonnie Ammons Stewart

20. Amanda Stewart Cook

21. Belinda Ammons Chatham

22. Tabitha  Chatham Risk

23. Benjamin Dale Chatham

24. Zachary Chatham

25. Jean Dorothy Hayes

26. Sara Louise Sellers Nunez-Mason

27. Mickey Thompson

28. Dock Roy Sellers

29. Melissa Thompson

30. Mark: keep books open till next open meeting till all hanging apps are done; Homer seconded

31. Rick: Make them all honorary, get them genealogy done, & get them off books; Dalton seconded

32. Mark withdrew his motion

33. John: amend motion to accept all completed apps in full except genealogy as honorary & will continue to work on it until federal recognition; Postpone all other apps until after TRB reopens; Dalton seconded

34. Secretary’s Note 11/18: Files added to TRB

35. Christian Josiah Hooper

36. Maranda Bost Fritts Spry

37. Olivia Bost

38. Bobby Bost

39. Courtney Ammons Spry

40. Henry Isaiah Hooper

41. Samuel Seth Hooper

42. Elijah Jacob Hooper

43. Bethanie Jordan Hooper

44. Nola Grace Ammons Hooper

45. Jonathan Bently Louie Spry

46. Nathaniel James Spry

47. Jaycee Nola-Merle Curry

48. Jayda Nina Marie Curry

49. Winfred Todd Curry

50. Charles Andrew Hooper

51. Hannah Turner

52. Bryan Turner

53. Kenneth Eugene Ammons

54. Facha Kim Jamila Modupa (Janet Alice Wilson)

55. Hakim El-Faith Abdulrahman (John Henry Mitchell)

56. Kevin Schewdo

57. Ezekiel Pardo

58. New Business

59. Committee Reports

60. Arts & Crafts: Susan

61. Discovery place in Charleston: display for 1 year- arrowheads, gourds, knives, bonnets, necklaces

62. John: has Todd or Phil worked on constructing the display case/ building for it?

63. Grants: Michelle

64. Nothing yet; looking at first of year

65. Buildings & Grounds: John

66. John stepped down as chair; Rick took over as chair

67. Fire Ant treatment doesn’t seem to cover as much as we though; Wayne will do it $400

68. Rick motioned; Mark seconded

69. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

70. Check 1049 $400 from building fund account

71. Cemetery Fund: $411.15

72. Roof Project: discussed possibly doing a pitched roof

73. Electrical box shorts will cost approximately $406 to replace all

74. Dalton: as Chair, you could spend up to $500. Do you want that to extend to Rick?

75. Homer motioned; Susan seconded

76. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

77. Pauwau: Michelle

78. 11 vendors so far, but most show up with paperwork in hand

79. Program Book has a new page with the Governor & a new picture of Mark

80. Last pauwau meeting of 2015 is 10/14

81. John requested more volunteers

82. Chief Hatcher doing a presentation/ event in NMB on 10/17

83. Sewer Pump Project: Mark

84. Roof should be done first

85. John: take this off reports until we have more funds

86. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

87. Drum: Rick

88. Two guys come to Rick’s house a few times a week and have learned two songs

89. Going to Chicora event on 10/17 to play

90. Request and granted permission to use the small drum

91. Constitution: Dalton

92. Next meeting in December

93. Still waiting on call-in results from Steve

94. Fuel Receipts

95. $41.46

96. John motioned; Susan seconded

97. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

98. Check 643

99. Chief

100. Lawyers don’t want us to go through Congress because they can put laws into the recognition process

101. Sally, SC- event with Chief Chavis

102. Special Needs Family Fun Day: Rain or Shine Day

103. Susan: 11/5: Pauwau/ School Day setup & Family Day

104. Chief Anthony Davidson passed away

105. Rick: Work Day:10/24 & 10/31

106. John: thanks to all who came out during the equinox

Mark motioned to close the meeting; Susan seconded.

Meeting adjourned 7:58 pm.

Respectfully submitted by Michelle Hatcher on 01/05/16 at 4:03 pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
