---
layout: post
title: "February 2015 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2015/02/07/february-open-meeting-summary.html
post_id: 5649682
custom_summary: false
summary: ""
date: 2015-02-06T19:00:00-0500
lastmod: 2015-02-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2015/02/06/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/6/2015 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Susan, Homer, Robert, John, and Rick present. Dalton chaired the meeting for CoC Scott.

2. CoC requested a 3 month leave of absence while he moved to NC and that Dalton be acting CoC

3. Vote on leave of absence

4. Homer-yes, John, yes, Rick-yes, Robert-yes, Dalton-yes

5. Vote for making Dalton Acting CoC

6. Homer-yes, John-yes, Rick-yes, Robert-yes, Dalton-yes

7. Susan was sworn in for new term of Council & Dalton was sworn in for a reinstatement to Council.

8. January minutes read

9. Rick motioned to accept; Homer seconded

10. Homer-yes, John-yes, Rick-yes, Robert-abstain, Susan-abstain, Dalton-yes

11. Financial Report (via Lori’s email)

12. Building Fund

13. $9.95 debit for website now going through general fund

14. Balance: $1892.65

15. General Fund

16. Balance: $8354.74

17. Old Business

18. Trademark of Tribal Logo: Susan

19. Price grew as you expand search criteria

20. Jeania: you can go directly through federal trademark office

21. 1.

      1. 1.

22. Poor man’s copyright can still be bought from under you; they could have established logo before you

23. Resolutions

24. Res DH-12-06-2014-002: Volunteer and Donor Rewards: 3rd Reading

25. Susan: $20 can be in-kind- is it implied or should it say that?

26. Dalton: implied, but we can add it

27. Rick motioned to accept; Robert seconded

28. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

29. Res DH-01-09-2015-001: Waccamaw Buck Elimination: 2nd Reading

30. Dalton: okay to change date to “on or before Aug 1?”

31. Council: yes

32. John: why does it stay a living document?

33. Dalton: we may decide to make changes up to March

34. New Business

35. Committee Reports

36. Arts & Crafts: Susan

37. Meeting was 1/18

38. 1 approved application; confirmed by ACoC

39. Currently have 4 voting members; need 3 more certified artists

40. Would like to keep trailer for classes

41. Chief Hatcher: decide on trailer- fix it or do away with it

42. Susan motioned to drop time period to 60 days; else give it to John’s friend for scrap; John seconded

43. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

44. Robert: use storage building for classes

45. Susan: want locking door knobs on front/ back

46. Needs electricity, lights, steps

47. John: Having a B&G meeting 2/21 if you want to come out

48. Starting a budget; probably around $300-400

49. Grants: Michelle

50. SCAC due 3/15

51. Lowe’s for material: Becky

52. Buildings & Grounds: John

53. Thanked friend in CA and others for B&G donations

54. Next meeting 2/21- to do walkthrough of RV sites

55. Voting members: Wayne T resigned

56. RV proposals from last month: approx. $3395

57. Cemetery Fund: $370.07; read letter to post on website

58. Fundraiser suggestions

59. Turkey shoot

60. Chief Hatcher: find out about advertising

61. Dalton: curious about insurance on this one

62. Archery- sanctioned event

63. Fishing Tournament

64. Elder Hank- yard sale

65. Rick: Soft BB Gun Tournament: pay to get in gate, for tournament, stay all night

66. Pauwau: Michelle

67. Need Council to confirm Dalton as a voting member

68. Homer motioned; Rick seconded

69. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

70. Starting a SoP book to put everyone on the same page as far as procedures, whether they are on committee or not

71. Sewer: Mark:

72. Waiting on funding

73. Drum: Rick

74. Need more participation

75. Constitution: Dalton

76. Next meeting in May the Thursday before Council meeting

77. Article 4 done, 5 nearly done, 10 needs to change first

78. Res DH-02-05-2015-001: Constitutional Amendment

79. Homer motioned to accept; John seconded

80. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

81. Asking for 3-reading rule waiver

82. Chief Hatcher: yes

83. Chief Hatcher: we will need people to help call others to help pass amendments; put in newsletter

84. Funding for Letterhead & Envelopes: $250

85. Rick motioned; Robert seconded

86. Homer-yes, John-yes, Susan-yes, Rick-yes, Robert-yes, Dalton-yes

87. Chief Hatcher

88. Introduced Dan Fuller from the Native American Chamber of Commerce

89. American Indian Religious Freedom Act- about Eagle feathers/ parts & state recognized tribes

90. Display in Pawley’s Island Library: 2/21, 2/28

91. Chief Hatcher & Susan doing presentations

92. Library will show our items & people can purchase artist works

93. Letters: donation letters from B&G- John to seal & stamp

94. Also used the gofundme site

95. Federal Recognition

96. Tom Rice said he would hold a meeting with SC delegation in DC

97. Would like to do ASAP; would take a week or two

98. Laws are changing; his chief of staff says we may not need Congress

99. Disagree; the criteria require congressional intervention

100. Need 10 people to write letter to their congressman saying why this issue is important

101. Jeania, Glen, Ronnie, Frank, Brenda, Doug, Mark, Homer, Rick, Donnie

102. John: website is lacking; member Tim Ammons does it for a living

103. Chief Hatcher: tell him to contact me to get passwords to get started

104. John: do you want samples or do you want him to just do it?

105. Chief: just do it

106. Dan Fuller: Economic Drive: partner with companies to provide jobs to Natives first

107. Expo in Greenville 4/23-24 with dancing & seminars

108. Can set up tables there too

109. Susan: work at amphitheater has begun; concert in May

110. Let her know if you want to get in touch with Hartman for job

Susan motioned to close the meeting; Robert seconded.

Meeting adjourned 8:38 pm.

Respectfully submitted by Michelle Hatcher on 3/1/15 at 5:55 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
