---
layout: post
title: "September 2015 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2015/09/05/september-open-meeting-summary.html
post_id: 5649685
custom_summary: false
summary: ""
date: 2015-09-04T19:00:00-0500
lastmod: 2015-09-04T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2015/09/04/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 9/04/2015 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Susan, Homer, Rick, John, & CoC Scott present.

2. Chief Hatcher appointed CoC Scott to 2nd Chief Internal and Mark Ammons to Tribal Council.

3. Council nominated John to CoC position.

4. August minutes read & voted for mostly online.

5. Dalton motioned; Rick seconded

6. Homer-yes, Susan-abstain, Mark-abstain, Dalton-yes, Rick-yes, John-yes

7. Financial Report

8. General Fund: $6190.95

9. Building Fund: $5407.30

10. Online Votes

11. Minutes

12. John-yes, Dalton-yes, Rick-yes, Scott-yes

13. Reimburse John T $302.03 (receipts presented at previous meeting)

14. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

15. Old Business

16. Membership Files

17. Justin Ammons’ file is missing: we need a physical file for federal reasons, not just to update his status

18. Susan: we can still vote on it

19. Homer motioned that his file be updated pending paperwork within 30 days; Dalton seconded

20. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes, John-yes

21. Chief Hatcher: should we make the current waiting list honorary members?

22. We can’t add names after federal recognition (would have to go through BIA)

23. If the file is complete, Chief Hatcher will make them honorary

24. John: so no more apps are to go out and current apps that are out have 30 days to return completed

25. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

26. New Business

27. Committee Reports

28. Arts & Crafts: Susan

29. Waiting to hear from the Native American studies department about sending items to the gallery

30. We wanted to do a pauwau booth, but there’s not much interest among members

31. Mark: will Iris loan display pieces?

32. Susan: talk to her

33. Discovery place in Charlotte wants display pieces

34. Grants: Michelle

35. Nothing at this time

36. Buildings & Grounds: Rick & John

37. Wayne did cemetery work ahead of time; others did pond cleanup

38. Work Day late Sept around RV sites

39. Found electrical short in vendor post

40. Donation for one fire ant treatment by Larry Ammons, Sr.

41. Cemetery fund: $400.14

42. Nice gesture at solstice/ pauwau to to do smudging at cemetery annually or with the solstice

43. Pauwau: Michelle

44. Budget needs approval

45. Elder Doug suggested having our own people shadowing the paid demonstrators

46. Mark: why not do competitive dancing to get more people?

47. Chief Hatcher: you get a lot more dancers, but it will cost you a lot more money

48. Rodlyn: you want dancers here who love to do it, not just ones who want money

49. Susan motioned to approve the budget; Mark seconded

50. Susan-yes, Homer-yes, Mark-yes, Rick-yes, Dalton-yes, John-yes

51. Program Book

52. Dalton is calling people from last year to renew ads

53. Same book from last year but with a different cover since they weren’t sold

54. Meeting at Ryan’s Wed @ 6:30pm

55. Sewer Pump Project: Mark

56. Needs funding

57. Drum: Rick

58. Suggest that Arts & Crafts head up the drum since Rick doesn’t have the contacts

59. Rick: still need to learn how to drum myself

60. Chief Hatcher: applied for funding from Edisto

61. Elder Doug: training in TN on tape with children

62. What would be wrong with inviting community children?

63. Chief Hatcher: etiquette; they may not be aware of the reasons some things are done or not done a certain way

64. Special Needs Family Fun Day: archery & other activities 10/10

65. They also sent a letter of appreciation for the golf tournament

66. Constitution: Dalton

67. Article V: hope to be done by October

68. Article VI: hope to be done by October

69. Work on Article VII in October

70. Ballots back: 66

71. Blank ballots on the table for anyone eligible to vote who has not yet done so

72. Discussed having Elders calling for votes & then mailing out ballots to remainder

73. Elder Dan: we liked this idea very much

74. Need Council to approve Council of Elders calling for votes & recording them

75. Mark motioned; Dalton seconded

76. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

77. Discussed having mandatory elections

78. Elder Dan: we negated this idea

79. Meeting next month Thursday before the open meeting

80. Membership Files: Heather Beaver (spousal)

81. Susan motioned; Rick seconded

82. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

83. Fuel Receipt: $110.61 Check 639

84. Susan motioned; Homer seconded

85. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

86. 2nd Chief Cheryl

87. Website Development

88. We can add a store to the website

89. The guy wouldn’t be the web admin but is capable of good work

90. Put him in touch with Aaron

91. Chief Hatcher

92. Pauwau on 19th in Ridgeville, SC: Santee

93. Meeting in Columbia

94. Waccamaw elected again to recognition team & would like to keep Joey Watford there

95. Susan motioned; Homer seconded

96. Homer-yes, Susan-yes, Rick-yes, Dalton-yes, John-yes

97. High School Education

98. Indian Development Council will help with expenses

99. A job training flyer was shown

100. Website links to free health care in the area

101. 2nd Chief Scott

102. Grateful for 2nd Chief position

103. Congratulations to John

104. Encourage everyone to give John respect

105. Solstice

106. Mark: plan on food; can freeze

107. Susan: don’t know how many will show up; would rather wait to buy

108. Mark

109. Core of engineers/ HC Stormwater needs to contacted about water standing everywhere

John motioned to close the meeting; Rick seconded.

Meeting adjourned 8:27 pm.

Respectfully submitted by Michelle Hatcher on 9/30/15 at 1:13 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
