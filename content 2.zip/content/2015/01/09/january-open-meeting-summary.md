---
layout: post
title: "January 2015 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2015/01/10/january-open-meeting-summary.html
post_id: 5649681
custom_summary: false
summary: ""
date: 2015-01-09T19:00:00-0500
lastmod: 2015-01-09T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2015/01/09/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 1/9/2015 held at the Tribal Office in Aynor, SC

1. CM’s Homer, Dalton, Scott, John, Rick present.

2. Chief Hatcher: Res J-HH-01-09-2015-001: Appointment of Elders

3. Appoints Avalene Standing Bear to Elders

4. Dalton motioned to accept; Homer seconded

5. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

6. Homer and Scott were sworn in for new terms for Council and Avalene was sworn in to Elders

7. Dalton nominated Scott to remain CoC; Homer, John seconded

8. Homer-yes, John-yes, Rick-yes, Dalton-yes; Susan-yes (by text)

9. Scott thanked everyone for their support

10. December minutes read

11. John motioned to accept; Homer seconded

12. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott- abstain

13. Financial Report

14. Not available

15. Dalton nominated Lori O as treasurer; John seconded

16. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

17. Online Votes

18. Pay TN land taxes

19. John-yes, Rick-yes, Dalton-yes

20. Old Business

21. Trademark on Tribal Logo

22. Lindsey: all things ready; just have to get with Susan to complete it

23. New Business

24. Committee Reports

25. Arts & Crafts

26. Nothing to report

27. Grants: Michelle

28. Nothing until February

29. Buildings & Grounds: John

30. Just had a meeting

31. Removing Scott from committee and need to replace him with Larry J

32. John motioned; Rick seconded

33. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

34. Having quarterly meetings- second Saturday at 9am, beginning 3/14- working meetings

35. 3rd Saturday is cemetery work day- 9am at Bethel, beginning in March

36. Old trailer- not worth anything; cost more to repair than it’s worth

37. Chief Hatcher: Jeanie has asked to buy it twice

38. John: $1500 or best offer?

39. Windows and roof need repairs due to leaks

40. John motioned to give it to her if she wants it/ Dalton seconded

41. Dalton said put a time limit on it

42. Rick said put it in writing

43. Current motion: 90 days from offer

44. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

45. RV spots: 10 spots with frost-freeze spickets- approx.. $4000 total

46. Fix old spots- approx.. $1100

47. Need gravel or something for parking

48. Homer: what about sewer?

49. John: isn’t that on the agenda?

50. Dalton: do people send in Buildings & Grounds donations?

51. Michelle: yes, Homer always does

52. Chief Hatcher: Avalene just gave $100

53. Chris H: can you get a better price?

54. Bathroom floor needs to be finished

55. Need back door; water comes in when it rains

56. People with Disabilities fishing event for PR

57. Fishing tournament in Conway

58. Indian games fundraiser- archery

59. Pauwau: Lindsey

60. Next meeting is Wed. at 6pm

61. Scott thanked Mark, John, Rick

62. Sewer Pump Project: Mark A

63. Waiting on funding

64. Drum: Rick

65. Will work with Andy during pauwau

66. Constitution: Dalton

67. Need to set Jan meeting date

68. Resolutions

69. Res DH-12-06-2014-002: Volunteer & Donor Rewards: 2nd Reading

70. Res DH-01-09-2015-001-Waccamaw Bucks Elimination: 1st Reading

71. Mark A: change fees to dues because it sounds like people can pay their application fee with Waccamaw Bucks

72. Res DH-01-09-2015-002: Establishing Proxy Voting to the Program Committee Resolution

73. Dalton asked for a waiver to the 3 reading rule; Homer seconded

74. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

75. Rick motioned to accept the amendment; Dalton seconded

76. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

77. Receipts

78. Antifreeze (tractor): $15.83 Check 623

79. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

80. Fuel: $36.12 Check 622

81. Homer-yes, John-yes, Rick-yes, Dalton-yes, Scott-yes

82. Chief Hatcher

83. Thanks to John, Rick, Mark

84. Need Lori to setup budget & Council to abide by it

85. Would like to change name on Duke Energy bill

86. Should be in tribe’s name; comes in Chief’s

87. Also need to change auto-payment setup- should come from general fund

88. Family Day

89. Closest Saturday to 2/17

90. Mark to cook

91. Budget is $200 per policy letter

Homer motioned to close the meeting; Dalton seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 2/4/15 at 4:45 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
