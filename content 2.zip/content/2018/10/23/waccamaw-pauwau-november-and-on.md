---
layout: post
title: "Waccamaw Pauwau - November 3 and 4 on Waccamaw Land at 591 Bluewater Road, Aynor, SC 29511"
microblog: false
guid: http://waccamaw.micro.blog/2018/10/24/waccamaw-pauwau-november-and-on.html
post_id: 5650051
custom_summary: false
summary: ""
date: 2018-10-23T19:00:00-0500
lastmod: 2018-10-23T19:00:00-0500
type: post
url: /2018/10/23/waccamaw-pauwau-november-and-on.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Oct 23, 2018
- 2 min read

**NOTE: Help your favorite Tribe to get this information out! Our Chief may be ugly but we are great people!**

Please share and ask others to share.  Place on your FaceBook and everywhere you can think to post! Bring us proof that ten of your friends have shared it and you will be rewarded!

**The Waccamaw Indian People's  Pauwau is on  November 3rd and 4th, 2018**

**There will be survival skills demonstrations** (Fire starting with the bow drill, ancient clothing, ancient cooking techniques, ancient weapons demonstrations, displays of traps and snares).

**Storytelling** by one of the best Cherokee traditionalists in the business.

**Dancing in full regalia** including most any traditional Native Cultural dance in the country.

Over 30 displays of Native Arts and Crafts to peruse and purchase! Most are handmade! Christmas Shopping?

Prices: Adult $7.00 (15 years to 59 years), Child, and Senior $4.00 (7 years to 14 years and over 60 years)

6 years and under no charge!

**The Pauwau is Open to the Public and will happen come rain or shine. **

**Parking is absolutely Free! We have never charged to park! There is no charge to park!**

Photos taken at this Pauwau may be used in school textbooks exhibiting full regalia dancing, and other cultural exhibitions that showcase the Native Culture from anywhere in the country.

This year, there will be producers and journalists, on-site videotaping, asking questions and preparing two different documentaries which will air in the near future.

**Everybody is welcome. No racism and no hatred will be tolerated. Bring the kids, a lawn chair, a few friends and relax!**

Sorry, but pets are not allowed in the arena or Fire Circle areas. Please leave them at home unless you have papers proving they are service animals.

**There will be absolutely No alcohol, No drugs, No cussing, No racism or No meanness allowed **

Security onsite 24/7!  You will be escorted off of the grounds if you cannot act properly in public!

Anyone on the grounds may be interviewed and wind up on the screen. Unless you say otherwise!

We pay **dancers** by "luck of the draw" dance payout.

If you are registered and in the arena when a draw is called, and your number matches the called number, you get to pick an envelope from a bucket. Whatever is in the envelope is yours!

**It may be as much as $300,  but never below $50. There will be ten draws each day.**

Note: Even Native Dancers must pay to enter the Pauwau grounds, but their money will be returned when they register, if in regalia. Therefore, after they register, Dancers are in FREE!

**Come Rain or Shine -  November 3rd and 4th at 591 Bluewater Road, Aynor, SC 29511**

**The Waccamaw Tribal Grounds**

**Host Motel**: Quality Inn and Suites $49.99 per double (plus tax). If you mention the PauWau.

**843-272-6153**

More PauWau Information, including vendor information

843-358-6877

[#Pauwau](https://www.waccamaw.org/updates/hashtags/Pauwau) [#community](https://www.waccamaw.org/updates/hashtags/community) [#festival](https://www.waccamaw.org/updates/hashtags/festival)
