---
layout: post
title: "October 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2018/10/06/october-open-meeting-summary.html
post_id: 5649709
custom_summary: false
summary: ""
date: 2018-10-05T19:00:00-0500
lastmod: 2025-11-22T19:02:17-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2018/10/05/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/5/2018  held at the Tribal Office in Aynor, SC

1. CM’s,  John, Dalton, Susan, Jeania,  and CoC Rick present. Elders Doug, Ronnie, and Becky present.

2. Financial Report

3. General Fund: $11,573.45

4. Building Fund: $1,969.12

5. Online Votes

6. Accept September minutes

7. Susan: absent, John-yes, Jeania-absent, Dalton-yes, Rick-yes

8. Pump Groundskeeper septic tank

9. Jeania-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

10. Old Business

11. Cemetery Update

12. Case settled, need to register paperwork, get map soon

13. Electrical Update

14. Glenn C: nothing yet, work tomorrow; set platform for new panel box

15. New Business

16. Susan

17. Best Chance Network: requested to come out next year

18. Do medical screenings

19. Census 2020: recruiting people: apply at census2020.gov/jobs

20. Quilts of Valor: fill out form Susan created & she can fill it out online for you; or you can fill it online yourself

21. Receipts

22. Fuel $53.96 Check 705

23. Committee Reports

24. Buildings & Grounds: Glenn C

25. Work Day 10/6 @ 8:30am: weedeat, panel box

26. Arts & Crafts: Susan

27. One app that needs to be reviewed

28. Pauwau: Michelle & Dalton

29. Program Book needs to be approved

30. Jeania-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

31. Looking for Volunteers

32. More trifolds ready

33. Aynor Hoe Down was canceled; they refunded the money

34. Bill Judge would like to document a few people at the Pauwau

35. Susan: sent an email to iheartmedia for PSA

36. Drum: Rick

37. Meeting again

38. Will play during School Day

39. Convention on the 29th

40. Accepting new drummers

41. Dalton: can you fill in at the Pauwau?

42. Rick: possibly

43. Constable Membership

44. Eric Morgan: make honorary

45. Joseph Carter: make honorary

46. Check ID cards on all Constables

47. Chief

48. Indian Development Council: meeting 29th at Convention Center

49. Colorguard: Ronnie, Shane, Susan, Alan

50. Rick, Glenn on drum

51. Carson to dance

52. Chief Harris to carry Eagle staff

53. Mayor of MB to be there

54. Provide opening prayer for meeting with Michael Avenatti on 13th

55. CMA: everyone has a right to talk to the Governor, but Indians have to get together & agree on an agenda, which CMA is trying to set

56. Churches can buy surplus items for cheap, but Indians have to live on reservation to qualify

57. Women on drum

58. Northern drums allow it

59. Some people will not want to participate if we allow it

60. Susan: what about ceremonies that won’t allow women to participate (example: pipe ceremony)?

<Tribal Secretary had a seizure at this point; no further notes>

Respectfully submitted by Michelle Hatcher on 10/22/18 at 2:16 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
