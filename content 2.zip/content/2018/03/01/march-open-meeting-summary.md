---
layout: post
title: "March 2018 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2018/03/02/march-open-meeting-summary.html
post_id: 5649703
custom_summary: false
summary: ""
date: 2018-03-01T19:00:00-0500
lastmod: 2018-03-01T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2018/03/01/march-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 3/1/2018  held at the Tribal Office in Aynor, SC

1. CM’s Susan, John, Dalton, and Rick present. Elders Dan, Glenn T, Ronnie, and Becky present.

2. Financial Report

3. Cemetery Report: $531.26

4. General & Building fund totals unobtainable due to password reset issues

5. Online Votes

6. 2/15 Appoint a Color Guard

7. Susan-yes, John-yes, Dalton-yes, Rick-yes

8. 2/15 Allot money to purchase Color Guard uniforms

9. Susan-yes, John-yes, Dalton-yes, Rick-yes

10. February Minutes

11. Dalton motioned to accept; John seconded

12. Susan-yes, John-yes, Dalton-yes, Rick-yes

13. Old Business

14. Cemetery Update: 2C Cheryl

15. Nothing back from Terry about our last proposal

16. New Business

17. Fuel Receipts: $25.05 Check 525

18. Committee Reports

19. Arts & Crafts: Susan

20. Only 2 people on the committee; propose a quorum be of the majority of voting members present and moving meetings from a monthly basis to quarterly basis

21. 2C Phil: we need a budget for A&C

22. Susan: do a temporary waiver & allow Rick to come on the committee

23. Rick: I agree to go

24. Dalton: motion to waive quorum requirements & confirm Rick as a voting member; 2C Phil seconded

25. Susan-yes, John-yes, Dalton-yes, Rick-yes

26. Grants: Michelle

27. SCAC grant due on 3/15; artists biographies due to me by 3/8

28. Pauwau: Glenn C

29. We have a couple of options on the drum

30. We checked on hoop dancers from Rick Birdm but they are too expensive

31. Michelle: Budget is in Drive and is updated each month

32. Need Council to approve Mathea as a voting member

33. Susan motioned; John seconded

34. Susan-yes, John-yes, Dalton-yes, Rick-yes

35. Susan: Red Oak: $500 total & 2 blanket dances per day & 2 rooms for 1 night

36. Flyers available soon

37. Volunteers will signup & signout on Saturday & Sunday tp receive volunteer credit

38. Always looking for older pictures; could be some that haven’t been featured in the book before

39. 2C Phil: did we get the power straightened out?

40. Susan: no

41. Susan: with the Jefferson Award, we have a contact with WPDE & can get PSA done there

42. 2C Phil: ask them for old footage too

43. John: do they have a relationship with coastal NC?

44. 2C Phil: if not, they can copy it & send it to the station

45. Alan F: will ETV run a PSA?

46. 2C Phil: no; they aren’t in the commercial business. Local stations can write it off

47. Elder Dan: Channel 4 does rotating ads

48. Glenn C: would like Council to approve $35 for Socastee heritage Festival

49. We will give out flyers, drum, Carson may dance, have a donation jar

50. Money was donated

51. Buildings & Grounds

52. Rick: motion to make Glenn C the chair; Susan seconded

53. Susan-yes, John-yes, Dalton-yes, Rick-yes

54. Glenn C: there will be a work day every Saturday after the open meeting

55. Susan: motion to allow him to spend up to $500 for emergencies; Rick seconded

56. Rick: it’s for emergencies; finishing projects

57. John: bring receipts

58. Susan-yes, John-yes, Dalton-yes, Rick-yes

59. John: Glenn T did spray something more durable than concrete on the ground as a test

60. Also need A/C fixed here

61. Glenn C: I will contact someone

62. JOhn: motion to let Glenn C look into A?C & get estimate to Rick if he can’t fix it; Rick seconded

63. Susan-yes, John-yes, Dalton-yes, Rick-yes

64. Any word on the grinding station?

65. Chris H: will have more next week

66. Drum

67. 2C Phil: bought leather & made more sticks

68. Elders

69. Elder Dan: we would like to go with gaming, but will take what we can get

70. Misc

71. Dalton: proposal for first reading next month: waive dues for disabled, age >65, possible imprisoned for nonviolent crime

72. Rick: Larry J, is everything good with the horse ride?

73. Larry J: yes

74. John: Recognition: 2 roads: Congress or BIA

75. We have to cleanup our files

76. We may be contacting members for missing items & will need them back ASAP

77. Dalton: letter will probably consist of a drop-dead date, so you could lose your membership if you delay it

78. We may also ask the Elders to get on the phones like they did during the election to help out

79. Rick: raffle tickets available for sell; proceeds go towards the Fishing Day event

80. 2nd Chiefs

81. Cheryl: January should have had a vote to remove 2 people, but nothing since then; several numbers aren’t up-to-date

82. We need to send out a letter telling people their card is about to expire

83. Dalton: Inactive policy is set: they have 3 months to get their fees updated

84. Susan/ Rick: Chief keeps giving out applications; won’t get caught up

85. Rick: make sense for 2C Cheryl/ filekeeper to give them out

86. Susan: Chief said that if we hadn’t given out applications to begin with, we wouldn’t have a tribe

87. Dalton: next Council work day, we’ll go over those specific files first

88. Susan: and we need to find the missing files

Dalton motioned to close the meeting; Susan seconded.

Meeting adjourned 8:30 pm.

Respectfully submitted by Michelle Hatcher on 3/22/18 at 12:16 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
