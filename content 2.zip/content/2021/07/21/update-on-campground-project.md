---
layout: post
title: "Update on Campground Project"
microblog: false
guid: http://waccamaw.micro.blog/2021/07/22/update-on-campground-project.html
post_id: 5650042
custom_summary: false
summary: ""
date: 2021-07-21T19:00:00-0500
lastmod: 2025-11-22T20:01:49-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/823e7efb58.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/823e7efb58.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/823e7efb58.jpg
url: /2021/07/21/update-on-campground-project.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jul 21, 2021
- 1 min read

Today marks another milestone for the Waccamaw Indian People. We finally have our sewer pump station put in place today for the office and trailers along with a dump station for the campers. All though we still have to put the plumbing in place  to and from the pump station. We will need to rent an excavator (or if someone has one we can use please let me know or for donation with the rental) to dig and place the plumbing in the ground. The plans to do this will happen in the next weekend or two.  We will post to let everyone know the date.

Thanks, Glenn C

![ree](https://waccamaw.micro.blog/uploads/2025/823e7efb58.jpg)

Tags:

- [B&G](https://www.waccamaw.org/updates/tags/b-g)
