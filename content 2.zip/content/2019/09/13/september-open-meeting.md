---
layout: post
title: "September Open Meeting"
microblog: false
guid: http://waccamaw.micro.blog/2019/09/14/september-open-meeting.html
post_id: 5649716
custom_summary: false
summary: ""
date: 2019-09-13T19:00:00-0500
lastmod: 2019-09-13T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/09/13/september-open-meeting.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 9/13/2019  held at the Tribal Office in Aynor, SC

1. CM’s Robert, Susan, John, Marion, Alan, Dalton, and CoC Rick present. Elders Doug, Becky, and Dan present. 2C Cheryl present.

2. Chief Hatcher introduced Carla Goodson who has helped with the National Guard

3. Carla: group collects donations, gloves, food, water for reservations dealing with catastrophes

4. Collected saddles for Sacred Ride, which lasts 18 days

5. Provide a space for people to sleep (25/ room or area)

6. Do pickups in Grey Court, Missouri, Rosebud, Navaho, Montana, New Mexico

7. Need bulk food, tents, laundry detergent, gloves

8. Organization started by Roger Dupuis (sp?)

9. Motto: Native Flags under one Nation

10. John T: are you asking for tribal food run or personal

11. Carla: both; all is appreciated

12. John: we could post to website, Facebook, email

13. Financial Report: not available

14. Online Votes

15. 8/9 Join NCAI

16. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

17. 9/2 Postpone meeting till 9/13 due to Hurricane Dorian

18. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

19. 9/6 Accept August meeting summary with correction

20. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-abstain

21. Old Business

22. Receipts

23. Fuel $114.40 Check 754

24. Alan: talk to Donnie about buying premium gas

25. Dalton: motion to not reimburse for premium gas

26. Rick: consider adding Seafoam to gas

27. John: we don’t use premium for anything but lawnmower

28. Rick: he should be using the tractor

29. Marion: he uses the tractor on the back side

30. Rick: he should use the tractor as much as possible

31. John T: unless he buys Ethanol-free

32. John T: make a policy- no premium fuel, use Seafoam, use tractor as much as possible

33. Rick: I’d like to see gas cost cut in half; use diesel

34. Chief Hatcher to talk to Donnie

35. Dalton: withdraw my motion

36. John: Ms. Ammons’ letter

37. Need a complete & accurate database for labels

38. 2C Cheryl: NeonCRM costs $400 to merge

39. Labels could be printed from Filekeeper’s database

40. Rick: when can we get the letters out?

41. Dalton: if you send me a spreadsheet, I can do it from work, just need the letter

42. Rick: mail by Monday?

43. Dalton: probably Tuesday/ Wednesday- print labels, stuff envelope

44. Lockbox receipt for office keys per Chief Hatcher’s suggestion

45. To Rick Hudnall: $100.27 check 755

46. Cemetery: tribal members can cut it & be reimbursed

47. Elder Dan: trustees are going to do what they can

48. Chief Hatcher: check from attorney received & deposited

49. 2C Cheryl: if I don’t have access to the most recent Access database, how can I change things?

50. Dalton: email Starla a copy of the changes

51. Let each other know when you’re each using the database since only 1 can make changes at a time

52. Let’s set up a committee

53. Chief Hatcher: want Starla, Cheryl, Dalton, Marie, Patty to get together

54. Committee Reports

55. Buildings & Grounds: Glenn

56. Put in a request for donations at Lowe’s

57. Does the insurance policy cover bleachers?

58. Chief: keep doing what we’re doing

59. Dalton: so bleachers can be used?

60. Chief Hatcher: yes

61. Glenn: I’ll finish buying materials

62. Owen’s Steel said they’d lower the price on metal

63. Marion C donated some

64. Paint for posts around circle; need 4 colors

65. Rick: motion to give $450 to buy paint; Alan seconded

66. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

67. If it costs more, Glenn will buy it

68. Weed eat 9/14

69. Refer to office calendar for work days & other events

70. Arts & Crafts: nothing to report

71. Pauwau: Susan

72. Budget

73. John T: why are we paying members to work during the Pauwau? Inconsistency in how we treat people

74. Dalton: let Chief Hatcher/ Susan talk to them

75. 2C Cheryl: it’s like asking Susan to do feathers for free

76. Marion: no issue with paying people for Pauwau work

77. Chief Hatcher: we’ve paid members to do work (ex: Wayne & spraying for ants)

78. Make a policy; it comes out of their pocket

79. Marion: if you pay one, you should pay them all

80. John T: put on mind for January

81. John T: signs for 501?

82. Susan: would like a flashing sign; probably $500 to rent

83. Marion: signs are expensive & letters fall off

84. Dalton motioned to accept; Susan seconded

85. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

86. Rick: Cub Scouts will be here 10/22-29

87. 2C Cheryl: just camping; no canteen?

88. Rick: you can; going to do a Saturday dinner

89. Marion & others to do things with them

90. Rick: food donated for them; help from Wayne & Richard T

91. No cost to them except electric

92. Marion: will they build campfires at night?

93. Rick: I told them not in the either circles

94. Rick: they can fish; catch and release

95. Interested in a nature trail

96. Program Book: broke into 3 sections with corrections

97. Rick motioned to accept book with changes; Robert seconded

98. Robert-yes, Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

99. Governing Body to send Michelle or Susan list of 4 names by 10/30

100. Outbrief: 11/9 @2pm, @ El Cerro Grande in Conway, possible 10% discount

101. If you can’t be there, send an email with positives, negatives, corrections, solutions

102. Vendors: $755

103. Ads: $2200; 3 people to remind; $2750 total

104. Dalton: provide a link on our website to businesses

105. Camping: $105

106. Chief Hatcher

107. Ed Piotrowski will hopefully be here that Friday to do the weather

108. CNB donated $500

109. Drum: Rick

110. Played 2 weeks ago in Sumter National Guard for Unity Day

111. 9/18 for CCU Cultural Celebration

112. See 2C Cheryl for parking passes

113. 9/28: for Carson with Scouts

114. Campground: John T

115. GSWS: price for pump station & grinder: $5875

116. Glenn: can probably put meter base together for $500

117. John: probably $7000 total

118. Waiting for Rural Tourism Zoning to see how it affects us

119. Chief Hatcher: think we should do it after Pauwau

120. Can probably get a personal loan for $5000 if people help with donations

121. Glenn: and eventually put in a bath house

122. John T: brother & I talked about moving parents into cemetery, but there are no guidelines

123. 2C Cheryl: trustees need to make a policy

124. Sellers may have issues

125. Chief: usually trustees say if it’s ok

126. Property belongs to us; Council decision

127. John T: who do I request permission from?

128. Chief: through Elder Dan

129. Elder Dan: and then to rest of trustees

130. Rick: how much trouble can Hilda give us?

131. 2C Cheryl: not much

132. Rick: what if trustees say no; can Council override

133. 2C Cheryl: keeping Hilda in the loop goes along with the judge’s order

134. John T: so Hilda would have to challenge us in court?

135. 2C Cheryl: or she could sue, but she has no claim to the cemetery

136. 2C Cheryl

137. Genealogy Class with Patty, 1-3pm Sunday

138. Florence panel: No Blame, no shame- race relations

139. Santee Pauwau 9/21; PAIA 9/28

140. NeonCRM still in progress

141. ICWA Taskforce: need Native foster parents

142. Idle No More round table: 10/18: Lancaster, 2-4pm

143. Lunch & Learn, 12-1pm: Lawson’s journey through SC

144. Land Claim Proclamation: read in meeting

145. On Facebook: [www.facebook.com/groups/45...](https://www.facebook.com/groups/454146981313761/permalink/2561725260555912/)

146. Close to 40 documented tribes in SC

147. Chief

148. Introduced Dr Tracey from HGTC

149. Recognized Jeanie W; condolences on sister’s passing

150. IWA Luncheon 9/14

151. Alan bringing food

152. Asked for a fire circle 9/14

153. Marion: I have no supplies

154. 2C Cheryl: I have them

155. Marion will do it

156. Special healing ceremony for Jeanie

157. Have asked Jeanie to do parades

158. 10/17: Address MB City Council, 4:30pm

159. They are writing a proclamation to recognize us

160. Consider changing Columbus Day to Indigenous Day

161. Asking Chicora to do it too

162. 10/19: Meeting in Catawba about CMA, 11am

163. Limited seating

164. Donnie said we need to treat for ants before Scouts come

165. Donnie has a leak on top of his trailer; going to bring bucket truck here & try to fix it

166. Elder Dan: Aynor HoeDown; Carson is performing

167. Susan: Gate, we are doing prepaid tickets this year; 20 total

168. 2C Cheryl: Making donation for Jeanie W to help offset ad cost

John motioned to close the meeting; Alan seconded.

Meeting adjourned at 9:20 pm.

Respectfully submitted by Michelle Hatcher on 9/25/2019 at 12:53 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
