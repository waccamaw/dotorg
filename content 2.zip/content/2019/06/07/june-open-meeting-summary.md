---
layout: post
title: "June 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/06/08/june-open-meeting-summary.html
post_id: 5649714
custom_summary: false
summary: ""
date: 2019-06-07T19:00:00-0500
lastmod: 2019-06-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/06/07/june-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 6/7/2019  held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Alan, Susan, John, and Marion present. 2C Cheryl led the meeting. Elders Ronnie and Avalene present. 2C Cheryl present.

2. Financial Report

3. General Fund: $7,795.33

4. Building Fund: $450.55

5. Online Votes

6. 5/24: Accept May meeting summary with change

7. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-abstain

8. 5/30 Proposal SHH-05-30-2019-001: Give donated van to Donnie

9. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

10. 5/30:  Exception to policy: JR-HH-05-03-2019-001: Appointment of Waccamaw Genealogist

11. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

12. Old Business

13. Donnie’s AC

14. Duct work still needs to be done

15. New Business

16. Receipts

17. Susan H: Fishing Day Supplies: $55.97 Check 747

18. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

19. Fuel: Sunhouse: $81.17 Check 748

20. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

21. Glenn C: Business Cards/ Dance Circle: $538.03 Check 749

22. Committee Reports

23. Buildings & Grounds: Glenn C

24. Work Day 6/8 weather permitting

25. Plumbing to be done

26. 2C Cheryl: move fish food

27. Put it in trailer

28. Glenn C: could gain more moisture

29. 2C Cheryl: need a solution to keep rats  from getting into it

30. Glenn C: ziploc bags would sweat

31. Susan H: we’ve had the food for  years; we should dump it

32. Glenn C: Donnie thinks that’s what killed the  fish

33. Marion C: Dump it in woods

34. John T: dump it in grass

35. John T: need a mandate that all food in the refrigerator is properly contained

36. 2C Cheryl: and in freezer; deer meat needs to go

37. Arts & Crafts: Susan H

38. Found more related emails to send to Tribal Council

39. 2C Cheryl: talked to Chris H, who said he submitted application

40. Told him that Council was taking it over

41. Susan H: his and Jeri Hunter’s

42. Send applications in with pictures of items: must be accessible & not have to download an app to open the file

43. 2C Cheryl: any more art classes?

44. Susan H: thinking about it; Mathea discussed doing moccasins

45. 2C Cheryl: received an email from Franklin Ellis requesting artisans to teach Intercultural and Inclusion Student Services (IISS) group: Nov 14 at 6pm

46. Dalton: put on Facebook requesting artisans; changed to just email

47. Email from Mr Ellis  send to Michelle to send out

48. Michelle: Make Susan th point of contact?

49. Susan/ Alan: put her email down

50. Alan F:  will build a relationship with them if we can do it; artisans should be tribal members

51. 2C Cheryl: HGTC  declined our fundraiser at this time; the fall is really busy for the school

52. John T: do applications (art) go to Susan?

53. Susan H: technically to 2C Phil

54. John T: make Susan the point of contact for Tribal Council on art applications

55. Pauwau: Michelle/ Dalton

56. Sell Tidal Wave Tickets

57. Susan H: extended  through Tuesday, 6/11

58. Dalton/ 2C Cheryl: reconcile and do again

59. 2C Cheryl: HGTC fundraiser: sent full proposal; it was reviewed

60. They can’t commit at this time per email

61. Received call from Human Resources: Diversity & Inclusion Council

62. They want 2C Cheryl to attend the meeting

63. Sounds like they will move us in  slowly

64. Continue selling ads

65. Looking for volunteers for Pauwau

66. Submit stories/ pictures  for next year’s book today

67. Meetings are the second Thursday of each month at 6pm, unless noted otherwise

68. Lindsey needs Photoshop:  $30/ month

69. Susan H: saw one for $10/ month for 1 PC

70. Need authorization to do it and for 3-4 month increments (stop/ start as needed)

71. Dalton motioned; Marion seconded to authorize purchase for 3-4 months at a time

72. Glenn C: annual plans; paid monthly

73. Susan H: Business one is $80/ month per license with annual plan

74. Dalton H: Lindsey is willing to pay half

75. Dalton H: see a business plan that is $33.95 paid monthly, 1 license

76. John T: add to PW budget

77. Dalton H: need a credit card reader: square or something similar

78. Glenn C: Square is universal

79. John T: how much is it?

80. Glenn C: item is free; transactions are 2.75%

81. Ideally, we would need 3 units

82. Dalton H: motion to link them to our main bank account; Susan seconded

83. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

84. Susan H: move modem back to center office instead of copying room

85. Internet doesn’t reach well to porch/ Chief’s RV spot

86. Glenn C: metal roof also interferes with reception

87. Charles H:: can we get a larger tower?

88. Glenn C: repeater: $30-1000,  depending on tier

89. 2C Cheryl: $85/month

90. Glenn C: that’s tier 1

91. Move modem to window; Glenn C thinks he has a repeater we can test

92. Drum: Marion/ Alan

93. Nothing new

94. No practice

95. Drum needs to be re-stringed: 1/2 in. at 90-100 ft

96. Glenn C: $60  for 70 ft; need it but suggest waiting

97. Dalton H: will put $20 towards it

98. Census 2020: Susan

99. Went to symposium; they want to hire Native Americans

100. Recruiting for many positions

101. They are temporary jobs with flexible hours

102. Looked at 2010 census to see how we answered questions

103. American Indian, Waccamaw Indian, SC

104. Send email and make it consistent

105. American Community Survey (ACS): 24 pages, but you may not need to fill them all out

106. Fill out information for everyone in your household up to 9 people

107. Goes out randomly- please fill it out- Susan will help you

108. uscensus.gov/mytribalarea

109. 2013-2017:: population: 52 in SC

110. Shows Male/ Female, Age, Employment Data

111. Important for Medicaid, number of representatives in Congress

112. Response outreach mapper: makes it easier to identify people in small areas

113. 2020: can do on PC, paper, and by phone

114. They are targeting areas that don’t get counted as much

115. Got maps & need to mark areas where it is predominantly Native American

116. Put Waccamaw Indians SC on forms

117. 2C Cheryl

118. CoC Rick wanted to allow scouts to camp for free as a pilot program

119. They will provide their own port-a-potties

120. Susan: need disclaimer on form about liability

121. Suggest running a canteen out of the office

122. Health-conscious  food, gatorade

123. Donnie has keys to van per Chief Hatcher

124. NeonCRM: program to sync with Quickbooks, Database

125. Create projects, volunteer lists

126. Publish to website & Facebook,  send mass emails

127. People can make membership  fee payments

128. Not limited to the number of users, but only 10 can be on at once

129. $110/ month ($1320/yr)

130. Elder Doug  donated $360

131. Chief Hatcher agreed to 30/month

132. 2C Cheryl & Marie agreed to $25/month

133. 2C Cheryl motioned to use Neon CRM for max of 1 year (paid  for) & if it sustains itself/ people use it, tribe to pick up cost; John seconded

134. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

135. Use a prepaid card for payment

136. Susan suggested adding the Neon cost to the building fund

137. Glenn C suggested creating a new bank account

138. Elder Standingbear: if I write a check for the Buildings & Grounds fund, where  does it go?

139. Michelle: to the Buildings & Grounds account if it’s in the memo line

140. Doing a phone conference on 6/11 with Mr. Hawkins  for more information

141. Marion C

142. June 22: Summer Solstice, 6:06 am sunrise

143. Susan H: Can we plan the next  2?

144. Marion C: sent letter to CoC Rick

145. Glenn C: they’re on the calendar here in the office

146. Resolution: JR-HH--05-03-2019-001: Appointment of Waccamaw Genealogist: 3rd reading

147. Fix spelling & page layout errors & reprint

148. John-yes, Dalton-yes, Susan-yes, Alan-yes, Marion-yes

149. Charles H: good job to Council

John motioned to close the meeting; Alan seconded.

Meeting adjourned at 8:54 pm.

Respectfully submitted by Michelle Hatcher on 6/27/2019 at 1:19 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
