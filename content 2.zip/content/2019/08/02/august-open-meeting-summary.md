---
layout: post
title: "August 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/08/03/august-open-meeting-summary.html
post_id: 5649715
custom_summary: false
summary: ""
date: 2019-08-02T19:00:00-0500
lastmod: 2019-08-02T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/08/02/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

*Transcribed from a recording made by Dalton Hatcher*

Tribal Open Meeting Summary 8/2/2019  held at the Tribal Office in Aynor, SC

1. CM’s Robert, Susan, John, Marion, Alan, 2C Cheryl (Rick), and Dalton as ACoC present.

2. July Meeting Summary

3. Susan motioned to accept; Alan seconded

4. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-yes, Dalton-yes

5. Old Business

6. Donnie’s Ductwork

7. John: expensive to do, AC is cooling

8. Marion: less efficient

9. John: when they put the new AC in, they left old ductwork, just mashed it together

10. Dalton: out of curiosity, by mashed together, do you mean damaged or forced to work?

11. John: forced to work

12. Chief Hatcher: can you unmash it?

13. Dalton: then it would stop working

14. Dalton: they mashed the two systems together

15. Alan: the ductwork got squeezed down

16. Tabled for now

17. New Business

18. Receipts

19. $158.40

20. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-yes, Dalton-yes

21. Chief Hatcher: one month?

22. Susan, others: there was something on the mower

23. Cheryl: $91.44

24. Chief Hatcher: the parts should be taken care of by the card

25. Dalton: yeah, you’ve already taken care of that

26. Committee Reports

27. Buildings & Grounds: Glenn

28. Bleachers cut up last month

29. Working on donations for metal

30. Weedeating tomorrow

31. Have finished firewood

32. Arts & Crafts: Susan

33. Nothing new

34. PW: Dalton

35. Request funds to fix bleachers

36. Susan: already taken care of; he’s cut them in half

37. Marion: the money has been allocated; $350

38. Chief Hatcher: is that going to be from B&G?

39. Susan: general, PW

40. Square has arrived; need to be setup so we can accept credit cards this year

41. Susan: I’ve been putting them on School Day papers

42. Submit stories to us someway by 8/15 for this year’s book

43. Get ads to us by 8/15 for this year’s book

44. 2C Cheryl: would it be inappropriate to sell an ad to Rad Dew’s when we have Hog Heaven out here?

45. Dalton: no

46. Chief Hatcher: do you have anyone calling the existing ads to see if they will renew?

47. Dalton: Who was handling that this year, do you remember? I will try

48. Dalton: Susan, do you remember the ad prices right off the top of your head?

49. $50: business card

50. $75: 1/4 page

51. $150: 1/2 page

52. $250 whole page

53. I think we were charging $25 for small In Memoriam type thing

54. Meetings are the second Thursday at 6pm at the tribal office

55. so 8/8 this month to make suggestions, tell us what we’re doing wrong, etc

56. John: FB marketplace, place in MB selling Port-a-johns used for $50

57. If we had our own, could we get them serviced, as opposed to them bringing out & servicing port-a-johns?

58. Alan: willing to bet you take in the service them and worry about leaving them in the sun and repairing them, you come out better if we aren’t going to be using them all year long and the first time someone uses one, you might as well plan on getting them pumped because you aren’t going to be able to walk into one as hot as it gets in the summer

59. Dalton: do you remember how much it costs to service one?

60. Susan: I think, well, for the whole time we use them, it was about $450 for 4 days; that’s 2 pumpings; he gets us actually 5

61. John: was just curious; sounded like a good deal

62. Dalton: it would be a good deal, depending on how much it cost us to pump & maintain them

63. Do you have a (inaudible) for vendors?

64. Susan: we have people come in last minute looking for a spot

65. Marion: Nov 1

66. Alan: unless they want to do school days

67. Susan: what size do you need- 10x10, 10x20?

68. Probably 2- 10x10’s

69. Susan: I’ll put you down for that

70. John: campground

71. Glenn & I did a little running around here looking for information about what we needed to do and first thing, we don’t need a business license. We just have to present our 501c3 paperwork and state exemption if we have it. Otherwise, we have to pay 3% on what we made

72. Alan: is that the county?

73. Glenn C: yes

74. Chief Hatcher: talking about (inaudible)?

75. Glenn C: yes

76. Susan: cool

77. John: currently our grounds are zoned forced agriculture

78. Glenn: we could have a campground out here for how many sites?

79. John: we have 10+2

80. Glenn C: I’m talking about what they require; so many to be non-commercial; I think it’s like 20 or 30

81. John: to open a commercial campground, we’d have to be rezoned into something new going into their system, known as a destination park. That would take 3-4 months going through the steps getting rezoned; requires a site plan, requires sewage disposal for each site

82. We don’t have sewer and we’d have to get a septic tank for each site

83. If we could get it rezoned, the cost for that license would be $250

84. Next alternative is probably the most advantageous to us; it’s called rural tourism

85. He said it would be 2-3 months before it gets through all the steps it needs to

86. Glenn C: 3 weeks

87. John: then we wouldn’t need to get rezoned; we could just apply for rural tourism, it’s in process, which allows us, and he wasn’t sure when he was telling us, 3-4 months of the year that you can use that zoning

88. That would only cost us $100

89. The question was: we don’t know all the ins/ outs of that process and whether we would have to have sewer at that time is debatable

90. We didn’t talk to anybody over there about getting a waiver

91. I was thinking about that after-the-fact; we don’t know that we can make any money doing a campground; I was thinking we could apply for a waiver as far as the sewage part goes & grant us some leniency &  let us use our current facilities, but there are so many groups involved & we don’t know that yet

92. Some of the requirements for a campground:

93. Hard-packed roads for fire trucks

94. 20ft access so they can turn around

95. Electrical and water layout

96. One of the biggest things we’d have to fight is DHEC, who controls the sewage disposal

97. Right now, if you have city water, I mean city sewage, they  wouldn’t let you allow you to have a septic tank installed

98. City sewer stops on the other side of the road over there & we went to a water & sewer man said he would write us a letter saying we don’t have sewer on this side of the road; however, if we want to get hooked up to that, they can do it

99. So we’re in a grey area as far as public sewage access

100. They’re supposed to contact us about coming out here to get us a grinding & pump station to go over there, so we don’t know about that & I don’t think he probably called you back yet

101. So, the biggest thing is the sewage disposal; we have a little more to do on that, but if we work towards this rural tourism goal (which will probably be a couple months out), and we don’t know how that works- if we can do 3 months this year, do 3 months next year, rollover to the next year and put them back-to-back or if it has to be the same 3 months each year

102. If we went to a commercial sewage system, hooked into the public sewage system, the guy said it would be $50-70,000.

103. The septic tank was $3500 or so

104. Dalton (laughing): what if we give them like a bedpan when they roll up?

105. Glenn C: then again, talking to the guy, he said “I can’t tell you to do this, but…”

106. John: Yes, he seemed to say you could do things and get away with it

107. Glenn C: he said it wasn’t like they would be out there investigating, but he’d give us a price of hooking these two buildings up on the same one and the septic tank would be freed up

108. Why can’t you use port-a-potties out there?

109. That’s only temporary

110. John: I mean, you can’t have a holding tank, but I don’t know if Native Americans on their own grounds can do separate from what DHEC says

111. Chief Hatcher: they’ve been doing it for 20-something years

112. John: I mean, yeah, we could probably skirt the edges a little bit possibly, but I think you know, if you want to go with this rural tourism thing if we could a waiver and go plea with somebody and say we don’t think we can make any money doing this and we can’t afford to spend $50-70,000 on a dream, so I don’t know if that’s a possibility to talk to him about that

113. If we didn’t offer sewage disposal as part of the campground, why do you have to meet their regulations? I don’t understand that, maybe they just assume that. How high is it at this end as opposed to that end?

114. Glenn C: what do you mean higher?

115. Alan: elevation-wise

116. Glenn C: bottom of the second step is about 3.5ft to middle of the field out there between the dance circle & fire circle

117. I presented it to Council when you first started talking about moving the circle to the back, saying it’s higher. And it is higher, by 0.5-0.75 in. than our dance circle now, so there wouldn’t have been a benefit there, but if you can bring up those maps, I still have mine. I can make copies for next month if that matters to you

118. Alan: the septic tank is servicing the trailer and this building here

119. Susan, Glenn: it’s two separate ones

120. Alan: would they be enough to handle those 14 sites?

121. Glenn: what we’re talking about is getting us our own grinder station and pumping it up to sewage of these buildings

122. Chief Hatcher: which he says he can’t tell you to do that and get away with it

123. Glenn C: we actually asked him this stuff and he said I can’t tell you that you can’t do that

124. Chief Hatcher: How much difference is bringing it across the road?

125. Glenn C: he hadn’t priced it yet

126. John: the question on that too would be how much is it and would they add it to the monthly bill in having it done

127. Alan: but most of them, if the same person furnishes both of them they usually charge you your sewer bill by whatever your water bill, water usage

128. Glenn: correct. See, we will be paying more sewer when we have campsites that don’t offer sewage. We’re realistically paying for it up here. But John, your question is, bringing it from here to there, they will probably finance all that, for us to do commercial-wise, they have nothing to do with it

129. Chief Hatcher: you’re still going to need $10,000 or so to bring it across the road, but we’ve done this before

130. Glenn C: right

131. John: we’ve talked about it, but we’ve never really gotten a price. I think what Chris said originally was somewhere in the $5-6,000 range.

132. Glenn: but if they could put it in our monthly bill and finance it for us

133. John: so that’s a possibility; we’re still working on it. I mean, they do have regulations as far as how big each site has to be that you park at I think it said 35ft across; I don’t think we’re 35 ft on most of them. We’re probably 30-33 ft. And it’s supposed to be like 1600 sq ft per site, but we can go out as far as we want in front of the site to make 1600 sq ft, so I don’t think that would be a problem

134. There are a few things to work out, but I think the first thing is to see how this rural tourism goes

135. Everyone was helpful there in Conway

136. Glenn C: there was no negativity there at all until we got to DHEC

137. John: DHEC was a little harsh, I mean not harsh but not overly concerned with our needs

138. One interesting thing: we did meet a gentleman in zoning; I think his name was Gary McCarsky (SP?). He’s a scout leader in Georgetown & his scouts are very deep into Native American culture with dancing, with drumming, with all sorts of different things. And they was supposed to contact us

139. Glenn C: well, no, he was supposed to tell the lady who actually does that

140. John: Anyway, I thought it would be a very good connection for us to deal with these boy scouts because they do a lot of different things

141. Glenn C: get him to bring his troops in here to help us out

142. John: that’s what I mean

143. Glenn C: we actually talked more about that

144. John: that’s all I have for the time being on the camping

145. Glenn C: the rural tourism is really based on the big farms for the Christmas programs and stuff so they can make some money on the off-season; they base it on their crops, 3 months is the limit they put on it, so that’s where that’s coming from

146. John: it sounds like they’re trying to help farmers and things so they may be a little less rigid on their requirements, I’m hoping

147. Glenn: but it will be a permit based every year, $100/year

148. 2C Cheryl: so are we in Aynor, city?

149. Glenn C: no

150. 2C Cheryl: we’re not, so we don’t have to worry about anything Aynor says

151. John: the only thing they said was if we wanted to get rezoned, they would have to interview people within 500 feet of our property about it, whether they would have a problem with it, which is not many people

152. Dalton: yeah, it’s like 2 houses, maybe

153. 2C Cheryl: that eliminates a lot of people

154. Glenn C: that’s not a lot of people, but then of course, sign’s going to go up

155. 2C Cheryl: yeah, that’s why I was asking, because I know Aynor has regulations on signage & how far (inaudible). I did look at, last year when we were talking about motorcycles and parking, it had zoning & structure, as well as structuring for 501c3 to not lose that- doing it as two separate entities called brother/sister- it has to have a structure like an LLC with a board (doesn’t have to be but 3), funds (for-profit) passed through go to the non-profit through sustainability of projects (furthering developing grounds, going towards a program that fits within our mission statement).

156. Or it can be done as setup as a parent/subsidiary. So the nonprofit is the parent and the for-profit is the subsidiary. The only thing we have to worry about is we don’t want to be too successful because if you’re too successful in your for-profit, you risk losing your nonprofit

157. Glenn C: well, let’s say you pay your people who come out and tends to it, can you take away from the profit that way?

158. 2C Cheryl: well, what I was thinking, the scouts again, they are always involved in Native American, the whole premise, it was Charles B Smith, who was actually Native American,  help founded the scouts something like 110 years ago, so at the point where we’re at, we could be doing what camp coker (?) (Society Hill) routinely that stays within our mission especially if we’re supporting the scout program that teaches them Native American culture and it would be right in where we would only be doing nonprofit with the community with developing and teaching the scouts

159. John: Actually, I want the scouts to come teach us Native American culture

160. 2C Cheryl: they learn a lot

161. Glenn C: especially the Eagle Scouts

162. John: they said when they got to the Order of the Arrow, they had to know 2 songs in Native American, they had to do these dances, they needed to tell two fables or stories from Native American culture. It sounds like they’re really into it. I mean, you could have them at the Pauwau; they have nationally-ranked drummers

163. Chief Hatcher: I have a question. We’re talking about a temporary thing here, but eventually a 24/7 thing, right?

164. Glenn C: that would be after we get the money up to do the commercial thing

165. John: it’s kind of hard to meet the regulations they have to be a full commercial operation, whereas if we could do the 3 months to see if it’s viable, which is my thought process, we could get our feet in the water and see how it works, and then if we can skirt some of the regulations by only doing 3 months/ year, we might be able to do that

166. Dalton: start banking the income

167. John: when we can say it works, then we can proceed. It will take a little while.

168. Chief Hatcher: this little thing on Hwy 90, Susan says they rent them out for $75/ night

169. Glenn C: and they’re about full too

170. Chief Hatcher: and stay pretty full but they do have sewage. Now we might could team up with somebody that would work with us for 10 years, get setup and leave it to us or find a grant

171. 2C Cheryl: there are rural development loans, RDA’s you can apply for; I can look at that, I’m not sure how it works for nonprofit; It’s a lot of hoops to jump through for an individual

172. Glenn C: my thoughts were if we can pay this small fee to get it across the road, go commercial, then we don’t have to pay the fee to get it back across the road

173. Chief Hatcher: that’s the very thing I was thinking; if we get it across the road, we can do what we want with it when it gets here and I don’t know that we have to comply with the county ordinance- it’s possible that we do, but it’s also possible that we don’t.

174. Glenn C: if we get sewage, DHEC has nothing to do with us

175. Chief Hatcher: that’s what I would do then and let them prove us wrong

176. Glenn that’s basically what he said, but he also said they wouldn’t be out here inspecting

177. Susan: did you find out about insurance?

178. John: later; we can get it if we need it

179. 2C Cheryl: maybe we could apply for the Accommodations Tax grant again

180. Dalton: we probably wouldn’t have a sales tax; we’d probably have a hospitality tax

181. Glenn C: no, all of that would be exempt

182. Dalton: perhaps make a commercial committee

183. Susan

184. Received a call from Ms Joan about sending out a letter to all tribal members about membership dues (read in meeting); asked for comments

185. Audience: it’s very good

186. 2C Cheryl: it’s very thoughtful & it’s what needs to happen; at least given the option, most people are going to want to be given a notice

187. Alan: could you send a letter this year and a card each year after?

188. 2C Cheryl: well, it won’t be that way, NeonCRM has an invoice and it has been updated, so it can email an invoice to them or it can send a form letter; they can even login to the site and make a one-time payment with their debit card and update their information; that’s the purpose of getting this setup

189. We’re inputting data now and as we go through, making sure it’s correct; some people have already received an email to setup their password

190. The letter would be a good introduction

191. Susan: I think it’s great; she’s offered to pay for it and send it herself

192. Ms Joan: I didn’t mean to interfere with anything that was planned

193. 2C Cheryl: no Ms Ammons, you’re timing is actually perfect

194. John: I think it’s good that it comes from a tribal member & not tribal government

195. Dalton: effectively you already have one, but should we form a membership committee to deal with all of the files, cards, federal recognition, etc…

196. 2C Cheryl: where things are at, it’s one of the biggest components of federal recognition; you have to meet their criteria, but membership is just as important; a membership committee later would be a good idea, like John wanted to be the membership renewal coordinator, working with the filekeeper, working with Michelle who keeps track of membership dues

197. Dalton: seems like that would basically be the core of a committee right there and it overlapping with the federal recognition committee is fine, like Buildings & Grounds overlaps with Pauwau quite a bit. So overlap is not a problem. And the membership committee going forward could look at the people looking to come in, telling them they need all of this stuff and make sure they get it right before the file comes to the table

198. 2C Cheryl: that overlaps with the genealogist that would be need to be part of the membership committee as well because you’ll be working on files partly for federal recognition

199. Susan: yep

200. Dalton: so I’d like to set those 2 committees up (membership & commercial) if we can find the people to staff them

201. 2C Cheryl: but you know it’s going to be the same people, but then you have somebody whose in the audience and is motivated to take to take the time to write out the letter. I think that part of it, we’ve got to bring people outside of Council and the people that are just showing up because there are people who obviously want to do things. So why not have members who want to do things be members of the committees as well? Well, like Pauwau committee, ‘cause anyone who is voted in can be on that committee

202. Alan: do we need Council approval on that letter?

203. Susan: we haven’t got back to that yet; he was backtracking

204. Dalton: I’m saying that before we send that, we need to deal with a lot of other things, don’t we?

205. Marion: we are allowing an individual member to voice their opinion to the tribe and just make a motion to allow her to send that letter; I don’t think this needs to go out with the federal recognition; I think this just needs to be a letter that goes out voicing her opinion to other members of the tribe

206. Alan: Because of the first thing on it, that’s why I thought I needed to make a motion to approve for her to send it out because she said she had Council approval and I would make the motion to allow her to do it

207. Chief Hatcher: One thing I think Council has got to start doing is designating people in charge of different things

208. I know that Starla has been named as Filekeeper

209. I still don’t know who has been named to keep track of dues; as far as I know, it has never been made official by Council, but there should be someone that everyone knows to call when they have a question on that and it should be an order written by Tribal Council

210. As far as  the letter is concerned, I think it’s an excellent letter, but when you authorize her to do that you are automatically authorizing her to address it to everyone in the tribe snf you have to think about that. I don’t think there’s an issue with it and I recommend that you do it, but I’m saying that things are not completely covered on the surface of the letter; you have to think deep.

211. Dalton: I know; I was about to get into that

212. Susan: well, why don’t we that and include that in the newsletter?

213. Dalton: do we have someone who wants to do a newsletter?

214. Susan: I retired a couple years ago; I did it for 13 years

215. Dalton: well, we have a motion, do we have a second?

216. John: I guess the question is; I’ll second the motion and then we can have some discussion

217. John: If she’s working under the auspices of the Council and sending this out with our approval, she would be entitled to the records

218. Dalton: there’s an easier way we could do it, I think

219. Alan: couldn’t you just print out the addresses on labels

220. Glenn: what if we use her letter and we send it out from filekeeper

221. 2C Cheryl: can we do one thing on that letter: add a bit of information of what the person should be doing to contact

222. Ms Joan: I have them contact Michelle with an envelope; if you have an envelope right there, makes you more apt than having to hunt for an envelope

223. 2C Cheryl: I understand what you mean: if I have to hunt down an envelope and address it, stamp it, it may sit in my car for 3 days before it gets mailed or leave it in my visor and find it 2 months later

224. Dalton: If I remember correctly, it’s something like 300 people you’d be looking at sending letters to

225. Ms Joan: that’s $150

226. Dalton: yeah, for the first envelope, but if you include a second stamped envelope

227. Ms Joan: no, just a second envelope

228. 2C Cheryl: but we also have households, so it could be a little less

229. Chief Hatcher: are you proposing to pay for it as well or just do it?

230. Ms Joan: I was proposing to pay for it

231. Chief Hatcher: I thought combining it with the newsletter was a good idea; you sign the letter, we print it off and we insert it in the newsletter and cover lots of things in the newsletter

232. Ms Joan: I don’t care; we just spend so much time discussing this

233. Chief Hatcher: you’re right

234. John: only thing with the newsletter is that it’s going to take time; we could get this out in a month. If you wait for a newsletter, who knows when that’s going to happen

235. Marion: I agree

236. Elder Becky: I think the letter seems more personal than the newsletter does

237. Chief Hatcher: I think you’re right about that, everyone got one in their own name; but then you still have a problem because you need some sort of a mail merge thing to print the letters; you need labels but the letter’s going to be “dear someone;” it’s still not going to have anything. It will be a blank letter; draft letter

238. 2C Cheryl: there’s a way to do that through mail merge; it will populate the fields and add salutations

239. Dalton: you just need access to a database; the question becomes which database you want to use until you get them merged, but what I would suggest is we get the file you used to create the letter and send that file to Susan or whoever will be doing the database and have them do the mail merge so that it’s got the salutations; they can, at the same time, print off labels, and we get some people in here to knock out stuffing the envelopes

240. John: if you get me the labels, letters, and envelopes, I will stuff the envelopes

241. Dalton: Need to use the most current database until they are all merged

242. 2C Cheryl: do we send the letter to expired cards?

243. Glenn: that’s more money for the tribe; more people

244. Dalton: we’ll discuss it

245. Chief Hatcher: the Executive Branch is meeting once a week to resolve some issues, so let us have our meeting next week

246. Dalton: include me please, so I can help Cheryl’s database sync with the others in Drive until we get NeonCRM

247. John: I added to the letter:

248. Please be aware dues have been occurring since August 2013

249. Please make checks payable to WIP

250. Anyone have a problem with that?

251. Dalton: I’m fine with that, but it’s her letter

252. Ms Joan: whatever Council thinks is appropriate

253. And use “effective”

254. Dalton, with those changes, there’s a motion and second to sending the letter

255. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-yes, Dalton-yes

256. 2C Cheryl

257. Monthly Work Day for Membership: working office so members can come pay membership fees, update information, etc…

258. Propose that the ID machine be kept here, the files be kept here

259. Puts boundaries on members- lets them know office is open on X day, during Y hours

260. John: you want a meeting in perpetuity for membership

261. 2C Cheryl: yes, a work day, the same day as the work day for Buildings & Grounds

262. Patty B: get  a landline out here with voicemail to make it easy for folks

263. Susan: our line is forwarded so someone answers it

264. Dalton: so we’d need to add a phone here or get a Google number

265. Patty B: I’ll create the details of the administrative committee

266. Dalton: I’ll create the details of the membership committee

267. 2C Cheryl: I propose since Marie has been through files the last few months, that she chair the membership committee

268. John: present them next month

269. Application Process

270. Looking at setting up process for honorary to become to full member

271. Give them a certificate until they become full member

272. Council won’t interact with the file until the membership committee submits it to them

273. Chief Hatcher: 3 out of 4 executives would have to agree before sending file in

274. Thought we should put a copy of their certificate in their file and track their volunteer hours their

275. 2C Cheryl: we can use NeonCRM to track it and donations

276. John: honorary: that would include spousal members?

277. Chief Hatcher: yes, and after today, any renewals or new spousal members will receive certificates

278. Indigenous Women’s Alliance Luncheon

279. 9/7

280. Request Council permission to change our Autumn Equinox to 9/7 or do an additional fire ceremony that day; Robert has agreed to be out here that day

281. Women Drum and fire ceremony

282. Particularly because we had a tribal member who lost a sister recently

283. John: so you want to do the fire ceremony on Indigenous Women’s Alliance day?

284. Susan: we can still do both of them

285. Robert: we don’t have to do the fires on the same day; we can do them on two different days

286. Alan: 8/21 is Santee Pauwau

287. John: can we do one on 8/22?

288. Robert: yes

289. Chief Hatcher: Marion, I’d like to know what you think about the files and the executive branch

290. Marion: I thought I had been; I agree with it

   1. 291.

Chief Hatcher: how about you Robert?

292. Robert: I agree with it

293. Chief Hatcher: well, apparently I offended a bunch of people when I wrote an email; I apologize for my wording in that email; what I said was that unless you are tied to core (and I don’t care what your genealogy is; I said that and I meant that- I said that and I hurt some people’s feelings) the truth is the truth, if I can’t send it to the BIA, I don’t care what it is. It doesn’t mean I don’t care about people; it just means that the genealogy does me no good.

294. Patty B: that’s how I took it; the genealogy was irrelevant

295. Marion: that’s how I took it

296. Chief Hatcher: it hurt somebody’s feelings because I heard about it

297. My intent wasn’t to hurt feelings; my intent was to say I didn’t want to waste her (Patty B) time doing Cherokee, Tuscarora genealogy when it’s not going to do us any good

298. John: point of clarification: according to federal recognition, does the chief have to be a descendant of the dimery settlement or does the chief have to be a core member?

299. Chief Hatcher: the core requirement comes into our constitution, but I have heard stories where the BIA has received petitions where tribes were not mostly core and they do pay attention to that

300. John: so if the chief weren’t core, the tribe could be affected negatively as far as recognition, so there shouldn't be a problem with this particular person that I’m thinking of about his grievance

301. Chief Hatcher: I understand his grievance; I’m not mad at the guy. You can only tell the truth by telling the truth

302. Dalton: It’s not something that we necessarily want; Native Americans are the only people in America who have to prove who they are

303. Chief Hatcher: I plan to talk to that person directly; he said that others made complaints too

304. Introduce Chief Jerry Brown of Cherokees of Tennessee

305. Chief Brown: I would like to see something happen with the land I gave you in TN

306. No one but his family on the land now

307. Chief Hatcher: we can make that land tax-exempt if we had something going on there that we could use as a spiritual event or something like that

308. Chief Brown: I have offered; I am a sanctioned firekeeper; I am a pipe-bearer; I am a healer, I do herbal healing; I could do a fire ceremony on the land in TN and you could make that land a 501c4 to reduce taxes

309. Chief Hatcher: propose we continue to pay the taxes on the land; Dalton seconded

310. John: If we get it to 501c4, can we not give the tax money we would have paid to Chief Brown?

311. Chief Brown: I appreciate the thought, but I do not want it; I have not sought any recognition or compensation

312. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-yes, Dalton-yes

313. 2C Cheryl: my last job was Life Recovery Solutions and we worked with inmates that were repeat offenders, addicts, alcoholics

314. The owner has wanted to or just started to take these men on a vision quest or journey into manhood because most of these young men had not ever passed into manhood; they stunted their ability to move forward when they started using drugs or alcohol

315. He needed a large enough area of land for them to experience a vision quest

316. If that’s available, open it up for that purpose as well

317. Chief Brown: I’d like to meet him

318. I’d like to make a decision as to if I can do what he’s doing

319. 2C Cheryl: he just arranges for the guys to go

320. Chief Hatcher: propose to allow Chief Brown to perform fire ceremony on TN land; Robert seconded

321. John: who would this be open to?

322. Chief Brown: I’d advertise it by word-of-mouth

323. Glenn: will the tribe inherit any cost?

324. Chief Brown: no

325. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-abstain, Dalton-yes

326. Chief Hatcher: would like to extend to other tribal families camping in TN at no charge; Robert seconded

327. Robert-yes, Susan-yes, Alan-yes, John-yes, Marion-yes, 2C Cheryl (Rick)-abstain, Dalton-yes

328. Introduce Jerry Lang of Creek of Georgia

329. Florida Indian heritage Association does 3 Pauwaus/ year, charges $275/ booth, and fill 47 booths, not counting the ones outside of the building

330. 47 inside + food vendors

331. I’m not here to tell you how to do a Pauwau, but if I can answer any questions, I will

332. Introduce Chief Vernon Thompson of Chicora People

333. We charge a $20 application fee; I’m trying to find a way to make it an incentive for those work on files

334. Example, why not give Ms Burns $5 for doing the genealogy and Starla $5 for doing the file work; the tribe keeps $10; they can give it back if they want to

335. Dalton: a counter-thought, and it may be more useful to them, we can compensate them for their work by giving them credit for an in-kind donation

336. Chief Hatcher: there was a law several years back, that we put a letter of appreciation in the file for doing good work and when we do receive money, those people with letters receive a larger percentage of whatever that disbursement is

337. John: my thought would be to pool this money and pay for expenses, such as gas, because you can’t pay them because we have a policy against that

338. Patty B: I say buy new equipment; Marie came here and we couldn’t get the file cabinet open for a long time; I’d rather the tribe keep the money

339. McEntire National Guard

340. 8/23 1-4pm

341. Cemetery in Orangeburg, 1861, marked with stones, shells

342. Was bulldozed

343. People called and I received a call from the AG

344. A criminal lawsuit is stopped by a civil lawsuit

345. Next step is embarrassing them in the media

346. Gave definition of core and non-core and 25 CFR 83.7

347. Susan: I was in Columbia today at a HPV training and Chief Brown & Lang and Dr Painter to get kids vaccinated; the younger they are vaccinated the better the results

348. They will vaccinate them up to the age of 27

349. Through 27, they have to get 3 shots up to age of 15

350. Getting the word out to prevent cancer for both male and females up to age 45

351. Working with Best Chance Network

352. Dalton: ad forms are up here; get one if you need one

353. Chief Brown: what is your relationship with the local school system here?

354. Susan: pretty good with Horry County, Georgetown county, Florence County, Marion County

355. Chief Brown: Give the ad form to the school kids, full spectrum, k-12, and let them sell

356. Offer a prize for the best in each grade/ best in school

357. You could sell thousands; give the school a percentage of what that school sells

358. 2C Cheryl: I think we’d have to go through the county/ district

359. Chief Brown: PTO is in charge of making money

360. Elders

361. Unsure (?): Gathering of Nations: it’s a way’s away, but if anyone wants to go, let me know

Susan motioned to close the meeting; Alan seconded.

Meeting adjourned at 9:30 pm.

Respectfully submitted by Michelle Hatcher on 8/28/2019 at 6:24 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
