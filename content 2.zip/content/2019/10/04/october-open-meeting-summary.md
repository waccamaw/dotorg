---
layout: post
title: "October 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/10/05/october-open-meeting-summary.html
post_id: 5649717
custom_summary: false
summary: ""
date: 2019-10-04T19:00:00-0500
lastmod: 2019-10-04T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/10/04/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 10/4/2019  held at the Tribal Office in Aynor, SC

1. CM’s Susan, John, Marion, Alan, Dalton, and CoC Rick present. Elders Avalene, Glenn T, Ronnie, Becky, and Dan present. 2C Cheryl present.

2. Financial Report

3. General Fund: $9647.73

4. Building Fund: $450.55

5. Online Votes

6. 9/26 Accept September minutes with changes

7. Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

8. Receipts

9. Boy Scouts

10. Rick: Wayne, Richie, Billy Joe brought food, but more people showed than anticipated; cost $195

11. John: it wasn’t supposed to cost us anything

12. Dalton motioned to pay Wayne the $195 for food; Alan seconded

13. Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

14. Susan: next time, put it out on the internet for a vote

15. 2C Cheryl: receipt for canteen

16. Leftover items to sell during other events, not just grab here in the office

17. $86.70 authorized by CoC Rick

18. Old Business

19. Carla Goodson

20. Dalton: she called about 4:30 today; still planning to go to reservations next week and looking for supplies for 40-50 families

21. Posted event on Facebook for her; please share it publicly

22. New Business

23. Receipts

24. Fuel: $81.44

25. Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-yes

26. Chief Hatcher: Clyde was going to donate cutting grass here; he cut grass at Ridge Rd

27. Committee Reports

28. Buildings & Grounds: Glenn

29. Weed eating

30. 10/5 & 10/16: bleachers, paint, glue, wood

31. Arts & Crafts: Susan

32. Probably hold classes after the first of the year

33. Want to use a projector for videos

34. Chief Hatcher: hold classes specifically for kids

35. Need Council feathers

36. 2C Cheryl: Chris Hatcher is still wondering about his app

37. Susan: I told him what to do and he hasn’t done it; will re-forward information to him

38. Pauwau: Dalton

39. Looking for volunteers; have some from CCU, Scouts, HGTC

40. Governing Body: send up to 4 people’s names to get in free

41. Begin submitting stories and pictures for next year’s program book today

42. Meetings are the 2nd Thursday of the month at 6pm at the tribal office

43. We will have Square available this year

44. Marion: will Robert be there?

45. Rick: as far as I know

46. Program book has been sent to printer

47. 2C Cheryl: policy on free book?

48. Susan: 1/2 page ad or better

49. Getting ice from Mr Newton for free

50. Susan: $2165: vendors, $2700: ads; $275: camping, with several due in

51. John: due vendors have to be native?

52. Susan: they have to be tribal-affiliated; only exception is food

53. Rick: fire: schedule days between Robert & Marion

54. Marion: need more than 2 days notice

55. Chief Hatcher: Earl & Little Bear will be here too

56. John: does tribal Firekeeper tend from first lit to extinguish?

57. Marion: No, someone did day; another did night

58. John: what about John Cox?

59. Dalton: Robert had a problem with him

60. Chief Hatcher: will talk to him; he knows Robert doesn’t want him here

61. Rick: will talk to Mark Williams too

62. Dalton: need young kids to take up Firekeeper and other duties

63. Glenn C: Larry J has a horse for the Pauwau

64. Larry J: Want to tell what horse means to natives

65. Needs a spot to let kids pet

66. Glenn C: suggest behind Bill & Susie, between them and fire

67. Dalton: can you come to the next Pauwau meeting?

68. Larry J: yes

69. Michelle: we will discuss it

70. Chief Hatcher: suggest around Ronnie Floyd’s tent

71. Glenn C: he needs access to water

72. We are adding Ronnie’s demonstrations to schedule of events

73. Drum: Rick

74. Played at CCU Cultural Celebration Event

75. Cub Scouts: Rick, Chris H, Trevor, others drummed

76. Campground: John T

77. Called zoning office on rural tourism; 3rd reading is 10/15

78. Chief Hatcher: can get a loan for it or credit card with 24 months no interest

79. Alan F: are there grants for development?

80. Chief Hatcher: we’ll look into it

81. Dalton: talk to Rick Elliott

82. Have him do $100/ plate dinner for rich people to benefit natives

83. Files: Susan

84. Propose Tribal Council, genealogists, filekeeper have access to the files

85. Alan F: Clarify: to look at, not change?

86. Susan: just to view

87. Rick: there’s an audit of files now

88. Susan: we’ve looked at files (Susan, Rick, Michelle, John)

89. 2C Cheryl: but nothing was done

90. Susan: 5-6 files were missing & not surfaced yet, but ID cards were made for them

91. Files belong to Tribal Council;

92. Marion C: as union, federal guidelines let officers into things

93. Dalton: audit doesn’t freeze activity

94. Changes are limited to filekeeper and those she designates

95. Alan F: not saying Tribal Council will change files; they are view-only

96. Rick: why does Tribal Council need access?

97. Susan: because I need to complete genealogy for projects with Patty

98. 2C Cheryl read an email from Patty to 2C Cheryl

99. Chief Hatcher: how long will it take to complete the audit?

100. Dalton: everyone backup emotionally from the issue

101. Right now, only the filekeeper can make physical changes

102. Read-only access should go to anyone

103. Non-Council members would need a Council member with them to view files

104. As far as federal recognition, it’s reasonable that we get questions from people about their file

105. No reason for a file to go home with anyone: make a copy of it

106. Decide on who has access to look at the files

107. No problem with Tribal Council looking at files

108. No need for power struggle issues

109. Rick: idea came from Chief Hatcher

110. Chief Hatcher: break it down into steps; make a coordinated effort to get files done

111. Okay with limited access and putting Susan’s proposal in place

112. Rick: okay with revisiting after audit

113. Chief Hatcher: there’s also the privacy act

114. Files belong to Council; they can already look at files unless they move otherwise

115. Dalton: don’t need to litigate this based on a specific circumstance

116. Do it based on who needs access and why

117. Susan: I was asked to do work by someone who does have access

118. 2C Cheryl: email says differently

119. Susan: will call these people to verify by word-of-mouth

120. Chief Hatcher: propose that you provide Susan with the code and after audit open it to all of Tribal Council; Dalton seconded

121. Susan-yes, John-yes, Marion-yes, Alan-yes, Dalton-yes, Rick-no

122. Marion: thinking about future Tribal Council & looking at files

123. 2C Cheryl: Tribal Council appointed a filekeeper to limit access to straighten out disarray

124. John: Governing Body should have access to all of it

125. John T: do we need a policy on planting memorial trees?

126. Dalton: yes, especially where

127. John: will consult with Buildings & Grounds

128. Elections next year: Elders need to begin working on guidelines

129. Cemetery: Brother put ashes in the fire; want to move parents to the cemetery

130. Do we need a separate 501(c)(3) for the cemetery?

131. Chief Hatcher: no

132. John: are there policies & procedures for the cemetery?

133. Is there a cemetery manager?

134. Are there plans for growth/ a budget

135. Do the trustees come up with the policies & appoint a manager?

136. Avalene: we have policies and procedures

137. John: can you get us a copy so we can make our own?

138. Chief Hatcher

139. 10/17: Myrtle Beach to speak about Columbus Day

140. Christian Academy wants us to come back and do a presentation; open to all

141. School books: we will be in a book; Carson will be in it

142. Original book had Catawba & Cherokee in it

Rick motioned to close the meeting; Dalton seconded.

Meeting adjourned at 8:24 pm.

Respectfully submitted by Michelle Hatcher on 11/23/2019 at 6:53 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
