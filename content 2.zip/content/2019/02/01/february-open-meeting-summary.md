---
layout: post
title: "February 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/02/02/february-open-meeting-summary.html
post_id: 5649711
custom_summary: false
summary: ""
date: 2019-02-01T19:00:00-0500
lastmod: 2019-02-01T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/02/01/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/1/2019  held at the Tribal Office in Aynor, SC

1. CM’s,   Dalton, Susan, Marion, Alan, and CoC Rick present. Elders Doug, Ronnie, Glenn, Becky, and Dan present. 2C Cheryl present.

2. 2C Cheryl sworn-in as Vice Chief by CoC Rick.

3. Financial Report

4. General Fund: $ 15,054.66

5. Building Fund: $350.55

6. Online Votes

7. Carport for equipment

8. Alan-yes, Susan-absent, Marion-yes, Dalton-yes, Rick-yes

9. Susan: suggest sending vote to full governing body for more ideas before closing the vote

10. 1/27 Approve January meeting summary

11. Alan-yes, Susan-yes, Marion-yes, Dalton-yes, Rick-yes

12. Old Business

13. Cemetery Update: 2C Cheryl

14. Deed still not received; it has been settled, follow-up with lawyer this week

15. Hallman Cemetery in Columbia: tombstones bulldozed, people not allowed to visit gravesites (which is illegal); would be a civil case

16. News picked up on it

17. Rick: what is the size of the cemetery?

18. Chief Hatcher: 5-6 tombstones

19. New Business

20. Receipts

21. Glenn C: Gas receipt & ID card receipt: $71.80

22. Committee Reports

23. Buildings & Grounds: Glenn C

24. The battery to charge the backhoe is gone; need to check with Mr. Charles to see if he has it

25. Created a calendar with work days, committee meetings to be put in a frame & kept at office

26. Need to clean around the area carport will go

27. Rick: where Donnie’s car is at is where the carport will go

28. Alan: does it affect anything if we decide to move the trailers?

29. Rick: no

30. Rick: everyone ok with the location? It can be moved around

31. Will call the guy as soon as the site is ready for it

32. Arts & Crafts

33. No report

34. Chief Hatcher: we need to do something about it

35. Susan: let Tribal Council certify artists

36. The only people who can say something should be certified are those who are certified

37. Chief Hatcher: let’s talk about it online

38. Rick: we could have a workshop on certification

39. Susan to head meeting some time in March

40. Pauwau: Dalton

41. Volunteers: let us know you want to volunteer and interested area

42. Pictures: change out old article pictures and update profile pictures

43. Send stories now for the program book on lore, family history, etc…

44. Meetings are the second Thursday of the month

45. Susan: can we change it to Wednesday this month because of Valentine’s Day?

46. Michelle-yes, 2C Cheryl-yes, Glenn-yes, Starla-yes

47. Post created on Facebook notifying everyone of the day change for Feb.

48. Starla: need more people selling ads, even just 1 each

49. Drum: Rick

50. Looking for 1/2 inch rawhide, may have to buy larger hides and cut it to restring drum

51. Susan: try moscowhides or centralhidesandfurs

52. Marion: how much do you need?

53. Rick: roughly 90-100 ft at 1/2 inch

54. Glenn C

55. Business Card designs: 3- logon on 2, eagle on 1

56. 500 for $8.50

57. Council to note any changes on the paper provided

58. 11/16 wedding: would like permission to use the grounds for the wedding & offer RV spot to people driving long distance

59. Dalton: camping/ RV spot: $35, tents: $5

60. Susan, normally would go by the policy letter, would disregard it for this

61. Alan: some people wouldn’t get a RV spot without Glenn’s (and committee) work

62. Marion: motion to allow the wedding to take place on the grounds & offer free RV site to those attending who need it; Alan seconded

63. Alan-yes, Susan-yes, Marion-yes, Dalton-yes, Rick-yes

64. Rick: if campers want to donate, they can

65. Starla: ID cards

66. Read a letter from her to Tribal Council

67. Rick: motion to make replacing card $15; Susan seconded

68. Alan-yes, Susan-yes, Marion-yes, Dalton-yes, Rick-yes

69. Rick: motion for policy to take effect on 3/1/2019; Susan seconded

70. Alan-yes, Susan-yes, Marion-yes, Dalton-yes, Rick-yes

71. Susan: this information (in the letter) was always in the first part of the newsletter

72. Dalton

73. Official communication: we discussed last month making it email

74. Marion: how would that work for voting?

75. Dalton: for voting, allow 1 vote per email address; others can print off a copy of the ballot or request an absentee ballot

76. Rick: spend approx $275 to send out one-time letter explaining voting changes- email, in-person, absentee

77. Could try an automatic voicemail system with voting information

78. Susan: include information we talked about for federal recognition, send 1 letter

79. Chief: have to be prepared: what happens if you send out 500 letters and only 2 respond?

80. Rick: can deal with people on a case-by-case basis

81. Chief: you’ll have some who say they never received the letter

82. Susan: they go into inactive & have 3 months to respond

83. Program to dial out

84. 2C Cheryl: Phone Tree

85. Glenn C: can text a landline, but there’s a fee

86. Rick: Council Homework

87. Think of items to put into letter for Chief Hatcher to draft

88. Alan

89. We have 18 functions/ year (meetings, Pauwau, solstice/ equinox, etc…); think to run for office, you should attend at least 1/3 of them

90. Dalton: in order to put requirements on who can run for office, you have to change the constitution & can add in background checks then too

91. Rick: single-check: $20; unlimited: $150-200

92. Susan: check Net Detective

93. 2C Cheryl: if someone wants to run for office, put the cost on them

94. Rick: would like to see background checks on new memberships

95. We will talk more about it, possibly create a committee to discuss it

96. Dalton to work on firearms resolution

97. Rick: Hemp program sounding good, going to Catawba to check out their program

98. Business cards: add website, maybe QR code

99. 2C Cheryl

100. Working with CCU in anthropology & geography with Dr Dillian (spelling?)

101. Meeting Thurs for petition- shared items in Drive

102. Will work with Ben Burrows- historical deeds

103. Going to research in Georgetown as well

104. Thanks to all who donated last month; will have an Awareness Dinner to talk about his condition next month

105. Susan

106. On conference call with people from the Cancer Van/ Best Chance Network

107. Needs a concrete pad to sit on, may need to change location (possibly school)

108. Can only do 25 appointments each day

109. 2C Cheryl: use a golf cart to transport people

110. If we have more than 25, they may set up another date

111. Rick: will check on the price of concrete for 40x40 area

112. Alan: perhaps have health fair event

113. Dalton: put the pad up beside RV spot 1

114. Susan: lengthwise from the gravesite

115. Chief

116. Introduced Tubby, Toby, Shiela, and Harrison West

117. Tubby: Frank’s wife is in ICU

118. Also introduced Paula & Jerry Cribb

119. Arts & Crafts: Public Law 101.644: can sell art as native

120. Our certification allows you to sell it as Waccamaw art

121. Letter sent to Standing Bear, waiting response

122. Tribal Roll Book: 2 people served time as honorary members: Marie

123. Tuesday: have a talk at CCU on federal recognition

124. TV15 interview done by Chief Hatcher & 2C Cheryl; unsure of air date

125. Genealogy files have to be certified

126. Suggest issuing certification to our 2 genealogists

127. Chief: are anthropology & genealogy the same?

128. Marion: similar, but will have my wife contact you

129. 2C Cheryl: there’s a Board of Genealogists that requires a fee, course with case study, and portfolio

130. Family Day: 2/16

131. Post to website

132. Friend from Longest Walk 3 will donate a van to the tribe; think we should give it to Donnie

133. Moving out of CMA and into Governor’s office- legislation being drafted by Mr. Clemons

134. Close gaps on contacting people and consequences

135. Draft letter

136. Bring suggestions to next meeting

137. Dalton: make voting mandatory, at least by mail-in ballot

138. Modify current membership agreement

139. Rick: calls count as 1 attempt, letter counts as 2nd attempt, then send certified letter

140. Dalton: except it’s not in the last 30 days

141. Susan: it moves them to inactive status for 90 days- they could get their act together

142. Elder Doug

143. Want to allow women on the drum

144. Chief: you see it as standing up for women; I see it as standing up for tradition

145. Glenn C: keep Mike’s father, my brother, 2C Cheryl, Trevor, & Chris Hatcher in your prayers

Dalton motioned to close the meeting; John seconded.

Meeting adjourned 9:15 pm.

Respectfully submitted by Michelle Hatcher on 2/27/18 at 1:03 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
