---
layout: post
title: "July Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/07/13/july-meeting-summary.html
post_id: 5649706
custom_summary: false
summary: ""
date: 2019-07-12T19:00:00-0500
lastmod: 2025-11-22T19:02:18-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/07/12/july-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 7/12/2019  held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Alan, Susan, John, Marion, and Rick present. 2C Cheryl present.

2. Financial Report

3. General Fund: $7,623.78

4. Building Fund: $450.55

5. Online Votes

6. 6/27 Accept June Summary

7. Alan-yes, Marion-yes, Susan-yes, John-yes, Dalton-yes, Rick-absent

8. Old Business

9. Donnie’s AC: ductwork incomplete

10. New Business

11. Receipts

12. Fuel: $76.43 Check 751

13. Committee Reports

14. Buildings & Grounds: Glenn C

15. Work Day 7/13- bleachers

16. Asked Chief for letterhead

17. Arts & Crafts: nothing new

18. Pauwau: Michelle & Dalton

19. SCAC is giving us $4000 to help with the Pauwau

20. Bleachers request: allow Glenn C to work on them now before budget is approved

21. Marion motioned, Dalton seconded to allot up to $350 for bleacher work

22. Alan-yes, Marion-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

23. Square: 3 ordered; Cost $21.60

24. Glenn C will also allow us to use his

25. Can send email receipts if people want on during Pauwau

26. Sill need: volunteers, ads, stories/ pictures for program book

27. John T: can we do ads on the website?

28. Dalton: it would be fine; have to get in touch with Doug

29. John T: was thinking more of a list of supporters with their website link

30. Dalton: put it on the Facebook event and all who click the even will be able to click the links

31. Patty B: up to when will you take money?

32. Dalton: through the Pauwau

33. Michelle: if you want it in this year’s book, 8/15

34. John T: my wife may be interested in helping with the website

35. Need to update Tribal Council on the website

36. John T: thoughts on something going on before Grand Entry?

37. Susan: always things to do before Grand Entry: games, stories, survival skills

38. Susan: 4 RV spots left

39. Glenn C: Ms. Tina mailed her application today; she will be here

40. Chief Hatcher: have you done anything about food vendor pricing for Pauwau?

41. Susan: it’s on the application to send us their menu with prices

42. Drum: nothing new

43. Susan: the UMC will give us $500 for the drum

44. Elder Doug asked to use the office 8/10 for family reunion

45. Dalton motioned; Alan seconded to allow Elder Doug to use the office for free on 8/10

46. Alan-yes, Marion-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

47. 2C Cheryl

48. Financial Report

49. Need to show money for Neon

50. Resend deposit slips 6/4-6/21

51. Dalton: what’s happening with our retainer?

52. 2C Cheryl: we have to ask for it

53. Rick motioned; Dalton seconded to ask the lawyer for the retainer back

54. Alan-yes, Marion-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

55. HH-VCC-06-12-2019-001: Hunka Membership Management: 1st Reading

56. 2C Cheryl: it’s at the discretion of the Chief if they receive a card

57. Glenn C: the card says they have no privileges

58. Patty B: wouldn’t give them a card

59. Rick H: think a card implies membership

60. 2C Cheryl: would give them a certificate & have a ceremony

61. Chief Hatcher: want to establish all Chiefs conferring on hunka memberships

62. NeonCRM

63. Marie is almost through the files

64. Some don’t have a date for when their ID card was removed

65. Expired cards as of 8/13/2012 should be inactive

66. Dalton H: Inactive is 90 days & then removed (retired) if nott fixed

67. Deceased Numbers should be retired

68. Need a policy on membership status

69. Dalton: status list: active, inactive, retired (includes deceased), resigned

70. If someone loses their number because of status, they will get a new number

71. John T: I think deceased should be its own category because their spirit is still part of the tribe

72. Marion C: if someone loses their membership, do you throw the file away?

73. Dalton/ 2C Cheryl: no, we keep them forever

74. Susan: we keep the actual file

75. Starla: what is the definition of good standing?

76. Dalton: up to date on dues, no under an order from Tribal Judge

77. Dalton to write a letter out with list of statuses:

78. Active: current

79. Inactive: problem with 90 days to fix

80. Resigned: didn’t fix problem with Inactive status or voluntarily resigned

81. Retired: Were a member who passed on

82. Judgement: under order from Judge

83. Neon CRM is in process of being set up; first is membership

84. Set up payment processor; fee: credit cards 2.6% + 0.30/transaction

85. Check draft: 1% +$1/ transaction

86. Set up as a valid non-profit

87. Susan: do we have to be linked to Quickbooks?

88. 2C Cheryl: it syncs to Quickbooks, but Dori isn’t using Quickbooks

89. Dalton: see if we can use Square as our processor

90. 2C Cheryl: read samples from list; Square isn’t on it

91. Dalton: use current database structure

92. Patty B: another genealogy class 8/4, 9/15 at 1pm

93. 2C Cheryl: Indigeonous Women’s Alliance: cooking BBQ 9/7

94. Is everyone ok with women drumming?

95. No complaints voiced

96. Chief Hatcher

97. Patty, are you going to go back & certify the core people?

98. Patty B: I can

99. Chief: I will have you look at Hatcher & Dimery books

100. All additions will go through Patty B

101. Patty B: I have research on paper, Susan will check for errors, then I will compile on big genealogy book of core

102. Chief Hatcher: we need to put book numbering on ID too

103. Chief Hatcher: what about non-core?

104. Patty B: you don’t need anything; just keep % 's right

105. Chief Hatcher: would like Starla V & Patty B to keep count of core/ non-core percentage

106. Susan suggested going back to 2017 & give people 6 months to fix expired cards

107. Allow them to pay past dues & we will renew the card

108. Patty B: I’ve seen it work some in libraries

109. Chief Hatcher: we don’t have a historian doing work; we need an active one creating articles

110. Rutland/ Chavis Cemetery in Norway, SC

111. Around 1864, a man was buried on his own land and then more people were buried there with stones to mark the graves

112. About 2 years ago, Mr. Barr bought the land. His house overlooked the graves, so he bulldozed them down

113. Pat Hallman’s relatives are buried there & he’s now stopped from going to the cemetery

114. State law says it’s a felony to desecrate a graveyard

115. 2C Cheryl: H3806, 2019,  session 123, Gilliard et al

116. Preservation of cemeteries

117. It’s illegal to stop people from visiting a cemetery

118. 501c (3) can do business with surplus stores

119. Unless you’re Native, then you have to live on a reservation

120. Award: Carolina Celebration of Freedom

121. Need to write letters about issues we care about

122. Letter should say you are a citizen

123. Dalton: use billboards if not too expensive

124. Gov. McMaster: we were supposed to meet, but his advisors/ staff said he had a meeting with NAACP, Hispanics, but wouldn’t have time for use

125. Marie & Starla V did lots of work; found wrong addresses in files

126. Call people; send letters: John T, Marie, Starla

127. 2C Cheryl: Neon CRM will send mail merge with individual names on letters

128. Susan: use Facebook page/ messenger

129. Dalton: send mail through tribal secretary

130. Tubby West passed away

131. John T

132. Rent RV campsites as-is: $35/night

133. Concerns: credit card payment

134. Need camping prices on website with pictures

135. Establish a method of reservation

136. Email; call to confirm

137. Need a contact list of people taking reservations

138. Do a test run

139. Dalton: talk to a travel agent for advertising

140. Volunteers: John, Glenn C

141. Let John know if you’re interested

142. Pricing: RV & tent

143. Check on insurance policy

144. Chief Hatcher: get an attorney to write a letter releasing us of liability

145. Susan: the only time they can’t be here is during Pauwau

146. Dalton: or increase the cost during the Pauwau

147. Glenn C: 14 sites available

148. John T motioned to move forward with camping and make adjustments as we go; Marion seconded

149. Alan-yes, Marion-yes, Susan-yes, John-yes, Dalton-yes, Rick-yes

150. John to initiate WIP Campground Setup

151. Chief Hatcher to check on insurance

152. Rick: do we need a license? Check with county first

153. Membership Renewal Coordinator

154. We should be taking in $875/ month in fees; willing to call or email them

155. Are we willing to remove them for lack of payment?

156. Dalton: by 8/1, $50/year or $5/ month, no penalty for not paying until renewal date

157. John: would like a $50 card renewal fee/ 2 years

John motioned to close the meeting; Alan seconded.

Meeting adjourned at 9:20 pm.

Respectfully submitted by Michelle Hatcher on 7/25/2019 at 4:43 pm.

[#WorkDay](https://www.waccamaw.org/updates/hashtags/WorkDay) [#membership](https://www.waccamaw.org/updates/hashtags/membership) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
