---
layout: post
title: "January 2019 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2019/01/12/january-open-meeting-summary.html
post_id: 5649710
custom_summary: false
summary: ""
date: 2019-01-11T19:00:00-0500
lastmod: 2019-01-11T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2019/01/11/january-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 1/11/2019  held at the Tribal Office in Aynor, SC

1. CM’s,   Dalton, Susan, John, and CoC Rick present. Elders Doug, Ronnie, Becky, and Dan present.

2. Res: DH-01-11-2019-001: Certification of the Results of the 2018 Tribal Election

3. Susan-yes, Dalton-yes, John-yes, Rick-yes

4. Susan, Marion C, Alan F sworn-in to Council, Harold Hatcher sworn-in as Chief by CoC Rick.

5. Chief Hatcher: thank you to Jeania, Susan, Mark for their service on Council

6. December summary read

7. Dalton-yes, John-yes, Susan-abstain, Chief-yes

8. Financial Report

9. General Fund: $16,054.90

10. Building Fund: $350.55

11. Chief Hatcher: I can give each member of Council a different password to allow them to view the site

12. Old Business

13. Cemetery Update

14. Deed not registered yet

15. John T: think we need to investigate putting up a fence between our line & the trailer at the cemetery

16. Larry J: how do you become a trustee?

17. Elder Dan: when a trustee gives up a spot, we fill it

18. Need a sign for the cemetery so people will know whose it is

19. CoC Rick: what about the dog situation there?

20. Larry J: dogs still go all over the place

21. New Business

22. John T: we had talked about getting a pump for a gas tank

23. CoC Rick: not received yet

24. Committee Reports

25. Buildings & Grounds: Glenn C

26. Nothing new since Pauwau

27. Trench drawn across the second entrance

28. May be too wet for putting in run-out pipe/ pump action

29. 1.5HP pump: approx. $100, drum $10, electric each month

30. Elder Doug: I have a 55-gal plastic drum

31. COC Rick: motion to budget $150 for pump between site 8 & 9

32. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

33. John T: did you buy those bleachers?

34. Glenn:yes, Susan & I bought them; thanks to Mike, Metissa, all who helped

35. Can turn them into 4 sets if they are too high

36. Pauwau: Michelle

37. Chair elected: Michelle

38. Voting Members have to be approved by Council since it is a new year

39. Michelle, Cheryl, Glenn, Starla, Courtney, Mathea, Lindsay

40. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

41. If you have personal picture you’d like to switch to put in the book, send it now

42. Discussed increasing Dance Raffle by $500: 1 prize for dancers who were there both days & in circle when grand prize drawn

43. Volunteers: let us know if you’d like to help

44. Walkie Talkies: we would like to get 18 more so we can get one to everyone who needs one & for us to be able to talk to Constables

45. Need someone from the gate to be at the Pauwau meetings so we can coordinate

46. Need an accurate count of people

47. Susan: Veterans Feathers

48. Need to create a policy letter

49. Conditions for Veterans Feather:

50. Have to be a veteran (ex: not the child of one)

51. Have to be in the circle during Grand Entry (unless wheelchair-bound, extreme cases)

52. You only get 1

53. Or decide that it doesn’t matter

54. Alan F: they should be in the circle unless disabled

55. Chief Hatcher: clip a V into feathers of those who don’t attend Grand Entry

56. John T: where do you give them out?

57. Dalton: discussing giving them out while they are in the circle

58. John T: Think we should run elections 9/15-10/15 & have swearing-in at the Pauwau

59. Dalton: not sure Tribal Council has time; most are volunteering

60. Marion C: great idea, but I see Council running around during Pauwau

61. Arena Director: need someone to shadow; let us know if you are interested

62. Rick: anyone talk to Chris H?

63. Michelle: he said he didn’t want to go through all of that

64. Drum: Rick

65. Drummed at MB Christian Academy

66. Need to restring the drum

67. Rick

68. Special Needs Fishing Day: May 4th

69. Need more fish because of the storms

70. Roger Barber will probably bring them; would like to give him something

71. Starla: can I get an invitation to send out by email?

72. Rick: yes

73. Asked Larry J to bring out the horses

74. Need a release form to protect us from accidents

75. Elder Doug: Roger McNeil has lots of land with a pond on it; would probably be tickled to host the event

76. Talking about building up the banks

77. Will have a volunteer check-in sheet

78. Growing Hemp

79. 2020 is the quickest we can grow

80. Attractive, moneywise

81. 5 acres to do it on; Richard T has land if we choose to do it

82. If Council approves, Rick and Richard T will go to Rock Hill to see how Catawba started their program and how it’s doing now

83. Chief Hatcher: would need security on it because it looks identical to marijuana

84. Have to be established with a college

85. Richard is working with Clemson

86. Agreement in place before we grow

87. We would be partners with Richard T because of the land & equipment

88. Susan: what’s the split?

89. Rick: still working on it

90. Dalton: I’d like to see a business plan

91. Rick: cost about $1000/ acre to plant

92. Larry J: will it be protected like other crops?

93. Rick: not sure yet, looking into it

94. Think after 2020 (when you won’t need a permit), you can buy insurance for it

95. Elder Doug: is there a market for it?

96. Marion C: the oil

97. Rick: you can make things from it like it were cotton

98. Dalton: what’s the expected profit per acre?

99. Rick: it’s up there, unsure of exact numbers

100. You can also sell the seeds

101. The state randomly inspects it & will destroy it if they find marijuana in it

102. Guidelines for Government

103. Need to hold government officials accountable

104. Chief Hatcher: will email you job descriptions

105. Background Checks

106. Program & subscription: approx $150-300

107. John T: will you do checks on members of the tribe?

108. Rick: if they are going to work around kids, yes

109. Alan F: then you have something to show that you tried to do something if a problem were to happen

110. Guns on the Grounds

111. Concealed Weapon Permit: leave the gun in the car

112. Dalton: don’t see a problem with it if it’s not on your hip & kept in your car

113. Rick: applies to pistols, not long guns

114. Glenn T: keep guns in mind for turkey shoots

115. Can modify the current Firearms Restriction Resolution

116. Dalton: electrical status, Glenn C?

117. Glenn C: need the trench; probably be end of February before we have anything

118. Alan F: need to look at qualifications for running for Council besides being a member

119. Susan: need a better voter response

120. Need to add to current resolution on distributions (Disbursement of Assets)

121. Rick: what about voting at the Pauwau?

122. Dalton: could make voting mandatory

123. Starla: what about prepaid envelopes?

124. Marion C: problem with that is if they don’t vote, tribe is still out-of-pocket for the envelopes

125. Chief Hatcher: used to be that if you lived within a 50 mile radius, you had to come vote, the rest were mailed out

126. John T: what about online voting?

127. Chief Hatcher: have to be able to tell that it’s you voting

128. John T: methods of communication; can make email our official means of communicating

129. Dalton: would like to see dirt to build up the circle

130. And finish pictures of Tribal Council to put on the walls

131. Rick: would like to get a metal carport for our equipment

132. Chief Hatcher

133. Trevor S: has cancer; any donations for 2C Cheryl to help with groceries/ gas would help

134. Opportunity for us to move from CMA to a government office

135. CMA hasn’t done much for Natives

136. Meeting between 2C Cheryl, Marie, and others

137. Take our drafted petition to get it in this year

138. 2 documentaries; 1 about us specifically

139. They want to talk to the Elders

140. 2nd is about SC Indians

141. Mr. Chavis is off the CMA board

142. Have a lady to go through genealogy files

143. Linda A is the tribal genealogist, but hasn’t shown degree

144. Tribal Treasurer: Dori A will still do it if Council approves

145. Dalton motioned; Rick seconded

146. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

147. Need letterhead & envelopes (250)

148. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

149. Tribal Council Business Cards: need to design a card; Glenn & Starla to work on it

150. Grey Court next Thurs/Friday for feather ceremony for Chief Worthy at sunrise on the grounds

151. Mark Williams to start the fire & we will name him their firekeeper

152. Daughters of American Revolution: Jan 16

153. Received a book from MB Christian Academy; will probably be an annual event

154. Governing Body Information Sheet: make sure it’s correct

155. Rick: motion to give $100 to Cheryl; Dalton seconded

156. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

157. Check 728

158. Susan: can we give UMC $100 for Elders’ baskets?

159. Susan motioned; Rick seconded

160. Susan-yes, Marion-yes, Alan-yes, Dalton-yes, John-yes, Rick-yes

161. Check 729

162. Elder Doug: any further discussion of having women on the drum?

163. Chief: not worked on recently

164. Elder Becky: picnic tables: $185-200 out of Cypress

165. The man just needs to time to build them

166. Glenn C: more community involvement

167. Parades, Hoe Down, Heritage Festival

168. Rick: and schools

169. Elder Dan: have a parade before the Pauwau

170. Charles H: have the tribe purchase 1 lottery ticket each month

171. Family Day: 2/16

172. Food: BBQ, Chicken Bog

173. Glenn C: Next Work Day: TBA

Dalton motioned to close the meeting; John seconded.

Meeting adjourned 9:30 pm.

Respectfully submitted by Michelle Hatcher on 1/27/18 at 5:06 m.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
