---
layout: post
title: "Summer Solstice 2020"
microblog: false
guid: http://waccamaw.micro.blog/2020/06/04/summer-solstice.html
post_id: 5650036
custom_summary: false
summary: ""
date: 2020-06-03T19:00:00-0500
lastmod: 2020-06-03T19:00:00-0500
type: post
url: /2020/06/03/summer-solstice.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Jun 4, 2020
- 1 min read

From CoC Rick:

The summer solstice falls on June 20th the third Saturday of the month. I have spoken to two of our three fire-keepers and they both are in favor of holding the fire ceremony. Do not feel obligated to addend if you feel your health or the health of others may be at risk.For those who feel comfortable attending I look forward to seeing you there.Thanks COC

[#WIPSummerSolstice2020](https://www.waccamaw.org/updates/hashtags/WIPSummerSolstice2020)

Tags:

- [solstice](https://www.waccamaw.org/updates/tags/solstice)
