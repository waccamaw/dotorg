---
layout: post
title: "February 2020 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2020/02/08/february-open-meeting-summary.html
post_id: 5649720
custom_summary: false
summary: ""
date: 2020-02-07T19:00:00-0500
lastmod: 2020-02-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2020/02/07/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Updated: Apr 4, 2021

Tribal Open Meeting Summary 2/7/2020  held at the Tribal Office in Aynor, SC

1. CM’s Marion, Alan, John, Robert, CoC Rick present. Elder Glenn T present.

2. Financial Report

3. General Fund: $24,245.92

4. Online Votes

5. 1/27: Accept January 2020 Open Meeting Summary

6. John-absent, Dalton-absent, Marion-yes, Alan-yes, Robert-yes, Rick-yes

7. Old Business

8. John T’s Email

9. Building Interest

10. Classes: language, history

11. Movie Night

12. Dalton: Have a Family Day each month the day after the open meeting

13. Council Agenda

14. No tabling issues

15. Policy & Procedure book with private web access

16. Allocate money for projects

17. Should do a budget every year

18. Glenn C: already  working on windows

19. Rick: think we need another event to increase funds

20. Marion: from Deborah Creech: $500 for rock on driveway

21. Suggest a priority list from Council with costs by next meeting

22. Marion: motion to make pump station [#1](https://www.waccamaw.org/updates/hashtags/1) priority for the year; Robert seconded

23. Dalton: do we know its exact cost?

24. John: from water company: $5875

25. Couple of additional costs, around $1200 more

26. Rick: do a meeting just for the pump station

27. Marion: are we going to have a meeting?

28. Rick: Family day at 5pm

29. Marion: withdraw my motion

30. Election Year- Elders

31. Marion: add active attendance

32. Alan/ Dalton: require candidates to get a certain number of signatures like state/ federal elections

33. March Council Work Day on Policies 3/21

34. Money paid to some & not others (Example: paying Earl & not Robert)

35. Dalton: not aware that Robert wanted to be paid, do you? It  costs Earl money to get here, his food, etc…

36. Rick: but so does Robert

37. John: same with Ronnie

38. Dalton: I imagine that when the pauwau was first started, Ronnie was asked if/ said he’d do things; if people want to be paid, they should ask

39. Rick: it’s not that they want to be paid, but they  don’t want others to be paid

40. Cemetery Guidelines

41. Marion: I volunteer to mow the cemetery on my time

42. Glenn: will do it with you

43. Policy Letter: Trees

44. Rick motioned to accept; Robert seconded

45. Marion-yes, Alan-yes, John-yes, Robert-yes, Rick-yes

46. John T’s birthday donation: $1500 for sewer

47. Exemption of Membership Fees   Resolution: added [#7](https://www.waccamaw.org/updates/hashtags/7)

48. Marion: 200/yr? Thought it was 200

49. Rick: think it should stay as written (200/yr)

50. Alan: labor is only one with a time limit

51. Glenn: make it 200 for 2 years (consecutively)

52. Rick: 200hrs in 24 months

53. Dalton: change to 2 consecutive calendar years

54. Rick: motion to change it to 200 hours in 2 consecutive calendar years;  Robert seconded

55. Marion-yes, Alan-yes, John-yes, Robert-yes, Rick-yes

56. New Business

57. Committee Reports

58. Buildings & Grounds: Glenn

59. Dirt here, just need to get it moved around

60. Cleaned old trailer last month; added new lock to it

61. Windows: need to take size to the man to be able to get a price

62. Poppy Hamilton passed; Starla’s sick

63. Rick: friend’s child is missing

64. Marion: Michael had a stroke and is in the hospital

65. Pauwau:  Dalton

66. Looking for Volunteers for Pauwau2020

67. Begin submitting stories/ pictures for this year’s book today

68. Begin selling ads; cutoff date 8/15

69. Meetings are the 2nd Thursday at 6pm at tribal office (2/13)

70. Rick: need better food for volunteers/ dancers

71. Rick: each member of Council should have a spot working the pauwau

72. Files Committee: Dalton

73. Need to set the voting membership

74. Automatic: Filekeeper and Secretary: Starla, Michelle

75. 1 Tribal Genealogist

76. 1 Council Member (suggest Dalton because of database knowledge)

77. Chief nominates a spot for him (suspect 2C Cheryl)

78. Marion wants a spot

79. Nominate Glenn C for last spot (since Starla will be here)

80. Rick: motion to accept Dalton, Marion, Glenn as voting members on the files committee; Robert seconded

81. Marion-yes, Alan-yes, John-yes, Robert-yes, Rick-yes

82. Rick: do we need to have a certified genealogist?

83. Dalton: don’t think they have to be certified

84. Marion: a certified genealogist will cost thousands of dollars/month

85. Dalton: may be cheaper to get one of ours certified

86. Marion: we need to work on the files before looking into certifying a genealogist

87. Drum

88. Play for Christian Academy 2/21 from 8:30-11:30

89. Family Day 2/15

90. Alan F  is bringing BBQ

91. Elders

92. Larry J: think we should set our own cemetery trustees

93. Dalton: all of the trustees are Waccamaw except Hilda

Marion motioned to close the meeting; Robert seconded.

Meeting adjourned at 9:10 pm.

Respectfully submitted by Michelle Hatcher on 2/23/2020 at 12:33 am.
