---
layout: post
title: "Announcement"
microblog: false
guid: http://waccamaw.micro.blog/2022/08/25/announcement.html
post_id: 5649930
custom_summary: false
summary: ""
date: 2022-08-24T19:00:00-0500
lastmod: 2022-08-24T19:00:00-0500
type: post
url: /2022/08/24/announcement.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- May 25, 2022
- 1 min read

Updated: Aug 25, 2022

You can now find us on other social media sites:

Instagram: @Waccamaw_SC

Twitter: @Waccamaw_SC

Facebook: @WaccamawIndianPeople  (the community page)
