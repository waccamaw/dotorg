---
layout: post
title: "CCU & Horry County Museum Waccamaw Exhibit"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/20/ccu-horry-county-museum-waccamaw.html
post_id: 5649950
custom_summary: false
summary: ""
date: 2022-02-19T19:00:00-0500
lastmod: 2025-11-22T19:07:01-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/8d9343373b.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/8d9343373b.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/8d9343373b.jpg
url: /2022/02/19/ccu-horry-county-museum-waccamaw.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 25, 2021
- 1 min read

**Save the Date**: 4/27/2021

[

![ree](https://waccamaw.micro.blog/uploads/2025/8d9343373b.jpg)

](https://www.facebook.com/photo?fbid=10158037758953568&set=pcb.10158037759183568)

[https://www.facebook.com/anthropologygeographyCCU/photos/pcb.1421352841558736/1421352594892094/](https://www.facebook.com/anthropologygeographyCCU/photos/pcb.1421352841558736/1421352594892094/)
