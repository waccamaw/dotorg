---
layout: post
title: "Grounds & Equinox update from CM Glenn"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/20/grounds-equinox-update-from-cm.html
post_id: 5649981
custom_summary: false
summary: ""
date: 2022-02-19T19:00:00-0500
lastmod: 2025-11-22T19:07:29-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/3fba65d8ca.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/3fba65d8ca.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/3fba65d8ca.jpg
url: /2022/02/19/grounds-equinox-update-from-cm.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Apr 4, 2021
- 1 min read

A big thanks to Mrs. Nancy, Clay and Marion for their help on the Grounds yesterday. Mrs. Nancy got the front flower bed looking great. Marion and Clay helped with some electrical and plumbing work. We are still waiting on Grand Strand to put in the sewer system. Once they do, they can go ahead and hook up their end of the electric and do their testing on the pump station. We will then rent something to dig with and put in our part of the sewer plumbing. We plan to put in a couple of places for dump stations along with our buildings.

It was good to Mr. Glenn T. and Mr. Larry J.

 Also like to thank everyone who came out for the Fire Ceremony on 3/20/2021. It was good to see the young adults participating in our culture. On that same note, Starla and I had a Grand Niece (MiahLeigh) to come out. She also did a paper for school (Eastern Carolina University) on the Tribe in which she received a grade A for.

    Thanks to our Volunteers. Thanks to Donnie for donating a Boston butt, Larry C for cooking the Boston butts, Starla, her sister Debi and Ricky for preparing and serving the food, Debi, her husband David, Carolyn D, Catie C, and the others I may have forgotten, for the food they prepared.

Thank you all for your support

![ree](https://waccamaw.micro.blog/uploads/2025/3fba65d8ca.jpg)

Glenn C
