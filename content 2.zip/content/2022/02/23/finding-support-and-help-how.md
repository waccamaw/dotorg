---
layout: post
title: "Finding support and help: how your community can make a difference"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/finding-support-and-help-how.html
post_id: 5649979
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2025-11-22T19:07:11-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/435d4b2d34.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/435d4b2d34.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/435d4b2d34.jpg
url: /2022/02/23/finding-support-and-help-how.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- May 8, 2016
- 1 min read

This is your blog post. Blogs are a great way to connect with your audience and keep them coming back. They can also be a great way to position yourself as an authority in your field. To edit your content, simply click here to open the Blog Manager. From the Blog Manager you can edit posts and also add a brand new post in a breeze.

To make it easy for visitors to search your blog according to topic, add 'Tags' to your posts in the Blog Manager.  You can showcase the very best posts from your blog by setting a post as a Featured Post. Just click the star icon next to the Post title to define it as a Featured Post. It’s a great, easy way to promote specific content in your blog.

![image](https://waccamaw.micro.blog/uploads/2025/435d4b2d34.jpg)

[#community](https://www.waccamaw.org/updates/hashtags/community) [#team](https://www.waccamaw.org/updates/hashtags/team)
