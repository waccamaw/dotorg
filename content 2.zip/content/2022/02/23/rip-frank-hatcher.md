---
layout: post
title: "RIP Frank Hatcher"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/rip-frank-hatcher.html
post_id: 5650020
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2025-11-22T19:46:26-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
- https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/92c8e5632c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/15e45d24fa.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/b507ef994d.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/85ec81f8cd.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/fb544a2d20.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/bf0bdbc820.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/2ff8ffcc64.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/1fbd70a3af.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d2f78a13c2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/dffe27d0d2.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/4f1d550756.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/11d639e3e0.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/06ab974a4b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/16d5691edc.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/7ca5c67e7c.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae2f98e4d5.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/d9bd09578b.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
- url: https://cdn.uploads.micro.blog/272201/2025/ae409db76e.jpg
url: /2022/02/23/rip-frank-hatcher.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jun 4, 2020
- 1 min read

From Chief Hatcher:

Once in a lifetime, there comes a person who will value their principals, morals and their people above all else.

They will suffer any pain; carry any load, walk any path to make life better for those around them; some of which he didn't even know them.

Frank's feet have trod trails that many will never know. His heart has touched many beyond his own community, and friends and even many without knowing the.
He has led when no other would and he has succeeded when no other could. He was a voice from the pits of inequality that would not be quieted.
Earth is a better place because he walked upon it. His wisdom now, will be shared with the ancients because he has earned his place on the mountain of eternity.
What is lost to us is gained in the eternal light!
Rest In Peace, my friend! You have earned it! [#](https://www.facebook.com/hashtag/rip?__eep__=6&source=feed_text&epa=HASHTAG&__xts__%5B0%5D=68.ARC5dPpBVrKFteVhd99gdNlfx3k9PdD_CtFGhbgN2wQNTOxh8rv71jYlj26dww5wxMG8vp5A_yJ5PGRS21HEoZ0fqO9TgysonZ9pu3nzHK5PHhI94o5AknBFzTl1oHeGBEq54K9LXYI7unMYk980dkPhsJAWnKIoz-xbU3h5P76TqnY6AzVwHXHf6VUSWBbkR9YSKG69SG5p5Xtg4NGF1LhjE9D030Ie3_d5R-JFa0phIva6Bj9Laju6yro-9zxu1rfszLONh4mTgTwGCr3tiNRBj-DSz2IuI2ZxqcZVMnh986PaFDZYD6FW-9LcKAQknHy9IHsvtaVMapqwbSVi6Q&__tn__=%2ANK-R)RIP

![image](https://waccamaw.micro.blog/uploads/2025/92c8e5632c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/92c8e5632c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/15e45d24fa.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/15e45d24fa.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b507ef994d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/b507ef994d.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/85ec81f8cd.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/85ec81f8cd.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb544a2d20.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/fb544a2d20.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/bf0bdbc820.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/bf0bdbc820.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2ff8ffcc64.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/2ff8ffcc64.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1fbd70a3af.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/1fbd70a3af.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d2f78a13c2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d2f78a13c2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/dffe27d0d2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/dffe27d0d2.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4f1d550756.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/4f1d550756.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/11d639e3e0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/11d639e3e0.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/06ab974a4b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/06ab974a4b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/16d5691edc.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/16d5691edc.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7ca5c67e7c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/7ca5c67e7c.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ae2f98e4d5.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ae2f98e4d5.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d9bd09578b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/d9bd09578b.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ae409db76e.jpg)

![image](https://waccamaw.micro.blog/uploads/2025/ae409db76e.jpg)
