---
layout: post
title: "Request from Filekeeper Starla"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/request-from-filekeeper-starla.html
post_id: 5650011
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2022-02-23T19:00:00-0500
type: post
url: /2022/02/23/request-from-filekeeper-starla.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 29, 2018
- 1 min read

I need every member to send me their current email address and update any incorrect information. Please contact Filekeeper Starla at [[email protected]](/cdn-cgi/l/email-protection).

[#membership](https://www.waccamaw.org/updates/hashtags/membership) [#email](https://www.waccamaw.org/updates/hashtags/email)
