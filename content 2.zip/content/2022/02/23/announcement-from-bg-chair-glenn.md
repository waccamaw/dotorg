---
layout: post
title: "Announcement from B&G Chair Glenn C"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/announcement-from-bg-chair-glenn.html
post_id: 5649928
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2022-02-23T19:00:00-0500
type: post
url: /2022/02/23/announcement-from-bg-chair-glenn.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Sep 4, 2018
- 1 min read

 Reminder there is no work day this Sat 8th due to Santee Pauwau. But there is plenty on weedeating that needs done. If you go out just call or text me.

Thanks everyone.
