---
layout: post
title: "Membership, Fees, & ID Cards"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/membership-fees-id-cards.html
post_id: 5649996
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2022-02-23T19:00:00-0500
type: post
url: /2022/02/23/membership-fees-id-cards.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Mar 7, 2018
- 1 min read

Tribal Members:

If you need to pay your membership fees (which began August 2013), contact Michelle at [[email protected]](/cdn-cgi/l/email-protection)

If you need to update your information (phone, address, etc) or request a new card (due to expiration or loss), contact 2nd Chief Cheryl at [[email protected]](/cdn-cgi/l/email-protection)

[#membership](https://www.waccamaw.org/updates/hashtags/membership) [#membershipfees](https://www.waccamaw.org/updates/hashtags/membershipfees) [#IDcards](https://www.waccamaw.org/updates/hashtags/IDcards)
