---
layout: post
title: "5th Annual Special Needs Fishing Day"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/24/th-annual-special-needs-fishing.html
post_id: 5650040
custom_summary: false
summary: ""
date: 2022-02-23T19:00:00-0500
lastmod: 2025-11-22T20:01:39-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/b0a3d9f945.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/b0a3d9f945.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/b0a3d9f945.jpg
url: /2022/02/23/th-annual-special-needs-fishing.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Doug Hatcher
- Mar 31, 2019
- 1 min read

Hello everyone,

Can you believe it, we are already into the fifth year of Special Needs Fishing Day. Thanks to everyone that has worked to make this program a success. I am confident that Grandfather will bless you all for your efforts . I am attaching a flyer for this years event. Please feel free to share this with anyone you know that has affiliation with a special needs child or potential sponsors. Although invitations are sent out through the mail I know there are kids out there that are not receiving invitations simply because we don't have information for them. Plans are in the works for equine therapy, I hope to have this in place if possible this year. Special thanks to the Jernigan Family and Second Chief Cheryl Sievers for their efforts to make this happen.The Outdoor Ministry from Crossway Church will be there again this year providing the archery station for the kids.Chef Mark Ammons will be manning the grills again this year, yum yum. Please make an effort to participate this year. A few hours of your time can make a lifelong memory for a child with special needs.This is strong medicine not only for them but us as well.Thank you for your time and please forward this to anyone it may pertain to .

Grand Father tells us " And whoever welcomes one such child in my name welcomes me".

Walk Softly,

Chief of The Waccamaw Indian Tribal Council

Ricky Hudnall

![image](https://waccamaw.micro.blog/uploads/2025/b0a3d9f945.jpg)
