---
layout: post
title: "Fall newsletter"
microblog: false
guid: http://waccamaw.micro.blog/2022/02/18/fall-newsletter.html
post_id: 5649974
custom_summary: false
summary: ""
date: 2022-02-17T19:00:00-0500
lastmod: 2022-02-17T19:00:00-0500
type: post
url: /2022/02/17/fall-newsletter.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Nov 22, 2021
- 1 min read

Waccamaw Newsletter Sept 2021 (Final Copy).pdf

Download PDF • 740KB

This is a second-sending of the Fall Newsletter. It was originally sent by email to tribal members that the People's Alliance has addresses for. Be sure to check event dates and have a great holiday weekend!
