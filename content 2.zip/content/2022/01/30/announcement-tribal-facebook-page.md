---
layout: post
title: "Announcement: Tribal Facebook Page"
microblog: false
guid: http://waccamaw.micro.blog/2022/01/31/announcement-tribal-facebook-page.html
post_id: 5649931
custom_summary: false
summary: ""
date: 2022-01-30T19:00:00-0500
lastmod: 2022-01-30T19:00:00-0500
type: post
url: /2022/01/30/announcement-tribal-facebook-page.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Jan 30, 2022
- 1 min read

For all my Waccamaw friends, please remember to post to our FB business page, which says Community.

Our FB url is: [www.facebook.com/WaccamawI...](https://www.facebook.com/WaccamawIndianPeople)

We do not the own the Waccamaw Indian People page that says local business. Ours doesn't have dashes in the name or numbers after it like this: [https://www.facebook.com/pages/Waccamaw-Indian-People/163419077021621](https://www.facebook.com/pages/Waccamaw-Indian-People/163419077021621)

We only have one Facebook page.
