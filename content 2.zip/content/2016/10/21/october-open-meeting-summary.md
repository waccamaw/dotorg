---
layout: post
title: "October 2016 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2016/10/22/october-open-meeting-summary.html
post_id: 5649691
custom_summary: false
summary: ""
date: 2016-10-21T19:00:00-0500
lastmod: 2016-10-21T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2016/10/21/october-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Updated: Oct 12, 2024

Tribal Open Meeting Summary 10/21/2016 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Mark, Homer, Robert, Susan, and CoC Rick present.

2. Chief invited candidates for SC elections to meeting; Mal Hyman attended

3. Mal Hyman: candidate vs Rep Rice, Poli-Sci teacher

4. Members asked questions of Mr. Hyman to get a better idea of his policy issues

5. Cemeteries: Elder Dan nominated Ray as trustee as of 10/8/2016

6. September minutes read

7. Mark motioned to accept; Dalton seconded

8. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

9. Financial Report: Michelle via CNB site as of 10/18

10. General Fund: $9619.33

11. Building Fund: $4057.09

12. Online Votes

13. 10/3: Postpone open meeting to 10/14 due to Hurricane Matthew

14. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

15. 10/10: Postpone open meeting to 10/21 due to Hurricane Matthew

16. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

17. Old Business

18. Cemetery Encroachment

19. Letter sent to Mr. James

20. Cemetery Trustees Update

21. Paperwork not available yet

22. New Business

23. Dalton: apology to associate members who didn’t receive a newsletter

24. Ballots can be emailed before 10/31 to voting members who didn’t receive one

25. Constitution: send Dalton an email if you have questions before 10/31

26. Investors proposal from CM John; tabled until next meeting

27. Committee Reports

28. Arts & Crafts: Susan

29. 12/10 at 2pm: Class on how to make chokers: $35/ person (giving $10 back to tribe)

30. Asking for permission to use office

31. Mark: policy says rental if you make a profit

32. Susan: won’t do it them or use trailer next door

33. Rick: need lights in there or drop cord & light

34. Grants: Michelle

35. SCAC paperwork received

36. Pauwau: Michelle

37. 3 RV spots left

38. Important Dates: Nov 2: setup & bring a covered dish

39. Nov 4: Mandatory volunteer meeting

40. Nov 5-6: Pauwau

41. Nov 12: Outbrief at El Cerro at 2pm in Conway

42. Buildings & Grounds: Larry

43. Asked PW committee to consider straw bundles

44. Rick: need to spray for sand spurs before PW

45. Mark: fire ant spray? Donnie said we were out

46. Drum: Rick

47. Getting back together

48. Mark: grades for School Day?

49. Susan: all; special needs through high school,1050 students

50. Member Files (Office): Susan

51. Probably be after holidays before getting back to it

52. Parking Lot & Shuttle: in CM John’s proposal

53. Events

54. Invited to Waccamaw-Siouan Festival on 11/12

55. Invited to Massing of Colors on 11/12

56. Elder Doug: start raising funds for Special Needs Fishing Tournament & advertise it

57. Rick: need manpower

58. Receipts

59. Fuel: $59.81 Check 537

60. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

61. Chief Hatcher

62. Pauwau setup: cannot be here; 2nd Chief Phil will be here for audio setup

63. Had a meeting with Brockington with Rick

64. Federal recognition is looking good; possible problem with criteria E

65. They will do the research

66. They have good access with Mr. Clyburn

67. We don’t pay if they don’t get us recognition

68. Pauwau: always make sure two people are handling the money

69. Governor, Lt Governor, County Council, Chiefs invited

70. Election: Elders count the ballots

71. Pee Dee Indians: invited former Chief Caulder to be in grand entry too

72. Chloe Brianna Davis: minor of a member with guardianship

73. Mark motioned; Susan seconded

74. Homer-yes, Susan-yes, Robert-yes, Mark-yes, Dalton-yes, Rick-yes

75. Linda A: Bachelor in Genealogy: giving diploma to her at Pauwau

76. Susan: ANA training with Tap-E-Ya Bernie

77. Grant for living village

78. Could get enough money to also cover circus tent large enough to cover circle

79. Grant for building the grounds up

Mark motioned to close the meeting; Homer seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 11/30/16 at 10:45 am.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
