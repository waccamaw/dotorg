---
layout: post
title: "September Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2016/09/10/september-open-meeting-summary.html
post_id: 5649630
custom_summary: false
summary: ""
date: 2016-09-09T19:00:00-0500
lastmod: 2025-11-22T19:02:12-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2016/09/09/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Updated: Oct 12, 2024

Tribal Open Meeting Summary 09/09/2016 held at the Tribal Office in Aynor, SC

1. CM’s Susan, Homer, Mark, Dalton, John, and CoC Rick present.

2. Chief Hatcher invited CMA Chair Ken Battle to speak

3. Dalton: are there grants through the CMA?

4. Mr. Battle: no, we are a conduit and assist other organizations

5. Also look over your past grants to help improve them

6. August minutes read

7. Dalton motioned to accept; Mark seconded

8. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

9. Financial Report: Michelle (per CNB site)

10. General Fund: $10,073.76

11. Building Fund: $4,431.33

12. Old Business

13. Cemetery Trustees paperwork: no copies at office yet; need to get with Wayne

14. Census 2020: Susan

15. Count everyone once and in the right place

16. Can respond online, by phone, paper, in-home service

17. Need to contact census people about variations of tribe name

18. Waccamaw, WIP, Waccamaw Indians

19. Chief Hatcher: would like to see it all as Waccamaw

20. Susan: race question allows you to pick more than one

21. They are hiring temp positions for 2019; work from home or office

22. Can also work with office Atlanta

23. New Business

24. John: parking lot for bike weeks: would like committee to study it and he will  chair it

25. Mark motioned to create a committee to study parking lot during bike week; Rick seconded

26. Homer: why do we need committee when we park them?

27. Michelle: this isn’t for Pauwau

28. John: some hotels won’t let guests park bike trailer & cars at hotel

29. Contacted insurance carrier with no reply

30. Maybe get credit card swiper for payment?

31. Think we could make $20k/ week

32. Possibly shuttle them to their hotel?

33. Chief Hatcher: could put gates up if we need to

34. Dalton motioned; Mark seconded to create the Parking & Shuttle Committee

35. Dalton asked for Exception to Policy to allow a CM to be Chair

36. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

37. Ray, Susan said they would help with committee

38. Committee Reports

39. Arts & Crafts: Susan

40. Susan, Rick, Marion went to Brookgreen: trees soaking for suk

41. Volunteers from Brookgreen available on Monday & Tuesday

42. Chief Hatcher: would start stringing up shingles

43. Grants: Michelle

44. SCAC: PW committee decided to take the $1000 from SCAC (every little bit helps)

45. Pauwau: Michelle

46. Budget approval (handout)

47. Dalton motioned to accept; Susan seconded

48. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

49. Mark: don’t see why booth cost is included

50. Michelle: we could have sold the booth and made that money; nothing is free

51. Meetings are now on Thursdays instead of Wednesday

52. Billboards, Flyers changed to reflect help from SCAC

53. Rick: please look into trailer bathrooms

54. Chris H: try Elvis P-O-P

55. Chief: also get unisex bathrooms with locks

56. Wood: B&G to cut up 2 trees on the ground that have fallen

57. Constitution: Dalton

58. Newest copy available

59. Changes

60. Article V (A)(5), V (B)(3)

61. VI (G)

62. VII ( C) (1-3)

63. Mark motioned to accept as written; Homer seconded

64. Homer-yes, Susan-yes, John-abstain, Mark-yes, Dalton-yes, Rick-yes

65. Dalton: send letter of intent for CM seats this week (posted to FB)

66. Buildings & Grounds: Larry

67. Cemetery cut: someone remarking boundaries around cemetery

68. Rick thanked committee for help with pumpkin patch

69. Dalton: please don’t forget to spray grounds for ants before Pauwau

70. Drum: Rick

71. Will be able to drum for School Day

72. Member Files (Office): Susan

73. Will shred duplicate/ unneeded paperwork

74. Jeania brought more files to office tonight

75. Files need to be checked for 25 CFR 83.7 compliance

76. Jeania: when app is denied, we don’t have a letter, but we can create one

77. Officially completed a computer file for all member files

78. Receipts

79. Fuel: $27.50 Check 533

80. Mark motioned to accept, Homer seconded

81. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

82. Fertilizer reimbursement to Richard: $186.90 Check 1057

83. Mark motioned to accept; Homer seconded

84. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

85. 2nd Chief Cheryl

86. [#NoDAPL](https://www.waccamaw.org/updates/hashtags/NoDAPL) event 9/18 at SC Statehouse 2-5pm

87. Cemetery: initial filing: $150; registers of deeds may also charge

88. Chief Hatcher: letter talks about the dogs, shows the map, sent to Master in Equity, Mr. James, Governing Body

89. Chief Hatcher: if they are remarking boundaries, this may be solved soon; give it 1-2 weeks

90. John: one grave would be outside the fence line

91. Elder Dan: give him until next meeting since letter said 30 days

92. Chief Hatcher

93. Meeting in Alabama: Cherokee are trying to derecognize all state Indians

94. SCIAC letter in support of Standing Rock

95. Administration for Native Americans at DOI

96. Called them to create class, 10/11-13, 8:30am-5pm

97. Register on the site

98. DHEC emergency prep

99. Mark checked into it before: several schools closeby so this area covered

100. Chief Hatcher: check into it again

101. DHEC has job openings in Columbia

102. Events

103. Santee Pauwau: 9/17

104. Gray Court Pauwau: 9/24

105. Contract pending with archeologist; will email it to Council

106. CMA needs to commissioners

107. Help find funding for educating children

108. Chief Hatcher nominated Alan F to be our rep

109. Susan motioned to accept; Homer seconded

110. Homer-yes, Susan-yes, John-yes, Mark-yes, Dalton-yes, Rick-yes

111. John: Fall Equinox

112. Susan: 9/25

113. Chief Hatcher: John C wants to come back as Firekeeper

114. Earl-John C- Robert (length of service)

115. Chief to talk to John C & Robert

Mark motioned to close the meeting; Homer seconded.

Meeting adjourned 8:30 pm.

Respectfully submitted by Michelle Hatcher on 10/18/16 at 6:31 pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
