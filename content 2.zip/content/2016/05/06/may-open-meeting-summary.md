---
layout: post
title: "May 2016 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2016/05/07/may-open-meeting-summary.html
post_id: 5649689
custom_summary: false
summary: ""
date: 2016-05-06T19:00:00-0500
lastmod: 2016-05-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2016/05/06/may-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 05/06/2016 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Mark, Rick, Robert, Susan, Homer, and CoC John present.

2. Open Forum held

3. April minutes read

4. Susan motioned to accept; Dalton seconded

5. Dalton-yes, Mark-yes, Rick-yes, Robert-abstain, Susan-yes, Homer-yes, John-yes

6. Financial Report

7. Unavailable at this time; will try to get from Lori by email

8. Old Business

9. Policy Letters

10. Camping on the Grounds (non-PW)

11. Use of the Tribal Grounds (non-camping)

12. Goes with Tribal Grounds Rental Agreement

13. Mark: still don’t think members should have to pay

14. John: we reviewed it in April

15. John: can we use heaters now that we have full electric on the posts?

16. Chief Hatcher: shouldn’t be a problem

17. Rick: on fees, it’s an incentive for people to keep membership fees up-to-date if we don’t charge them to use the grounds

18. Homer: $25-50 is cheap to enjoy a day

19. Use of the Tribal Office

20. Goes with Tribal Office Rental Agreement

21. Mark: same complaint; members should not have to pay

22. Votes on Letters

23. Camping on the Tribal Grounds (non-PW)

24. John motioned; Rick seconded

25. Dalton-yes, Mark-yes, Rick-yes, Robert-abstain, Susan-yes, Homer-yes, John-yes

26. Use of the Tribal Grounds (non-camping)

27. John motioned; Dalton seconded

28. Dalton-yes, Mark-no, Rick-yes, Robert-abstain, Susan-yes, Homer-yes, John-yes

29. Use of the Tribal Office

30. John motioned; Dalton seconded

31. Dalton-yes, Mark-no, Rick-yes, Robert-abstain, Susan-yes, Homer-yes, John-yes

32. Cemetery Encroachment: 2nd Chief Cheryl

33. Need to file with probate to stop distribution of the estate; going to call Hope Martin to find out the best route to stop the James family actions; it will force us into mediation

34. John: what is the initial step’s cost?

35. 2nd C. Cheryl: unsure; as claimant, it may not cost anything

36. John: if we start the process to hold him up and he doesn’t want to mediate, we have to be prepared to put more money in, correct?

37. 2nd C. Cheryl: correct

38. Chief Hatcher read the motion they are preparing, which will include all deeds, surveys, and attachments required

39. John: and we would take that to probate?

40. 2nd C. Cheryl: yes

41. Chief Hatcher: it’s been my experience that if you already have a case number, you aren’t charged

42. John: financially, what is our burden?

43. Chief Hatcher: nothing right now

44. 2nd C. Cheryl: minimal; we are asking the judge to not give an order so we can make a claim against his estate which will force him to defend against us

45. John: and if we go further, then there’s money involved?

46. Chief Hatcher: the onus is on him to prove we are wrong

47. John: are we willing to put up what we have for a court battle?

48. 2nd C. Cheryl: court can’t issue an order while the estate isn’t settled

49. John: how long can it drag out?

50. Chief Hatcher: months or years

51. Mark: what about the value of the trees that he had cut down?

52. 2nd C. Cheryl: that is a Masters-In-Equity issue

53. John: can we stop them from using the parking lot?

54. 2nd C. Cheryl: “No Trespass” signs have to clearly visible

55. John: if we were to call the police and say cars are on our private property, would they come out?

56. Mark: with pictures, it shouldn’t be a problem

57. Rick: have them towed

58. John: we aren’t settling the issue if it can be drawn out

59. Chief Hatcher: hope is that he can’t do anything with it until probate settles it

60. Dalton: if you post signs and cops go out there, they will usually force the other people to leave; I wouldn’t have them towed though

61. 2nd C. Cheryl: problem is there is no paper trail right now

62. Dalton: what about the eviction notice?

63. Chief Hatcher: that was done, but the man told other people they could live there before he died

64. Rick: in the meantime, he can take pictures of our signs and us and say we are the ones trespassing

65. Homer: if we file, he may just move out

66. Chief Hatcher: he already told me to file

67. Mark motioned; Susan seconded to file with probate court with costs paid for by John

68. Dalton-yes, Mark-yes, Rick-yes, Robert-yes, Susan-yes, Homer-yes, John-yes

69. New Business

70. Open Forum Discussion

71. TRB Closed

72. Chief Hatcher: spousal member whose spouse has died

73. Dalton: current constitution: her membership ended when her spouse died

74. Mark motioned to make all aspects of associate memberships controlled by Chief until the new constitution; Dalton seconded

75. Dalton: New constitution ready in a month to be sent for a vote

76. Mark rescinded his motion

77. Tabled till next month

78. Chief Hatcher: can I issue them an honorary membership instead of associate membership?

79. Dalton: all parts of associate, yes

80. Susan: do they need paperwork if done this way?

81. Chief Hatcher, Michelle: all files need paperwork

82. Chief Hatcher: problem is, right now, we have 400+ files to go through to make sure they are really complete

83. Dalton motioned to modify her membership to Honorary and reinstate Joan Ammons; Mark seconded

84. Dalton-yes, Mark-yes, Rick-yes, Robert-yes, Susan-yes, Homer-yes, John-yes

85. Committee Reports

86. Arts & Crafts: Susan

87. Contacted by Brookgreen Gardens; work with them to build a suk

88. Funded by them; use willows from here

89. Use pvc pipe and cedar/ cypress-looking shingles

90. Chief Hatcher: pricing to include materials for 2 (one for here, one for Brookgreen)

91. They will put a sign up about us at Brookgreen

92. Grants: Michelle

93. SCAC: will hear back in mid-June

94. Pauwau: Michelle

95. Ad forms and flyers available on table for everyone to assist us

96. Dalton to call on past ad donors

97. Michelle to start working on PSA list

98. John: can we (John, Michelle, Chief Hatcher)  meet with the mayor?

99. Sure, set up date/ time

100. Mark: suggestion: raise RV camping prices to $35 because of new electrical posts

101. Next meeting: 5/11/2016 @ 6pm

102. Constitution: Dalton

103. Newest constitution available

104. Susan is getting cost of printing & mailing them through M&M

105. Buildings & Grounds: Larry

106. Bathrooms: working on the cost for 3 stalls

107. Mark: get with Chris Hatcher for plumbing materials at low price

108. Elder Doug: also look for them in other places besides here locally

109. John: take pictures for us

110. John: roof doesn’t seem to be as leaky

111. Drum: Rick

112. 2nd C. Phil is trying to learn so he can help us

113. Rick motioned to allow 2nd C. Phil use of the small drum at his residence until otherwise noted; Homer seconded

114. Dalton-yes, Mark-yes, Rick-yes, Robert-yes, Susan-yes, Homer-yes, John-yes

115. Receipts

116. John: Donnie paid for these receipts out of his pocket

117. John motioned to allow Donnie to use the tractor repair receipt and one gas receipt to offset his rent; Mark seconded

118. Dalton-yes, Mark-yes, Rick-yes, Robert-yes, Susan-yes, Homer-yes, John-yes

119. Fuel Receipt paid back to Donnie

120. $20.00 Check 683

121. Fishing Day

122. Mark: overspent by $200.86: Check 685

123. Rick: need check for Gary’s Pumping: Check 684

124. Need Council’s input if this event grows much bigger

125. We bought one tent in case we needed it

126. Mark: would like to do it on a permanent weekend date and make business cards with Fishing Day on one side and Pauwau on the other (Dori’s idea)

127. John: going to have to put a limit on the number of people in the future

128. Michelle: send out registration forms ahead of time

129. Dalton: I would like $100 to promote our tribal Facebook page: Check 686

130. Chief Hatcher

131. Cemetery: had Ms. Hilda read the motion over

132. Gary Green (?)

133. Federal recognition: 2PhD’s willing to put their credentials on our petition

134. Go through BIA because Congress can add amendments to it

135. Elder Doug: wolves in TN; not taking care of the land

136. Chief Hatcher: they are supposed to keep it in good condition

137. Rick: where would be if the wolves were to hurt someone?

138. Dalton: that’s on them

139. Jim Murphy: grand opening in Nashville soon; we’re invited

140. Cemetery trustees: Elder Dan

141. John: Richard, Linda, Wayne, Hilda

142. May need someone to take Wayne’s place if he resigns

143. Gifts from John Blackfeather: flags, Eagle Staff, and stands

144. Sending John Blackfeather a letter signed by everyone and framed

145. Bills: hunting and fishing licenses, game parts, and discontinuation of future groups (former S611, in House now)

146. Andrew Jackson’s picture will be put on the back of the $20 bill now

147. Copier: Dustin will be by to look at it and also looking for a new one

148. John: do we need one this big?

149. Susan: we use all of its functions

150. Homer: any thoughts to fencing the property in to keep derelicts out (example: bike weeks)?

Susan motioned to close the meeting; Mark seconded.

Meeting adjourned 8:35 pm.

Respectfully submitted by Michelle Hatcher on 05/27/16 at 2:17 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
