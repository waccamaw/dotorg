---
layout: post
title: "February 2016 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2016/02/06/february-open-meeting-summary.html
post_id: 5649686
custom_summary: false
summary: ""
date: 2016-02-05T19:00:00-0500
lastmod: 2016-02-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2016/02/05/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/5/2016 held at the Tribal Office in Aynor, SC

1. CM’s Homer, Susan, Robert, Mark, Dalton, and CoC John present. 2nd Chief Cheryl served as proxy for CM Rick.

2. January minutes read

3. Mark motioned to accept; Homer seconded

4. Robert-yes, Mark-yes, Rick-absent, Homer-yes, Dalton-yes, John-yes, Susan (2nd Chief Cheryl)-yes

5. Financial Report

6. General Fund: $9957.22

7. Building Fund: $3436.17

8. Susan motioned; Robert seconded to transfer $300 from building fund to general fund because money was deposited into wrong account

9. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-yes, Susan-yes

10. Online Votes

11. 12/15 Have Chief Hatcher & Hilda file charges with magistrate against Mr. James

12. Homer-yes, Susan-yes, [Rick-yes], John-yes

13. 12/15 Buy toner for the copier

14. Homer-yes, Susan-yes, [Rick-yes], John-yes

15. 1/20 Rent bobcat

16. Susan-yes, Dalton-yes, [Rick yes], Mark-yes, Homer-yes, Robert-yes

17. 1/20 Purchase Hydrostop roof coating

18. Susan-yes, Mark-yes. Dalton-yes, Homer-yes, John-yes, [Rick- yes], Robert-yes

19. Old Business

20. Cemetery Encroachment

21. Letter sent to Mr. James; no response

22. Contacted 2 lawyers

23. John: concern is if we give him this spot now, he’ll add more later

24. Glenn T suggested contacting Southern Poverty Law Center; 2nd Chief Cheryl to look into

25. 2nd Chief Cheryl suggested also contacting SC Legal Services

26. John: tell him we’re entitled to 2 acres; if not the current spot, where?

27. Mediation (though he would have to agree to it)

28. Mark: if we take him to court and win, is he liable for the value of the trees he took out?

29. Answer: yes, triple

30. Chief Hatcher: let 2nd Chief Cheryl contact Mr. Beverly

31. Elder Doug: use gofundme to raise money for lawyer

32. New Business

33. Committee Reports

34. Arts & Crafts: Susan & 2nd Chief Phil

35. Put 4 display cases up at Native American Studies in Rock Hill

36. Artists who want to display items there, let Susan/ Phil know

37. Can swap items in and out for 1-2 years

38. Get tables & building ready on the grounds to teach crafts

39. Elder Doug: have grapevine at home for those who use it

40. 2nd Chief Phil (phone): artists need to prepare descriptor cards for their items & help set up

41. 3/23 grand opening

42. Don’t use illegal parts on your art

43. funded by SC government & USC

44. First tribe to put certified SC art in display

45. Grants: Michelle

46. SCAC grant due 3/15; artists who want to change or update their biography, please email Michelle

47. Chief Hatcher” going to write the Accommodation Tax grant; worth $20,000

48. Pauwau: Dalton

49. Nearly all demonstrator positions filled

50. Billboards ready other than date change

51. Need to decide theme for program book

52. Meeting with Mayor to discuss park

53. Constitution: Dalton

54. Articles 5-11 done

55. Ready for a complete read-through before giving it to Council

56. Next meeting 3/3/2016 @ 6:30 @ tribal office

57. John: would be nice to have an elder or associate member come to the meeting

58. Buildings & Grounds: John

59. Crushed concrete: didn’t go as far as anticipated

60. Mark: need to raise area up before putting more concrete down

61. Roof: have materials; need 2-3 dry days before and 1 after while doing it

62. Need gutters

63. 2nd CHief Cheryl: son will help if not working

64. Elder Doug & Mark are buying a flagpole; need a location to put it because the plan is to cement it into the ground

65. John: going to need a light if you plan to leave it up

66. Left side of drive on the corner

67. Write state for SC flag

68. Johnnie F: ask Phil if they will donate once to use since he is there a lot

69. Robert motioned; 2nd Chief Cheryl seconded to allow Mark & Doug to install a flag; motion rescinded

70. Robert motioned; 2nd Chief Cheryl seconded to allow multiple flagpoles to be cemented into

71. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-yes, Susan-yes

72. Drum: Chief Hatcher

73. Dispute between drum and Clyde; Clyde dropped off

74. Drum is currently Rick & Glenn; trying to get them all back together

75. Johnnie: a father & son in Columbia would like to drum with them

76. Receipts: $80.93 check 1052

77. Mark motioned; Robert seconded

78. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-abstain, Susan-yes

79. Membership Fees

80. John: if we took in all fees, it would be $10-12k per year

81. Dalton: go to 1 year card. Instead of membership fee, make it a renewal fee of $50

82. Mark suggested it be 2 years

83. Jeania: 2 years, but pay the annual fee; vote after 90 days of a fee renewal date

84. 2nd Chief CHeryl: do every 4 years (runs with elections)

85. Alan F suggested staggering them to avoid overwhelming the person tracking them

86. Chief Hatcher: take expiration date off completely; use unique sticker like license tags

87. John to Council: look her proposals over; make comments; make list online

88. 2nd Chiefs

89. Drum will be at Loris Multicultural Festival

90. Chief

91. Met with Sen. McElveen & CMA

92. consented to introduce 3 bills for us

93. Let Natives that are 101.64 compliant use all game parts

94. Free hunting & fishing licenses for Natives

95. Stop group recognition

96. Jerry Brown: offered us the opportunity to move Native issues into their building; has to go through legislature

97. Sent letters to Pope & President

98. First federal recognition committee meeting today

99. Criterion E did not change

100. have to go back as far as we can

101. Files: Linda wants to be in charge of the files

102. Elections: even numbered seats (John, Dalton, Mark, Rick) run this year

103. Newsletter needs to be done more steadily

104. Longest Walk 5: permission to allow them to camp on grounds while here

105. Dalton motioned; Mark seconded

106. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-yes, Susan-yes

107. end of June 2016

108. Land in Latta: Susan motioned that the tribe will pay for the survey when the land is donated; Dalton seconded

109. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-yes, Susan-yes

110. Membership Files

111. Chastity Marie Faver Parks

112. Robert-yes, Mark-yes, Rick (2nd Chief Cheryl)-yes, Homer-yes, Dalton-yes, John-yes, Susan-yes

113. Family Day 2/20

114. Fire Ceremony at dawn, 12

115. Lunch around 12-1

116. Susan: Dept of Applied Research

117. Archeology survey work at Hobcaw 2/22- ¾

118. Marion C & his 2 sons files given to Council

119. Genealogy

120. Chief Hatcher: have 1 book at office for all genealogists to use

121. Susan and Cheryl to coordinate with Linda & develop policy book for genealogy

122. All files have to be screened for missing pieces

Mark motioned to close the meeting; Dalton seconded.

Meeting adjourned 9:07 pm.

Respectfully submitted by Michelle Hatcher on 3/3/16 at 4:19 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
