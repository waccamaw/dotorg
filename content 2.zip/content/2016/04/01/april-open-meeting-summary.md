---
layout: post
title: "April 2016 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2016/04/02/april-open-meeting-summary.html
post_id: 5649688
custom_summary: false
summary: ""
date: 2016-04-01T19:00:00-0500
lastmod: 2016-04-01T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2016/04/01/april-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 04/01/2016 held at the Tribal Office in Aynor, SC

1. CM’s Dalton, Mark, Rick, Homer, and Susan present. CoC John arrived later in the meeting.

2. Open Forum held

3. March minutes read

4. Susan motioned to accept; Mark seconded

5. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes

6. Financial Report

7. General Fund: $9540.30

8. Building Fund: $3520.24

9. Online Votes

10. 3/27 Contract for Donnie

11. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes

12. 3/31 Lawnmower Repair

13. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes

14. Old Business

15. Policy Letters

16. Camping on Grounds: Susan: stipulate walkpath for pets (outside treeline)

17. Rick: fish is catch & release if using pond

18. Rental of Office: rentor provides all equipment & supplies

19. Waiver like on pauwau camping form

20. Rental of Grounds: waiver like on pauwau form

21. Rentor provides all equipment & supplies

22. Mark: don’t think members should have to pay to use their property

23. John: if your dues are current, you can rent

24. Dalton, Susan rescinded motion on lawnmower repair; Donnie had it running at meeting

25. Cemetery fund: $511

26. Mark: need someone to make crosses & mark graves

27. Larry volunteered

28. Rick suggested pvc (looks like wood but won't rot)

29. Cemetery Encroachment

30. 2nd Chief Cheryl suggested filing in circuit court or sitting down with James’ family & our attorney

31. New Business

32. Open Forum Discussion

33. Marion C attended fire keeper meeting

34. Rick: Fishing Day: May 7: $685 budget

35. CCU students not going home for break are planning to attend

36. Contact Mayor

37. Rick, Chief Hatcher, & John donated $100, Mark donated $50, Glenn donated $30

38. John motion to spend up to $285 from general fund on this endeavor

39. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes, John-yes

40. Committee Reports

41. Arts & Crafts: Susan

42. During Spring Equinox, 2nd Chief Phil demonstrated feather wrapping, Susan demonstrated medicine bags

43. 3/23: grand opening Native American Studies at USC-Lancaster; have room until 2/2017

44. Grants: Michelle

45. SCAC: had to cut down the number of pictures I sent them by half

46. Chief Hatcher: ATAC: funded at approximately $3800; has to be voted on by Horry County Council

47. 2nd Chief Cheryl: need to track where attendees are coming from

48. Short exit surveys with zip code

49. Pauwau: Michelle

50. 2nd Chief Cheryl made copies of the ad form

51. CM Susan made copies of the flyer

52. Looking for suggestions for this year’s front cover theme

53. Having a fundraiser at Hog Heaven 6/14

54. Next meeting 4/13 at the tribal office at 6pm

55. Chief Hatcher: have local hotels write letters stating that they have increased occupancy during the dates of the pauwau

56. Constitution: Dalton

57. Need to go over the whole thing up to Wed before the next meeting

58. Will make sure to send most current version to Council

59. Buildings & Grounds: Larry

60. Larry recently nominated to Chairperson

61. Work Day Sat 4/9

62. Drum: Rick

63. Played at Johnnie F’s funeral

64. 4/14 playing at Polynesian event

65. Fuel Receipts

66. $31.28 Check 679

67. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes, John-yes

68. Membership Fees: Jeania

69. Need to bring %

70. 2nd Chiefs

71. Send invoices for membership fees

72. John: can’t do that until policy is changed

73. Currently, a member can wait until their card expires and then pay their membership fees in full to bring themselves up-to-date

74. Chief

75. Meeting this week with Dr Poplin (federal recognition committee)

76. Need to rescind previous decision to go through Congress

77. Mark motioned to undo the petition to Congress and send one to BIA; Homer seconded

78. Homer-yes, Susan-yes, Rick-yes, Mark-yes, Dalton-yes, John-yes

79. 2nd Chief Cheryl: petition could be strengthened by archeological digs at Hobcaw

80. Pauwau - Pee Dee- in McColl this weekend

81. 4/14 Hokule’a event in Charleston

82. Longest Walk 5: 23 cases of MRE’s coming

83. Newsletter: need someone to take it over

84. Would like Dan Fuller to represent us at Aynor Chamber of Commerce meetings

85. We have trained Blackfeather Singers for us and 2 other tribes now

86. Susan: Genealogical Protocols

87. We can write procedures

88. Next version of Family Tree Maker is the last one

89. 2nd Chief Cheryl: we verify the work submitted; we don’t complete the work and then check the work too

90. Susan: copier

91. Will cost approximately $2700 to replace

Mark motioned to close the meeting; Susan seconded.

Meeting adjourned 9:45 pm.

Respectfully submitted by Michelle Hatcher on 04/07/16 at 11:52 am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
