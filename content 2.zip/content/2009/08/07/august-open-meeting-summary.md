---
layout: post
title: "August 2009 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2009/08/08/august-open-meeting-summary.html
post_id: 5649640
custom_summary: false
summary: ""
date: 2009-08-07T19:00:00-0500
lastmod: 2009-08-07T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2009/08/07/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 8/7/2009 held at the Tribal Office in Aynor

1. No minutes to read due to technical error. Attach July and August minutes to September.

2. Financial Statements

3. 4.

Jerry: $260 donations

5. Iris: $4097.67

6. 1.

7. $300 for judge training

8. Total in bank $3797.67

9. Committee Reports

10. 11.

Grants- Michelle

12. 1.

13. Recovery Act - Health Care Sector and Other High Growth and Emerging Industries Grant from the Department of Labor

14. Free to reduced cost; must ask by 10/5/2009

15. 16.

Building & Grounds- Neal

17. 1.

18. Neal given thanks for work, tipi pulls, and grave area

19. Painting Donnie’s trailer should be done by pauwau

20. Markers/ concrete around grave

21. Longhouse/ sook- 20ft long

22. 1.

      1. 23.

Cover- canvas?

24. 1.

      1. 1.

25. Doug mentioned the Ellerbe Museum

26. Becky mentioned a shop on Hwy 90

27. NMB Canvas & Awning

28. Bernie mentioned state procurement

29. Homer mentioned giving donators tax write-off letters

30. 1.

      1. 31.

Nature walk to cedar trees with benches

32. Tipi locations still unknown

33. Waccamaw Indian People sign near driveway

34. Bamboo rails, log benches

35. Permanent & portable tent for gate

36. 37.

Arts & Crafts- Brian

38. 1.

39. Met 7/29/09

40. Brian elected new chair

41. Working on admin manual; Carol Ann’s PC is down

42. Criteria set for judging

43. At the first A&C meeting, Buster suggested letting people do their own research

44. 1.

      1. 45.

People will do their own research and add to the list, like a living document

46. 1.

47. Bernie wants to see circle defined in pauwau program book, feather- veterans write back for it

48. Brian only sends email to CoC, not entire Council unless necessary

49. 50.

Pauwau- Linda

51. 1.

52. Meeting 8/8/09; please sell ads

53. Turning book in to printer in September (15th)

54. Jerry- food booth; 2-3 extra food vendors- discuss at 8/8 meeting

55. Homer mentioned some people ate as dancers who weren’t dancers

56. 1.

      1. 57.

Another asked if we should stamp their hands

58. We have a system in place, but will discuss it

59. 1.

60. 6 vendors confirmed

61. Pauwau Budget- $15k

62. 63.

Iris (Richia) motioned to approve; Dalton seconded

64. Homer-yes, Robert-yes, Iris (Wayne)-yes, Iris (Richia)-yes, Dalton-yes, Scott- yes (passed, 1 absent)

65. Waccamaw Day Resolution (J-HH-07-10-2009-001) received its second reading

66. Neal- $50 reimbursement for tractor parts; sent by Reba ($55)

67. Online votes

68. 69.

Donnie- okay to bring car out here to work on: yes

70. Horry Independent 8/6/09 ran story on Aynor Bypass

71. Linda- 3/14/10 will be Grandma

72. Phone Bill

73. 74.

Jeanie paid overages

75. Linda has phone now

76. Boy from NC sent email and called; said he turned in an app to Jeanie and talked to Susan. Linda told him to contact Iris; last name is Jones

77. Tribal hours 8-5; cut phone off unless you are using it for pauwau business

78. 2nd Chief Iris from Buster

79. 80.

Resolution J-HH-07-25-2009-001: Appointment of Tribal Judge and Associate Judge read

81. 1.

82. Dalton motioned to accept; Homer seconded

83. Homer-yes, Robert-yes, Iris (Wayne)-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (passed, 1 absent)

84. 85.

Honorary Membership for Roshell Mason (sp?) tabled- no file or paper

86. Meeting with Catawbas later this month

87. Need office in working condition; Work day

88. Linda- status of food bank- FEMA will have one; we do not have to find the location

89. 1.

90. Homer still wants to do one

91. Neal stated Craig Talbot was helping with a project that gives food away at $0.19 per pound if you qualify

92. William Moore

93. 94.

Robert-motion; Homer- second

95. Homer-yes, Robert-yes, Iris (Wayne)-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (passed, 1 absent)

96. Patricia Brinson sent resignation letter with no identification card (only photocopy)

97. Heating & air- needs fixed; Iris to send information

98. 99.

Dalton-motion; Robert- second

100. Homer-yes, Robert-yes, Iris (Wayne)-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (passed, 1 absent)

101. Quarterly financial statement in September

102. Linda- Richia still needs a certificate

103. Brian to sponsor Craig Talbot next month

104. 105.

Elder Jerry Smith made comments about applicant's file.

106. Homer encouraged closer scrutiny of applicants

107. Iris asked to be placed on the agenda for next month

Homer Motioned and Robert seconded for the meeting to end.

Meeting adjourned at 8:53pm

Respectfully submitted by Michelle Hatcher on 8/09/2009 at 2:21am

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
