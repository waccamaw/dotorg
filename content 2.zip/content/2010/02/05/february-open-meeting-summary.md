---
layout: post
title: "February 2010 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2010/02/06/february-open-meeting-summary.html
post_id: 5649642
custom_summary: false
summary: ""
date: 2010-02-05T19:00:00-0500
lastmod: 2010-02-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2010/02/05/february-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 2/5/2010 held at the Tribal Office in Aynor

1. January summary read

2. Susan (Richia) motioned, Robert seconded

3. Dalton-yes, Susan (Richia)-yes, Robert-yes, Homer-yes, Neal-yes, Scott-yes

4. Minutes accepted by majority

5. Financial Report: Iris

6. $10337.93 in bank including pending transactions

7. $750 Verizon grant incoming

8. Committee Reports

9. Building & Grounds: Neal

10. Filing cabinets painted

11. Craig brought sweat lodge plans

12. Gas for lawn mower

13. Arts & Crafts: Brian

14. Meeting held on 30th

15. Brian (Chair), Susan (Co-Chair), Cha'kwaina (Secretary)

16. 2/20 deadline for manual

17. Work on organizational operations manual next

18. Susan has application done

19. Next Friday- vote

20. Deborah- criteria manual

21. Feathers

22. 4/16: next meeting

23. Video of doing feathers- Susan

24. Tent for art display

25. 1 member resigned

26. CoC Scott: commend for good job

27. Chief Buster: elaborate on problem

28. Brian: goes back to the word “certify”

29. Chief Buster- used to make sure art is real and uses real materials

30. 2nd Chief Susan read the current certificate out loud

31. Chief Buster suggested changing “Native American Art” to “Waccamaw Art”

32. Criteria- Council needs to do research too

33. “For Display Purposes Only” needs to be put on some art

34. Some art is not functional

35. Neal has clay at his house if anyone needs it

36. Grants: Michelle

37. Still looking at the Pepsi Refresh Grant

38. PauWau

39. No Report

40. Family Day

41. Neal: set up tents that morning

42. Craig- tipi set up too

43. Iris has trampoline and stand-alone basketball stand to donate

44. Online Votes

45. Turner Smith

46. Homer-yes, Neal-yes, Dalton-yes, Robert-yes, Jeanie-yes, Scott-yes

47. 6 for, 0 against, 1 absent

48. Deva Marie Barber

49. Jeanie-yes, Dalton-yes, Homer-yes, Neal-yes, Robert-yes, Scott-yes

50. 6 for, 0 against, 1 absent

51. Charles Creech

52. Dalton-yes, Robert-yes, Neal-yes, Homer-yes, Jeanie-yes, Susan (Richia)-yes, Scott-yes

53. 7 for, 0 against, 0 absent (passed unanimously)

54. Books- $130 Federal Recognition Petition abbreviated version

55. Thanks to Susan and Cheryl

56. Dalton-yes, Robert-yes, Neal-yes, Homer-yes, Susan (Richia)-yes, Scott-yes

57. 7 for, 0 against, 0 absent (passed unanimously)

58. Copy Machine Repair

59. Robert: Can we get a service contract on this one?

60. We would have to check into it; could be more costly than just repairing every few years

61. Dalton-yes, Robert-yes, Neal-yes, Homer-yes, Jeanie-yes, Scott-yes

62. 6 for, 0 against, 1 absent

63. CoC Beaver motioned to accept Michelle as official Tribal Secretary

64. Dalton abstained

65. Neal seconded

66. Robert-yes, Neal-yes, Homer-yes, Susan (Richia)-yes, Jeanie-yes, Scott-yes

67. 6 for, 0 against, 1 abstained (passed by majority)

68. Norma thanked for her service

69. 2nd Chief Susan

70. Census Bus: may use us for questionnaire spot for 2-3 days

71. Still hiring

72. Huntington State Park- 3/17 would like us to come back this year

73. Hours are 10-3

74. May be able to put us all together this year

75. Newsletters

76. Maybe do every other month this year because of election

77. Trying to send out as many via email as possible

78. Next newsletter in April; info to go in by 3/15

79. Buster- Council needs to decide on cutoff date for elections and letters of intent

80. Dalton suggests 6/15 (last newsletter before election)

81. Dalton motion, Homer seconded

82. Dalton-yes, Robert-yes, Neal-yes, Homer-yes, Jeanie-yes, Susan (Richia)-yes, Scott-yes

83. Passed unanimously

84. Homer suggests doing it this way every year

85. Takes a resolution to do it this way

86. Chief Hatcher

87. Donnie

88. If we were to rent Donnie’s trailer out, we would get $300-400 per month

89. During summer, grounds and cemetery are cut

90. Chief Hatcher suggested we pay Donnie $100 per month

91. Homer: look into flat plan and pay Donnie’s light bill each month

92. Iris: We have $10,000 in bank. No objections, but we have to look at the big picture

93. Buster: Effective 1/1/10, $100 till Council says the tribe can no longer afford it; Susan (Richia) seconded

94. Dalton-yes, Robert-yes, Neal-yes, Homer-yes, Jeanie-yes, Susan (Richia), Scott- yes

95. Passed unanimously

96. As of today  (2/5/2010), we owe Donnie $200

97. DC Trip

98. Lieberman met

99. Petition given to 5 Congressmen

100. Written Obama 10 times

101. BIA/ BAR: would like more classes

102. Would like to remove the right of Council members to use a 2nd Chief as their proxy

103. Shouldn’t have proxies

104. Should lean on Council members to be here

105. Craig: Gary Anderson passed away

106. Fireproof filing cabinets on order; should arrive in 10 days

107. Haven’t looked into PC yet

Homer motioned for the meeting to end; Neal seconded.

Meeting adjourned 8:01 pm.

Respectfully submitted by Michelle Hatcher on 2/8/10 at 2:55pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
