---
layout: post
title: "December 2010 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2010/12/04/december-open-meeting-summary.html
post_id: 5649646
custom_summary: false
summary: ""
date: 2010-12-03T19:00:00-0500
lastmod: 2010-12-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2010/12/03/december-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 12/03/2010 held at the Tribal Office in Aynor

 1.    Meeting opened at 7:10pm with CoC Scott and CM's Robert, Neal, Homer, Dalton, and 2nd Chiefs Susan (Jeanie) and 2nd Chief Iris (Richia) present.

 2.    October minutes read

 a)    Robert motioned to accept; Neal seconded

 b)    Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes; (7yes, 0no, 0abstain)

 3.    Financial Report: 2nd Chief Iris

 a)    $6494.03

 b)    $1.36 off balance

 c)    doesn't count bills for this month

 d)    annual report: what does Council want on it?

•  Whole register

 e)    Need office supplies, postage, Linda needs file folders

•  $200 for supplies Susan motioned; Neal seconded

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Dalton-yes, Scott-yes, Iris (Richia)- abstain; (6yes, 0no, 1abstain)

 f)      PW & SD financial reports handed to Council

 4.    Resolution SB-10-03-2010-001 Establishing Elections Committee received its 2nd reading

 5.    Resolution DH-12-03-2010-001 Certification of 2010 Tribal Elections

 a)    Scott motioned; Robert-seconded to accept with changes (format to 1 page and put all write-in names on the resolution)

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes; (7yes, 0no, 0abstain)

 6.    Resolution DH-12-03-2010-002 Associate Judgeship Role read

 a)    Homer motioned; Scott seconded to accept with change (has received or will receive the required training)

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes; (7yes, 0no, 0 abstain)

 7.    Online Votes

 a)    grass: Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 8.    Membership Files

 a)    Billy Floyd Toler, Jr

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 b)    Samantha Toler

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 c)    Tiffany Toler

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 d)    Fred Wright

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 e)    Daniel Barber

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 f)      Jerry Barber, Jr.

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 g)    John Kennedy, Jr.

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 h)    Neslihon Cerezon

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 i)      Ashton Wiggins

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 j)      Rigena Hatcher

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 k)    Stephen Windburn

•  Robert-yes, Neal-yes, Susan (Jeanie)-abstain, Homer-yes, Iris (Richia)-abstain, Dalton-yes, Scott-yes (5yes, 0no, 2abstain)

 l)      Jessica Windburn

•  Robert-yes, Neal-yes, Susan (Jeanie)-abstain, Homer-yes, Iris (Richia)-abstain, Dalton-yes, Scott-yes (5yes, 0no, 2abstain)

 m)  Joseph Windburn

•  Robert-yes, Neal-yes, Susan (Jeanie)-abstain, Homer-yes, Iris (Richia)-abstain, Dalton-yes, Scott-yes (5yes, 0no, 2abstain)

 n)    Margie Ellen Reeves

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes (7yes, 0no, 0abstain)

 9.    Committee Reports

 a)    A&C: Brian

•  Committee changed A&C Admin manual

•  Rules and Regulations for committee itself is done

•  Susan will send application manual to Tribal Council when done

•  Culture Classes

•  Drum Group, Arena Director

•  Instead of paying so much to put PW on each year

•  Grants for doing things (ex: Nancy Basket has a grant)

•  Fundraisers

•  Has his own site and will use it for the artists: waccamawartists.com

•  Artists can link to it

•  Plan to make Waccamaw T-shirts

•  Clear something up: No one has been kicked off the committee

•  Chief Hatcher: you're taking over feathers?

•  Brian: yes; I've got 107 beads; meeting 3rd Friday in January (3pm) to set day to make feathers

•  Mr. Moore working on language- Council has to decide which language

 b)    Grants: Michelle

•  Nothing to report yet

 c)    B&G: Neal

•  Animal control caught dog and pups

•  Restroom repaired

•  suk done; water-sealed, but will need another coat

•  donated deep freezer- Council to declare value

•  $200 Dalton motioned; Robert seconded

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes

•  2nd Chief Iris to email receipt

•  Wayne finished railings on Donnie's trailer

•  Thank you to Golden Eagle

 d)    PW: Linda

•  Thanks to everyone; appreciate all the help

•  Good committee that worked well together

•  2nd Chief Susan: thanks to all for working SD

 10.Homer

 a)    Thanks to all who worked the gate

 b)    Article in The State paper

 c)    Alcohol consumption on the grounds- our grounds are hallowed

•  We decided 1 person could drink in their residence

•  I didn't see it, but heard a lot about it

•  Neal: if we catch them, we don't need to run them off- they put more people at risk. We need to put them in jail

•  Chief Hatcher and CoC Scott: it was a tent campsite behind tipis

•  Use larger signs next year

•  Dalton: two things: one- illegal to be noticeable drunk in public and two- PW is a public event. We can ask them to leave (Chief Hatcher's purview)

•  Brian: agree with Neal; We have a couple of tribal people with arrest authority

•  Chief Hatcher: agree with Homer. Problem is, it wasn't on the tent/ camping application. Problem with going to jail is that we don't have one. County will do it at $2000/ day. You can't touch them with state-certified badge.

•  Constable wasn't here for the PW

•  Elder Doug: off-duty cops?- Chief Hatcher- they have a cost per day too

•  Need a written agreement on forms

•  Question is, when does the PW start and end (each day or through the whole weekend)

•  Brian: can't get around the $2000/day?

•  Chief Hatcher: only if they break a county law and not a tribal law

•  Also dogs and pets- agreement must be enforced

 11. Chief Hatcher

 a)    Looking at business opportunities for the future

 b)    Lady trained in Management and Problem Resolution that may help us better manage the tribe

 c)    SD/ PW: not as good this year as last, but thanks to all; good job

•  Want to coordinate earlier on drum

•  Susan and Linda to give Buster names for appreciation dinner @ Ryan's on 12/11 @ 3pm

•  Secretary's Note: Changed to 12/12

 d)    Notified CMA and Secretary of State about 2010 elections results

 e)    Due a Newsletter and suggest putting Constitutional change (Richia's resolution) in there to be voted on

 f)      The State article

•  Brian: he doesn't tell people that he's a holy man. He says he's Waccamaw. He tells people that Robert is our holy man.

•  2-3 people to sit down with man and come up with resolution on 1/15

•  Brian, Homer, Scott, Dalton

 g)    Elder Doug: why do we invite certain people to the PW?

•  Chief Hatcher: I chair the SCIAC; you invite all the Chiefs

 h)    Need letterhead and envelopes

 i)      Internet card- Jeanie still has it; it has been broke awhile

•  We need to shut the service off

•  Neal motioned; Robert-seconded

•  Robert-yes, Neal-yes, Susan (Jeanie)-yes, Homer-yes, Iris (Richia)-yes, Dalton-yes, Scott-yes

 j)      Horry County Council: may require peddler’s license next year

 k)    Attorney said he will be deposed before court

 l)      HTC: $229 to link website to phone book

•  2nd Chief Iris: would prefer landline for work days

 12.2nd Chief Susan

 a)    Rolling Thunder: PW next year

•  would like to do Missing Man Ceremony- Susan has video

Dalton motioned for the meeting to end; Homer seconded.

Meeting adjourned at 9:50pm.

Respectfully submitted by Michelle Hatcher on 1/2/2011 @ 12:01pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
