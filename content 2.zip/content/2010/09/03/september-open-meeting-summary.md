---
layout: post
title: "September 2010 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2010/09/04/september-open-meeting-summary.html
post_id: 5649645
custom_summary: false
summary: ""
date: 2010-09-03T19:00:00-0500
lastmod: 2010-09-03T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2010/09/03/september-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 9/3/2010 held at the Tribal Office in Aynor

1. Meeting opened at 6:45pm with CoC Scott and CM’s Dalton, Homer, Robert, Neal, Jeanie present.

2. August Minutes Read

3. Neal motioned to accept; Homer seconded

4. Dalton-yes, Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

5. Financial Report: 2nd Chief Iris

6. Current Balance: $3563.12

7. Need at least $1300 for operating expenses

8. Committee Reports

9. Building & Grounds: Neal

10. Suk started- will be 16ft wide, 7ft tall

11. New string for nature trail needed; will buy himself

12. Treated grounds for bees

13. Arts & Crafts: Brian

14. Have a wishlist for next year

15. 2nd Chief Iris: Need member’s feathers

16. Deborah working on some

17. 2nd Chief Iris working on clay beads

18. Council needs to tell him who needs feathers

19. Homer: get back to old way of presenting feathers

20. 2nd Chief Iris: role book is on agenda

21. Talking with Mr. Moore about websites and selling items

22. Mary Ellen has her own set up

23. Have almost all the documents we need

24. Meeting on 10/15 (3rd Friday of the month)

25. Talk about Kid’s Arts & Crafts Days

26. Chief Hatcher: Do yard sale on Saturdays; advertise to tribes in papers

27. Brian and Linda to work on it

28. Grants: Michelle

29. Nothing to report; still cannot apply due to Secretary of State order

30. Pauwau: Linda

31. Budget: $13, 169

32. Handout with cost breakdown presented

33. Dalton motioned to approve; Homer seconded

34. Dalton-yes, Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

35. Letter from Grand Strand Magazine- want to include us

36. 2nd Chief Susan: Program Book Rough Draft presented

37. $2.22 per book for 28 page book- 300 books

38. Reaffirm Online Votes

39. Grass Matting for suk

40. Homer-yes, Dalton-yes, (Richia-yes), Neal-yes, Scott-yes, Jeanie-yes, Robert-yes (passed unanimously)

41. 2nd Chief Susan

42. Absentee Ballots

43. How long to vote? who to send to?

44. By email?- print and mail

45. By website?- download, print, and mail

46. Dalton: stick with how it was done last year for consistency

47. Mail by 9/15; cutoff to get back 10/30

48. 2nd Chief Iris: mass email?

49. Chief Hatcher: need policy to prevent doing this every year

50. Elder Doug: let them pick it up at the pauwau & drop it in the box

51. 2nd Chief Iris: Council will need to man its own tent for it

52. Homer: Do it like last year; consider this for next year

53. Chief Hatcher: need an Elections Committee

54. Mailing address for ballots: Jerry was nominated

55. Robert motioned; Homer seconded

56. Dalton-yes; Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

57. Mail by 9/15/2010

58. Homer motioned; Robert seconded

59. Dalton-yes; Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

60. Cutoff Date to be 10/30/2010

61. Robert motioned; Dalton seconded

62. Dalton-yes; Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

63. Elder Jerry to pick three people to assist him

64. 2nd Chief Susan to email Michelle to make copies

65. 2nd Chief Iris: Tribal Roll Book

66. 239 people to sign new book; handout showing breakdown of number of members to sign by state

67. Presentation; no ID without signing the book; feather when book signed

68. Mailing with deadline and purge?

69. Give feathers out at solstices and gatherings as well

70. New Project: Younger Crowd

71. Send Photo ID’s to 10-18 year olds to younger people interested in 2011

72. Robert motioned to approve; Dalton seconded

73. Dalton-yes; Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

74. Homer: would also like to create library of documentaries

75. Chief Hatcher & CoC Scott: Special recognitions to:

76. Donnie Hatcher: Grounds and Cemetery work

77. Doug Hatcher: Website Maintenance

78. Michelle Hatcher: Meeting minutes, Filing, Project availability

79. Note: Make sure all Chief & Council Recognitions you receive are given to the tribal secretary to go in your file. The more recognitions you have on file, the higher any dividend checks will be once federal status is achieved.

80. Chief Hatcher

81. Apologized for giving the impression that School Day is not Tribal Council’s business; can’t relinquish control over 1800+ kids

82. Homer: School Day: same as last year?

83. 2nd Chief Susan: yes

84. Homer: get word out that families don’t get in free

85. 2nd Chief Susan: schools were told they have to use the pass

86. Federal Recognition help with Carolina Entertainment

87. Russell Simmons interested in investing in tribe

88. Chief Hatcher will probably go to NY

89. Copy of motel contract with Econo Lodge given to Council

90. Language: Catawba: Mr. Moore- online class with Becky Garris (sp?)

91. Only charge may be a cd; watch for more emails

92. Call from HTC; auto-link from website $220 approx.- tabled for now

93. Elder Jerry: Cub Scout Jamboree: Cheryl: artifacts, Brian: tipis

94. Federal Recognition from Congressman likely

95. Henry Brown intends to sign our Bill

96. Please continue to write Mr. Brown and encourage him to sign the bill

97. Tribal Judge Bernie: Ask the Vatican too

98. On 9/8 Meeting in Bennettsville with State Recognized Chiefs

99. Senator to help with a stand-alone Indian Agency

100. Governor Candidate Haley has said she would work with Indians in state

101. Insurance for tribal grounds:

102. $908 for year

103. Look into corporate insurance for everything

104. Out-of-town 9/8- 9/16 and 9/20- 9/27

105. Interstate: some things have to be done in 30 days

106. Council permission to answer questions- Dalton motioned; Homer seconded

107. Dalton-yes, Homer-yes, Robert-yes, Neal-yes, Jeanie-yes, Scott-yes (passed by majority)

108. Lawsuits for land: $13,900

109. Coffee News: $300 or $600 depending on number of areas you choose

110. North Grand Strand, Myrtle Beach, South Grand Strand, Loris/ Tabor City, Conway

111. Elder Jerry: Nonprofits are free

112. Chief Hatcher: please talk to her again then

113. Pauwau: double-stack vendors

114. Linda: more RV spots too

115. Chief Hatcher: have to revamp circuit breakers

116. Becky: backup plan if it rains?

117. Chief Hatcher: discuss it in committee

118. Linda: Meeting 9/29 (last Wed in September)

119. Tribal Judge Bernie will white sage grow here?

120. Linda: yes; Robert: no

121. Chief Hatcher welcomed  and thanked Jerry Barbour & his brother & Teresa for coming

Homer motioned for the meeting to end; Robert seconded.

Meeting adjourned 8:41 pm.

Respectfully submitted by Michelle Hatcher on 9/12/10 at 10:41pm.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
