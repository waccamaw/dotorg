---
layout: post
title: "August 2010 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2010/08/07/august-open-meeting-summary.html
post_id: 5649644
custom_summary: false
summary: ""
date: 2010-08-06T19:00:00-0500
lastmod: 2010-08-06T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2010/08/06/august-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 8/6/2010 held at the Tribal Office in Aynor

1. Craig Talbot presented tobacco to CoC Scott

2. Meeting opened at 6:39pm with CoC Scott and CM’s Dalton, Neal, Richia, and Homer present.

3. July minutes read

4. Dalton motioned to accept; Homer seconded

5. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

6. 5yes: 0no: 2absent: 0abstain (passed by majority)

7. CoC to Council: when you receive minutes by email and find a mistake, email Michelle back with that mistake so the correction can be made. For time efficiency during the meeting, you would only have to come in and approve the minutes.

8. Financial Report- 2nd Chief Iris

9. Current Bank Balance: $3865.39

10. Total Bare Bones Requirement through Oct. 2010: $2098.00

11. 2nd Chief Iris: this office building is not a storage unit. A group of us spent a day out here getting it cleaned up and it needs to stay that way. This is an office building.

12. Committee Reports

13. Building & Grounds: Neal

14. Donnie now has a Washer & Dryer and spare parts

15. Treated for yellow jackets at cemetery

16. Work Day before TV crew comes

17. Bushes to plant

18. Linda to donate 2 orange trees and crepe myrtle

19. Richia to donate sage

20. Arts & Crafts: Brian

21. Susan taught all feathers (Iris: not veteran’s feathers)

22. 3 people present for meeting

23. Decided to leave artist certification as-is

24. Mr. Moore brought up new law signed by President Obama and how it gives Chiefs more control to arrest people selling Native American art that should not be

25. Think rules are done for certification

26. Went to Wachesaw; she talked about coming there 2-3 times per year; will contact again

27. Grants: Michelle

28. SCAC Fellowship Grant deadline 10/1, but we cannot apply yet

29. Elder Hank: Melanie hasn’t received anything through Food Lion

30. No grants can be done yet because of court case and Secretary of State’s order

31. PauWau: Linda

32. Proud of her committee

33. Neal: on-site dumpster: $300 deposit, Fri-Wed, $135, $35 per ton

34. Exterminating $400: Wayne Turner

35. 2nd Chief Susan talked to Harland Richardson (drum/ emcee) 5 rooms for 3 nights

36. Vendors: She spoke to a vendor that knew of Harland and said we would not need a second drum

37. Chief Hatcher: make sure Bill and Suzie are here

38. Elder Hank: what about Rick Bird?

39. 2nd Chief Iris: We want comparison prices from all (rooms, nights, etc…)

40. Rodlyn: we have to think of the spirituality of it; want people who respect it

41. 2nd Chief Iris: I agree, but I think it’s stupid to not comparison shop

42. Elder Jerry: Last year, John didn’t charge us for Eastern Bull

43. Homer: When John came back, people commented how glad they were to see him back

44. Linda: PW Committee, listen to the people

45. Brian: We got away from using John and we lost a lot of dancers. We have to think about that too

46. Chief Hatcher: This is the biggest pauwau in SC; probably on the biggest on the east coast. If you stop chasing the spirit, it will suffer

47. Mr. Moore: PauWau TV: he’ll run ad free-of-charge

48. Plenty of work for volunteers

49. 2nd Chief Iris: Robert will need help getting mixed hard woods for Pauwau this year

50. Online Votes

51. Attorney Deposition

52. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes, (Robert-yes)

53. Membership Files

54. Please do not use white-out on the application; take the time to use another application.

55. Michael Porter

56. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

57. Pamela Stahl

58. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

59. Eva Porter

60. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

61. Asher Porter

62. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

63. Samuel Cerezo

64. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Scott-yes

65. Chief Hatcher

66. Presented letter for tribal roll book (asked to do in last month’s meeting)

67. 2nd Chief Iris: further discussion needed (agenda next month); not eliminate T-cards yet

68. Chief Hatcher: Council will need to set the policies

69. 2nd Chief Iris: I don’t want you to vote tonight; I want you to think about the policies and consequences

70. Richia: also inconsistent in applications (different applications going out)

71. Council needs Work Days to get caught up

72. TV: Dan, Neal to meet Tues and film in a couple of weeks

73. Elder Hank: going on Educational TV?

74. Chief Hatcher: yes; if anyone can tape it, please do so

75. Native American Prison Program

76. Probably going to take a change to the law

77. Cheryl Sievers active in program already

78. Craig Talbot present a Celebrate Recovery card; Chief Hatcher said he wasn’t sure that was it

79. Want to bring the program back; right now, only Muslim, Jews, & Christians are available to prisoners at night

80. He wants to move the program statewide

81. Dr. Trott, Cheryl, John George (Catawba), John Abrams, Liz Gilland (Horry County Chairman of Council)

82. Write letters to encourage funding, making it a standard program, and allow Native American spiritual leaders access

83. Would like to list Cheryl as point-of-contact

84. Requires background check

85. Dalton motioned to make Cheryl PoC; Homer seconded

86. Neal-yes, Dalton-yes, Homer-yes (pending background check), Richia-abstain, Scott-yes

87. 4yes: 0no: 2absent: 1abstain (passed by quorum)

88. Richia

89. Email addresses: please keep the list updated

90. Need help from Craig, Linda, Hank, Chief Hatcher, others for information to pass on to the younger generation

91. Did we discuss retiring of numbers last month?

92. Mr. Moore

93. Tribe needs a culture

94. Tents for young people on the weekend here; give the parents a break

95. Drum and dancers of our own; no need to pay anyone

96. Adopt our own language

97. I’ll take every word/ syllable and give it to you

98. 2nd Chief Iris: we have a Catawba language, but no one knows how to speak it

99. Weekend classes to give the parents a break

100. Chief Hatcher: We used to put 10 Waccamaw words in the newsletter

101. Dalton: suggest a committee with Chief in it because it would involve presentations

102. Presented handout about Cherokee and Lakota fire ceremonies

103. Presented 7 life-saving Native American Herbal Healing Secrets

104. Council to work with Mr. Moore

105. Craig

106. Busy from March until now

107. Low Country Festival

108. Alabama Mound Preservation

109. Sparkleberry Festival

110. Beaver Creek Family Day (Chavis)

111. Blue Ridge (Cloudwalker)

112. Pee Dee (Caulder) with Brian

113. Edisto (Davison) with Brian

114. Harborwalk

115. Honor Feather for Cloudwalker in Columbia

116. Funeral for Caleb Moore- Posthumous Naming Ceremony; named him Running Wolf

117. Wachesaw East with Brian; BIA pictures of tipi poles because they were made of bamboo; however bamboo dates back to 1534

118. Apologize for asking for a t-shirt while at the Edisto pauwau; it was their 35th anniversary and I wanted a t-shirt

119. I pay for every expense while on the road

Neal motioned for the meeting to end; Homer seconded.

Meeting adjourned 8:45 pm.

Respectfully submitted by Michelle Hatcher on 8/7/10 at 12:31pm.

[#meeting](https://www.waccamaw.org/updates/hashtags/meeting) [#minutes](https://www.waccamaw.org/updates/hashtags/minutes)
