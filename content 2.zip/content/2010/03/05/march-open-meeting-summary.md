---
layout: post
title: "March 2010 Open Meeting Summary"
microblog: false
guid: http://waccamaw.micro.blog/2010/03/06/march-open-meeting-summary.html
post_id: 5649643
custom_summary: false
summary: ""
date: 2010-03-05T19:00:00-0500
lastmod: 2010-03-05T19:00:00-0500
type: post
categories:
- "meetings"
- "tribal-business "
url: /2010/03/05/march-open-meeting-summary.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---

Tribal Open Meeting Summary 3/5/2010 held at the Tribal Office in Aynor

1. February minutes read

2. Change 8(iv) to read as “Donnie’s light bill”

3. Dalton motioned to accept with the change; Homer seconded

4. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes (passed by majority)

5. Financial Report: Iris

6. $8632.23 on-hand (bills not yet paid this month)

7. Includes $750 Verizon grant

8. Resolution RP-03-03-2010-001: Amendment to Change Article IV Paragraph 2 Subparagraph 2 of the Waccamaw Constitution as Ratified in October 2008 received its 1st reading

9. Dalton suggested changing “majority” to “5 vote majority of the Tribal Council”

10. Amendment to SB-09-12-2008-001: Establishing Committees Amendment to the Program Committee Resolution

11. Dalton-yes, Neal-no, Richia-yes, Homer-yes, Robert-no, Scott-yes (passed by majority)

12. PW Committee Voting Membership appointed: Michelle, Susan, Brian, Linda, Craig, Iris, Neal

13. Linda elected for PW Director: 6y: 0n: 1 absent

14. Committee Reports

15. Arts & Crafts: Brian

16. Artist Certification approved with change

17. Dalton-yes, Neal-yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes (passed by majority)

18. Committee approved admin manual; now needs Council approval

19. Mr. Moore (sp?) can sell at PW; Susan has his certificate

20. Farm Days: wants more next year

21. Criteria manual done; needs to be voted on

22. Would like a mass email to go out for all external matters concerning arts & crafts to be sent to him

23. Building & Grounds: Neal

24. Projects not done due to weather

25. Taking hot water heater to dump (leaks)

26. Would like to tile office floor; approximately $120

27. Tabled after talking to Mr. Moore and Steve

28. Alligator at the creek

29. Craig

30. Next 7-10 weeks will be busy

31. Doing things for Mr. Caulder

32. Holy mounds in Jackson, Alabama

33. Several pauwaus and demonstrations

34. Introducing Melissa Muse (sp?), a Child Advocacy Counselor next month

35. Census 2010

36. Please fill it out and put your tribal affiliation on it

37. Remember that money for the state is based off the census

38. Upcoming Events

39. Chief Hatcher and trip expenses

40. Robert said CEC was supposed to pay for expenses related to federal recognition

41. Iris recommended tabling it

42. Richia said it should be done; Buster does a lot when he could have given up

43. Iris said these small amounts are nothing; he does a lot more out of his pocket

44. Homer motions for $1000; Dalton says too much

45. Richia motions for $500; Neal seconded

46. Dalton- yes, Neal-yes, Richia-yes, Homer-yes, Robert-yes, Scott-yes (passed by majority)

47. Still working on a pc

48. Brian: an organizational chart is needed

49. Dalton nominated Brian for making the chart

Homer motioned for the meeting to end; Robert seconded.

Meeting adjourned 8:47 pm.

Respectfully submitted by Michelle Hatcher on 3/6/10 at 2:21am.

[#minutes](https://www.waccamaw.org/updates/hashtags/minutes) [#meeting](https://www.waccamaw.org/updates/hashtags/meeting)
