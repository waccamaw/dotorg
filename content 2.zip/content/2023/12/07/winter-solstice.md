---
layout: post
title: "Winter Solstice 12/16/2023"
microblog: false
guid: http://waccamaw.micro.blog/2023/12/08/winter-solstice.html
post_id: 5650054
custom_summary: false
summary: ""
date: 2023-12-07T19:00:00-0500
lastmod: 2025-11-22T20:03:08-0500
type: post
images:
- https://cdn.uploads.micro.blog/272201/2025/21f0bbb711.jpg
photos:
- https://cdn.uploads.micro.blog/272201/2025/21f0bbb711.jpg
photos_with_metadata:
- url: https://cdn.uploads.micro.blog/272201/2025/21f0bbb711.jpg
url: /2023/12/07/winter-solstice.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Dec 8, 2023
- 1 min read

The Winter Solstice fire ceremony will be held on 12/16/2023 on the tribal grounds at 591 Bluewater Rd, Aynor, SC, 29511, at 7:15 a.m., noon, and 4:30 p.m. [#native](https://www.facebook.com/hashtag/native?__eep__=6&__cft__[0]=AZVzD4MzeCAs0DGvh7SEElQgew5am5Wm3IhxP5qS4BmtYBJ-G04mTXinXrHHqxqXXAHB0qEcXvM6IgFaBb0W7iqUJD6lTi2ma1kixl-hNvmtM8W4zkJXqevDU0_fW8zXsVr57ApqhR9QV0WrelPE0qkwWugKKoB9GjMU5wVk2xT5UckQOBWnWc1wLSsdVNF4wNU&__tn__=*NK-R) [#Waccamaw](https://www.facebook.com/hashtag/waccamaw?__eep__=6&__cft__[0]=AZVzD4MzeCAs0DGvh7SEElQgew5am5Wm3IhxP5qS4BmtYBJ-G04mTXinXrHHqxqXXAHB0qEcXvM6IgFaBb0W7iqUJD6lTi2ma1kixl-hNvmtM8W4zkJXqevDU0_fW8zXsVr57ApqhR9QV0WrelPE0qkwWugKKoB9GjMU5wVk2xT5UckQOBWnWc1wLSsdVNF4wNU&__tn__=*NK-R)

![ree](https://waccamaw.micro.blog/uploads/2025/21f0bbb711.jpg)
