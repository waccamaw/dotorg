---
layout: post
title: "Spring Equinox 2023"
microblog: false
guid: http://waccamaw.micro.blog/2023/02/15/spring-equinox.html
post_id: 5650034
custom_summary: false
summary: ""
date: 2023-02-14T19:00:00-0500
lastmod: 2023-02-14T19:00:00-0500
type: post
url: /2023/02/14/spring-equinox.html
author:
  name: "Doug Hatcher"
  full_name: "Doug Hatcher"
  username: hatcher
  avatar: https://avatars.micro.blog/avatars/2025/42/1836278.jpg
authors:
- hatcher
---


-

Michelle Hatcher
- Feb 14, 2023
- 1 min read

The Spring Equinox fire ceremony will be held on 3/18/2023 beginning

at 7:22 am. [#native](https://www.waccamaw.org/updates/hashtags/native) [#Waccamaw](https://www.waccamaw.org/updates/hashtags/Waccamaw)

Tags:

- [#Waccamaw](https://www.waccamaw.org/updates/tags/waccamaw-1)
- [Native](https://www.waccamaw.org/updates/tags/native)
- [event](https://www.waccamaw.org/updates/tags/event)
- [community](https://www.waccamaw.org/updates/tags/community)
- [equinox](https://www.waccamaw.org/updates/tags/equinox)
